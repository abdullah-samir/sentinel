"""Bought parts, cables and keep-out zones, modelled at their real size and position (inner box coordinates).

Item.kind:
  solid - material; may not overlap anything except what `allow` names
  soft  - room for jumpers, wire bends and cables; may overlap other soft items, flagged (WARN) against solids
  air   - must stay empty of solids (fan intake, NFC field)
Item.stage - fitting step that installs it (see assembly.STEPS)
"""
import math
from dataclasses import dataclass, field
import cadquery as cq
from params import *
from geom import *


@dataclass
class Item:
    name: str
    shape: object
    color: str = "#888888"
    kind: str = "solid"
    allow: tuple = ()
    stage: str = ""
    note: str = ""

    @property
    def group(self):
        return self.name.split(".")[0]


PCB_G, PCB_B, PCB_BL, PCB_R = "#2f7d4a", "#1f1f1f", "#1f4e9c", "#a32020"
METAL, BLACK, GOLD, BRASS, WIRE = "#b8bcc2", "#2b2b2b", "#d4a017", "#c8a24a", "#e0a030"


def U(*shapes):
    sh = [s for s in shapes if s is not None]
    return sh[0] if len(sh) == 1 else fuse_all(sh[0], sh[1:])


# ------------------------------------------------------------------ Raspberry Pi 4
def pi4():
    p = PI
    z0, z1 = p["z0"], p["z0"] + p["t"]
    pcb = box(p["x0"], p["x1"], p["y0"], p["y1"], z0, z1)
    pcb = cut_all(pcb, [cyl_z(x, y, z0 - 1, z1 + 1, 2.7) for x, y in PI_HOLES])
    under = box(p["x0"] + 0.5, p["x1"] - 0.5, p["y0"] + 0.5, p["y1"] - 0.5, z0 - 1.8, z0)
    under = cut_all(under, [cyl_z(x, y, z0 - 3, z0 + 1, 7.0) for x, y in PI_HOLES])
    st = "2 Pi"
    it = [Item("pi.pcb", pcb, PCB_G, stage=st), Item("pi.underside", under, PCB_G, stage=st, note="solder joints / bottom parts"),
          Item("pi.usb2", box(*PI_USB2), METAL, stage=st), Item("pi.usb3", box(*PI_USB3), "#3a6fd8", stage=st),
          Item("pi.eth", box(*PI_ETH), METAL, stage=st),
          Item("pi.gpio", box(53.5, 58.5, 84.1, 134.9, z1, z1 + 8.5), BLACK, stage=st),
          Item("pi.hs_soc", box(24.5, 38.5, 106.0, 120.0, z1, z1 + HS_MAX), "#9aa0a6", stage=st),
          Item("pi.hs_ram", box(26.5, 36.5, 88.0, 102.0, z1, z1 + 7.0), "#9aa0a6", stage=st),
          Item("pi.usbc", box(2.5, 9.8, 126.3, 135.2, z1, z1 + 3.2), METAL, stage=st),
          Item("pi.hdmi0", box(2.5, 10.0, 112.4, 119.6, z1, z1 + 3.0), METAL, stage=st),
          Item("pi.hdmi1", box(2.5, 10.0, 98.9, 106.1, z1, z1 + 3.0), METAL, stage=st),
          Item("pi.audio", box(1.0, 13.0, 85.5, 91.5, z1, z1 + 6.0), BLACK, stage=st),
          Item("pi.sdcard", box(26.0, 37.0, 130.0, 144.5, z0 - 1.6, z0 - 0.8), "#444444", stage=st, note="microSD, sticks out 2.5 [A]"),
          Item("pi.gpio_jumpers", box(53.0, 67.0, 84.1, 134.9, 7.9, 26.9), WIRE, "soft", stage="4 jumpers")]
    for i, (x, y) in enumerate(PI_HOLES):
        it.append(Item(f"pi_screw{i}.head", cyl_z(x, y, z1, z1 + 2.5, 4.5), METAL, stage="2 Pi"))
        it.append(Item(f"pi_screw{i}.shank", cyl_z(x, y, z0 - 4.0, z1, 2.5), METAL, allow=("pi.pcb", "pi_insert"), stage="2 Pi"))
        it.append(Item(f"pi_insert{i}", cyl_z(x, y, z0 - INSERT_M25["l"], z0, INSERT_M25["od"]), BRASS, allow=("base",), stage="0 base"))
    return it


# ------------------------------------------------------------------ Pi-end USB plugs (short, home-made) and their wires
def usb_plugs():
    it = []
    for name, (x0, x1), (z0, z1), port in (("usbplug.esp", (24.0, 37.0), (14.4, 20.4), "pi.usb3"),
                                           ("usbplug.wn1", (6.0, 19.0), (14.4, 20.4), "pi.usb2"),
                                           ("usbplug.wn2", (24.0, 37.0), (6.4, 12.4), "pi.usb3")):
        body = box(x0, x1, 45.5, 54.5, z0, z1)
        xc, zc = (x0 + x1) / 2, (z0 + z1) / 2
        tongue = box(xc - 6.0, xc + 6.0, 54.5, 66.5, zc - 2.25, zc + 2.25)
        stage = "3 NIC B plug" if name.endswith("wn2") else "6 Pi plugs"
        it.append(Item(name, U(body, tongue), METAL, allow=(port,), stage=stage))
    it.append(Item("usbwire.nic_gap", box(12.0, 95.0, 38.5, 45.4, 6.0, 28.0), WIRE, "soft", stage="6 Pi plugs",
                   note="NIC USB wires along the gap behind the breadboard"))
    it.append(Item("usbfree", box(*NIC_USB_ENVELOPE), "#ffd27a", "air", allow=("socket", "wn1.plug", "wn2.plug"), stage="11b NIC stack",
                   note="space for the USB connectors on the WN722N plugs and their cables: no printed part may enter it"))
    it.append(Item("usbwire.nic_front", box(NIC_PLUG_CX - 11.5, NIC_PLUG_CX + 10.5, 8.0, SOCKET["y0"], BUZ["cz"] + BUZ["d"] / 2 + 0.3, 54.0), WIRE, "soft", stage="11b NIC stack",
                   note="NIC USB wires from the free sockets on the WN722N plugs, down in front of the shelf"))
    return it


# ------------------------------------------------------------------ ESP32-S3 DevKitC-1 (flipped: components down, pins up)
def esp32():
    e = ESP
    X = lambda a: e["x0"] + a
    Y = lambda b: e["y0"] + b
    zp0, zp1 = ESP_PCB_Z
    st = "5 ESP"
    it = [Item("esp.pcb", box(X(0), X(e["w"]), Y(0), Y(e["carrier_l"]), zp0, zp1), PCB_B, stage=st),
          Item("esp.module_pcb", box(X(ESP_MOD["ax"][0]), X(ESP_MOD["ax"][1]), Y(ESP_MOD["ly"][0]), Y(ESP_MOD["ly"][1]), 5.4, zp0),
               PCB_B, stage=st),
          Item("esp.shield", box(X(ESP_MOD["ax"][0]), X(ESP_MOD["ax"][1]), Y(ESP_SHIELD_LY[0]), Y(ESP_SHIELD_LY[1]), ESP_MOD["z"][0], 5.4),
               METAL, stage=st),
          Item("esp.ipex", box(X(ESP_IPEX["ax"][0]), X(ESP_IPEX["ax"][1]), Y(ESP_IPEX["ly"][0]), Y(ESP_IPEX["ly"][1]), *ESP_IPEX["z"]),
               GOLD, stage=st),
          Item("esp.parts", box(X(3.0), X(24.5), Y(9.5), Y(ESP_MOD["ly"][0] - 0.5), 4.2, zp0), "#444444", stage=st,
               note="[A] other parts on the (downward) component side")]
    for i, (a, b) in enumerate(ESP_USBC):
        it.append(Item(f"esp.usbc{i}", box(X(a), X(b), Y(-0.2), Y(8.7), ESP_MOD["z"][0], zp0), METAL, stage=st))
    for i, (a, b) in enumerate(ESP_HDR):
        it.append(Item(f"esp.hdr{i}", U(box(X(a), X(b), Y(0.1), Y(56.0), zp1, zp1 + 2.5),
                                        box(X(a) + 0.6, X(b) - 0.6, Y(0.1), Y(56.0), zp1 + 2.5, zp1 + 8.5)), BLACK, stage=st))
    it.append(Item("esp.jumpers0", box(X(-6.4), X(2.5), Y(0.0), Y(56.1), zp1 + 2.5, SHELF_Z - 0.2), WIRE, "soft", stage="6 Pi plugs"))
    it.append(Item("esp.jumpers1", box(X(25.0), X(33.8), Y(0.0), Y(56.1), zp1 + 2.5, SHELF_Z - 0.2), WIRE, "soft", stage="6 Pi plugs"))
    # 90 deg USB-C plug, cable up then under the shelf to the Pi's USB 3 upper port
    ux = X(sum(ESP_USBC[USBC_PORT]) / 2)
    uz = (ESP_MOD["z"][0] + zp0) / 2
    u = USBC90
    body = box(ux - u["w"] / 2, ux + u["w"] / 2, Y(-0.2) - u["d"], Y(-0.2), uz - u["below"], uz + u["up"])
    tongue = box(ux - 4.2, ux + 4.2, Y(-0.2), Y(6.5), uz - 1.2, uz + 1.2)
    it.append(Item("usbc90.plug", U(body, tongue), "#333333", allow=(f"esp.usbc{USBC_PORT}",), stage=st))
    it.append(Item("usbc90.cable", box(ux - 2.5, ux + 2.5, Y(-0.2) - 6.8, Y(-0.2) - 1.8, uz + u["up"], 27.5), WIRE, "soft", stage=st))
    it.append(Item("usbc90.run", box(24.0, ux + 2.5, 38.5, 46.5, 18.0, 27.5), WIRE, "soft", allow=("usbplug.esp",), stage="6 Pi plugs"))
    # antenna lead: IPEX -> right side under the module -> back -> up through the shelf cut-out to bulkhead 6
    x6 = HOLES[5]["x"]
    it.append(Item("esplead.a", box(X(ESP_IPEX["ax"][0]), X(29.3) + 4.0, Y(54.5), Y(60.0), 2.4, 5.3), WIRE, "soft", allow=("esp.ipex",), stage=st))
    it.append(Item("esplead.b", box(X(29.3) + 0.3, X(29.3) + 4.0, Y(54.5), 126.0, 2.4, 9.0), WIRE, "soft", stage=st))
    it.append(Item("esplead.c", box(x6 - 3.5, X(29.3) + 4.0, CUT[2] + 0.5, 133.4, 2.4, ROW_Z + 4.0), WIRE, "soft", stage=st))
    it.append(Item("esplead.d", box(x6 - 3.5, X(29.3) + 4.0, 118.0, CUT[2] + 0.5, 2.4, SHELF_Z - 0.2), WIRE, "soft", stage=st))
    return it


# ------------------------------------------------------------------ fan, spacers' screws and nuts
def fan():
    f = FAN
    x0, x1, y0, y1 = f["cx"] - f["s"] / 2, f["cx"] + f["s"] / 2, f["cy"] - f["s"] / 2, f["cy"] + f["s"] / 2
    z0, z1 = FAN_Z0, FAN_Z0 + f["t"]
    body = box(x0, x1, y0, y1, z0, z1).cut(cyl_z(f["cx"], f["cy"], z0 - 1, z1 + 1, f["bore"]))
    body = body.fuse(cyl_z(f["cx"], f["cy"], z0, z1, f["hub"]))
    p = f["pitch"] / 2
    holes = [(f["cx"] + dx, f["cy"] + dy) for dx in (-p, p) for dy in (-p, p)]
    body = cut_all(body, [cyl_z(x, y, z0 - 1, z1 + 1, 3.4) for x, y in holes])
    st = "10 shelf"
    it = [Item("fan.body", body, "#303030", stage=st),
          Item("fan.intake", box(x0, x1, y0, y1, z1, SHELF_Z), "#9ad0ff", "air", allow=("fan_spacer", "fan_screw"), stage=st)]
    for i, (x, y) in enumerate(holes):
        head = cone_z(x, y, ST - M3_CSK["h"], ST, 3.0, M3_CSK["d"])
        shank = cyl_z(x, y, ST - 18.3, ST - M3_CSK["h"], 3.0)
        it.append(Item(f"fan_screw{i}", U(head, shank), METAL, allow=("fan_nut",), stage=st))
        it.append(Item(f"fan_nut{i}", hex_prism_z(x, y, z0 - 2.4, z0, 5.5).cut(cyl_z(x, y, z0 - 3, z0 + 1, 3.0)), METAL, stage=st))
    return it


# ------------------------------------------------------------------ floor parts
def floor_parts():
    b = BB
    it = [Item("bb.body", box(b["x0"], b["x1"], b["y0"], b["y1"], 0, b["h"]), "#f2f2f2", stage="8 breadboard"),
          Item("bb.jumpers", box(b["x0"], b["x1"], b["y0"], b["y1"], b["h"], 28.0), WIRE, "soft", stage="8 breadboard",
               note="jumpers standing in the breadboard (<= 18 mm tall)")]
    p = PN
    it += [Item("pn.pcb", box(p["x0"], p["x0"] + p["t"], p["y0"], p["y1"], p["z0"], p["z1"]), PCB_R, stage="7 small parts"),
           Item("pn.parts", box(*p["parts"]), "#444444", stage="7 small parts"),
           Item("pn.hdr", box(*p["hdr"]), BLACK, stage="7 small parts"),
           Item("pn.jumpers", box(11.3, 30.3, 39.9, 44.1, 15.3, 27.8), WIRE, "soft", stage="7 small parts"),
           Item("pn.field", box(p["x0"] + p["t"], 12.8, p["y0"], p["y1"], p["z0"], p["z1"]), "#9ad0ff", "air", allow=("base", "print"),
                stage="7 small parts", note="NFC near field: no metal")]
    bz = BUZ
    ear = lambda ya, yb: box(bz["x0"], bz["x0"] + bz["ear_t"], ya, yb, bz["cz"] - bz["ear_w"] / 2, bz["cz"] + bz["ear_w"] / 2)
    it += [Item("buz.body", U(cyl_x(bz["cy"], bz["cz"], bz["x0"], bz["x1"], bz["d"]),
                              ear(bz["cy"] - bz["ear_pitch"] / 2 - 3.0, bz["cy"]), ear(bz["cy"], bz["cy"] + bz["ear_pitch"] / 2 + 3.0)),
                   BLACK, stage="7 small parts"),
           Item("buz.wires", box(100.0, bz["x0"], bz["cy"] - 3.0, bz["cy"] + 3.0, bz["cz"], 24.0), WIRE, "soft", stage="7 small parts")]
    s = SW
    bw, bh, bt = s["bezel"]
    cw, ch, cl = s["body"]
    it += [Item("sw.bezel", box(s["cx"] - bw / 2, s["cx"] + bw / 2, -WALL - bt, -WALL, s["cz"] - bh / 2, s["cz"] + bh / 2), BLACK,
                stage="9 KCD11"),
           Item("sw.body", box(s["cx"] - cw / 2, s["cx"] + cw / 2, -WALL, cl, s["cz"] - ch / 2, s["cz"] + ch / 2), BLACK, stage="9 KCD11"),
           Item("sw.terms", box(s["cx"] - 3.5, s["cx"] + 3.5, cl, cl + 6.0, s["cz"] - 3.0, s["cz"] + 3.0), METAL, stage="9 KCD11"),
           Item("sw.wires", box(s["cx"] - 4.5, s["cx"] + 4.5, cl + 6.0, cl + 14.0, s["cz"] - 4.5, s["cz"] + 4.5), WIRE, "soft",
                stage="9 KCD11")]
    k = KY
    it += [Item("ky.pcb", box(k["x0"], k["x1"], *k["pcb_y"], k["z0"], k["z1"]), PCB_BL, stage="7 small parts"),
           Item("ky.parts", box(k["x0"] + 1.5, k["x1"] - 1.5, *k["parts_y"], k["z0"] + 1.5, k["z1"] - 1.5), "#444444", stage="7 small parts"),
           Item("ky.pins", box(k["x1"], k["x1"] + 6.0, 143.7, 144.7, 13.5, 17.5), GOLD, stage="7 small parts", note="[A] header end"),
           Item("ky.jumpers", box(k["x1"], k["x1"] + 22.0, 139.0, 144.8, 11.0, 20.0), WIRE, "soft", stage="7 small parts")]
    # power bank cable plug (outside, through the 15 x 9 hole into the Pi's USB-C)
    yc, zc = PI_USBC_Y, PI["z0"] + PI["t"] + 1.6
    it.append(Item("power.plug", U(box(-16.0, 2.5, yc - 6.0, yc + 6.0, zc - 3.25, zc + 3.25),
                                   box(2.5, 9.0, yc - 4.2, yc + 4.2, zc - 1.2, zc + 1.2)), "#333333", allow=("pi.usbc",),
                   stage="18 power", note="[A] USB-C plug overmold up to 14.6 x 8.6 fits the hole"))
    return it


# ------------------------------------------------------------------ screen and buttons (lid assembly)
def lid_parts():
    x0, y0 = TFT_X0, TFT_Y0
    pw, ph, pt = TFT_PCB
    zt = TFT_TOP
    pcb = box(x0, x0 + pw, y0, y0 + ph, zt - pt, zt)
    pcb = cut_all(pcb, [cyl_z(x0 + hx, y0 + hy, zt - 3, zt + 1, 3.2) for hx, hy in TFT_HOLES])
    gw, gh, gt = GLASS
    hdr = zt - pt - 2.5
    st = "16 lid"
    it = [Item("tft.pcb", pcb, PCB_BL, stage=st),
          Item("tft.glass", box(GCX - gw / 2, GCX + gw / 2, GCY - gh / 2, GCY + gh / 2, zt, zt + gt), "#101820", stage=st),
          Item("tft.j2", box(x0 + 1.2, x0 + 3.8, y0 + 7.1, y0 + 27.4, hdr - 6.0, zt - pt), BLACK, stage=st),
          Item("tft.j4", box(x0 + 54.2, x0 + 56.8, y0 + 12.2, y0 + 22.3, hdr - 6.0, zt - pt), BLACK, stage=st),
          Item("tft.sd", box(x0 + 37.0, x0 + 52.0, y0 + 9.7, y0 + 24.7, zt - pt - 2.0, zt - pt), METAL, stage=st),
          Item("tft.jumpers2", box(x0 - 0.5, x0 + 5.5, y0 + 6.3, y0 + 28.3, hdr - 19.0, hdr), WIRE, "soft", stage=st),
          Item("tft.jumpers4", box(x0 + 52.5, x0 + 58.5, y0 + 11.4, y0 + 23.1, hdr - 19.0, hdr), WIRE, "soft", stage=st)]
    for i, (hx, hy) in enumerate(TFT_HOLES):
        x, y = x0 + hx, y0 + hy
        it.append(Item(f"tft_screw{i}", U(cyl_z(x, y, zt - pt - 1.7, zt - pt, 4.5), cyl_z(x, y, zt - pt, zt + 2.4, 2.5)), METAL,
                       allow=("lid", "tft.pcb"), stage=st))
    b = BTN
    top = H + LID_T
    for i, (cx, cy) in enumerate(BTNS):
        n = f"btn{i}"
        it += [Item(f"{n}.head", U(cyl_z(cx, cy, top, top + b["head_h"], b["head_d"]), cyl_z(cx, cy, top + b["head_h"], top + b["above"], b["cap_d"])),
                    "#c0392b" if BTN_NAMES[i] == "OK" else "#d0d0d0", stage=st),
               Item(f"{n}.thread", cyl_z(cx, cy, top - b["thr_l"], top, b["thr_d"]), METAL, allow=(f"{n}.nut",), stage=st),
               Item(f"{n}.nut", hex_prism_z(cx, cy, H - b["nut_t"], H, b["nut_af"]).cut(cyl_z(cx, cy, H - 3, H + 1, b["thr_d"] - 0.5)), METAL,
                    stage=st),
               Item(f"{n}.body", cyl_z(cx, cy, top - b["body_l"], top - b["thr_l"], b["body_d"]), BLACK, stage=st),
               Item(f"{n}.pins", box(cx - 3.0, cx + 3.0, cy - 1.5, cy + 1.5, top - b["pin_l"], top - b["body_l"]), METAL, stage=st),
               Item(f"{n}.wires", box(cx - 6.0, cx + 6.0, cy - 6.0, cy + 6.0, top - b["pin_l"] - 3.0, top - b["body_l"]), WIRE, "soft", stage=st)]
    for i, p in enumerate(LID_POSTS):
        x, y = p["x"], p["y"]
        it.append(Item(f"lid_screw{i}", U(cyl_z(x, y, top, top + M3_HEAD["h"], M3_HEAD["d"]), cyl_z(x, y, top - 8.0, top, 3.0)), METAL,
                       allow=(f"lid_insert{i}",), stage="17 lid screws"))
        it.append(Item(f"lid_insert{i}", cyl_z(x, y, H - INSERT_M3["l"], H, INSERT_M3["od"]), BRASS, allow=("base",), stage="0 base"))
    return it


# ------------------------------------------------------------------ WN722N pair in the rails
def wn722n():
    """Two WN722N boards, component face up, USB plug at the front, RP-SMA jack on the left edge near the far end.
    Width NIC_PCB_W (21-23 mm [U]); y and z data as in rev 5. Nothing within 2.5 mm of the long edges [U] except the
    button on the right edge (2 mm high, plunger 1 mm past the edge, near the USB end [U]): its position along the edge is
    not measured, so the whole path it sweeps while the board slides in is kept clear (air item wnN.button_path)."""
    w, x0 = NIC_PCB_W, NIC_X0
    d = NIC_YUSB + 101.5
    ty = lambda a, b: (d - b, d - a)
    it = []
    sk = SOCKET
    eb = NIC_BTN["edge_band"]
    xk = nic_right()["kerb"]
    for k, dz in ((1, 0.0), (2, 14.0)):
        n = f"wn{k}"
        zz = lambda a, b: (a + DZ_R + dz, b + DZ_R + dz)
        jx0, jx1 = x0 - 8.0, x0                     # RP-SMA jack on the left edge, 8 long
        jy0, jy1 = ty(40.5, 47)
        jz0, jz1 = zz(39.6, 46.1)
        jyc, jzc = (jy0 + jy1) / 2, (jz0 + jz1) / 2
        zp = zz(42.1, 43.7)
        st = "11b NIC stack"
        it += [Item(f"{n}.pcb", box(x0, x0 + w, *ty(35.5, 101.5), *zp), PCB_G, stage=st),
               Item(f"{n}.parts", box(x0 + eb, x0 + w - eb, *ty(47.5, 99.5), *zz(40.7, 45.1)), "#444444", stage=st,
                    note="[A] parts envelope 1.4 mm each face, 2.5 mm in from the long edges [U]"),
               Item(f"{n}.jack", U(cyl_x(jyc, jzc, jx0 + 5.0, jx1, 6.5), cyl_x(jyc, jzc, jx0, jx0 + 5.0, 6.35)), GOLD, stage=st),
               Item(f"{n}.plug", box(NIC_PLUG_CX - 6.0, NIC_PLUG_CX + 6.0, *ty(101.5, 115.5), *zz(40.6, 45.1)), METAL,
                    allow=(f"socket{k}",), stage=st),
               Item(f"{n}.button_path", box(xk - eb, xk + NIC_BTN["out"], NIC_YUSB, NIC_RAIL["y1_r"], zp[1], zp[1] + NIC_BTN["h"]),
                    "#ff7a7a", "air", allow=("wn",), stage=st,
                    note="button + 1 mm plunger with the board pushed against the right rail's kerb, along its whole sliding path"),
               Item(f"socket{k}", box(sk["cx"] - sk["w"] / 2, sk["cx"] + sk["w"] / 2, sk["y0"], sk["y0"] + sk["l"],
                                      sk["cz"][k - 1] - sk["h"] / 2, sk["cz"][k - 1] + sk["h"] / 2), METAL, stage=st),
               Item(f"socket{k}.pins", box(sk["cx"] - 4.5, sk["cx"] + 4.5, sk["y0"] + 0.5, sk["y0"] + 2.5,
                                           sk["cz"][k - 1] - sk["h"] / 2 - 3.0, sk["cz"][k - 1] - sk["h"] / 2), METAL, stage=st)]
        # right-angle RP-SMA plug: coupling nut on the jack's thread, elbow beyond it, cable boot to the back
        nut = cyl_x(jyc, jzc, jx0 - 0.5, jx0 + 5.5, 9.2)
        elbow = box(jx0 - 5.5, jx0 - 0.5, jyc - 4.0, jyc + 4.0, jzc - 4.0, jzc + 4.0)
        boot = box(jx0 - 5.0, jx0 - 1.0, jyc + 4.0, jy1 + 6.2, jzc - 2.25, jzc + 2.25)
        it.append(Item(f"{n}ra.plug", U(nut, elbow, boot), "#d4a017", allow=(f"{n}.jack",), stage="12 RA plugs"))
    # coax from each RA plug to its bulkhead (lower board -> hole 4, upper -> hole 5)
    it.append(Item("coax.wn1", box(HOLES[3]["x"] - 3.0, 92.0, 109.0, 133.4, 33.0, ROW_Z + 4.0), WIRE, "soft", allow=("wn1ra", "wn2ra"), stage="12 RA plugs"))
    it.append(Item("coax.wn2", box(84.0, HOLES[4]["x"] + 4.0, 109.0, 133.4, ROW_Z - 4.0, 55.0), WIRE, "soft", allow=("wn1ra", "wn2ra"), stage="12 RA plugs"))
    return it


# ------------------------------------------------------------------ nRF24L01+PA+LNA on adapters
def nrf24():
    it = []
    ye = OUT_Y - 2.5
    for k, xc in enumerate(NRF_X, 1):
        n = f"nrf{k}"
        a0, z = xc - 9.5, ST + 1.0
        st = "13 nRF24"
        it += [Item(f"{n}.adapter", box(a0, a0 + 19, NRF_YS, NRF_YS + 26, z, z + 1.6), PCB_B, stage=st),
               Item(f"{n}.socket", box(a0 + 4, a0 + 15, NRF_YS + 9, NRF_YS + 19, z + 1.6, z + 9.0), BLACK, stage=st),
               Item(f"{n}.hdr", box(a0 + 4.4, a0 + 14.6, NRF_YS + 1, NRF_YS + 6.1, z + 1.6, z + 10.1), BLACK, stage=st),
               Item(f"{n}.jumpers", box(a0 + 3.5, a0 + 15.5, NRF_YS, NRF_YS + 7, z + 4.1, TFT_TOP - TFT_PCB[2] - 1.9), WIRE, "soft", stage=st),
               Item(f"{n}.module", box(xc - 7.75, xc + 7.75, ye - 41, ye, z + 9.0, z + 13.0), PCB_B, stage=st),
               Item(f"{n}.jack", U(cyl_y(xc, ROW_Z, ye, ye + 3.0, 6.5), cyl_y(xc, ROW_Z, ye + 3.0, ye + 8.0, 6.35)), GOLD, stage=st)]
        it += antenna(f"ant{k}", xc, ye + 3.0, "15 antennas")
    return it


def antenna(name, x, y_seat, stage):
    """SMA/RP-SMA rubber-duck antenna: coupling nut + hinge on the thread, whip folded straight up [A]."""
    nut = cyl_y(x, ROW_Z, y_seat + 0.5, y_seat + 10.0, 9.0)
    hinge = cyl_y(x, ROW_Z, y_seat + 10.0, y_seat + 18.0, 10.0)
    whip = cyl_z(x, y_seat + 14.0, ROW_Z, ROW_Z + 105.0, 10.0)
    return [Item(name, U(nut, hinge, whip), "#2b2b2b", allow=(name.replace("ant", "nrf") + ".jack", name.replace("ant", "sma") + ".thread"),
                 stage=stage)]


# ------------------------------------------------------------------ SMA / RP-SMA bulkheads in holes 4-6
def bulkheads():
    it = []
    s = SMA
    seat = OUT_Y - s["clamp"]                          # 145.0
    for h in HOLES:
        if h["kind"] != "sma":
            continue
        x, n = h["x"], f"sma{h['n']}"
        st = "1 SMA leads"
        it += [Item(f"{n}.flange", hex_prism_y(x, ROW_Z, seat - s["flange_t"], seat, s["flange_af"]), GOLD, stage=st),
               Item(f"{n}.body", cyl_y(x, ROW_Z, seat - s["flange_t"] - s["body_l"], seat - s["flange_t"], s["body_d"]), GOLD, stage=st),
               Item(f"{n}.thread", cyl_y(x, ROW_Z, seat, seat + s["thread_min"], s["thread"]), GOLD, stage=st),
               Item(f"{n}.washer", cyl_y(x, ROW_Z, OUT_Y, OUT_Y + s["washer_t"], s["washer_d"]).cut(cyl_y(x, ROW_Z, OUT_Y - 1, OUT_Y + 1, 6.5)),
                    METAL, stage=st),
               Item(f"{n}.nut", hex_prism_y(x, ROW_Z, OUT_Y + s["washer_t"], OUT_Y + s["washer_t"] + s["nut_t"], s["nut_af"])
                    .cut(cyl_y(x, ROW_Z, OUT_Y - 1, OUT_Y + 5, 6.0)), METAL, stage=st)]
        it += antenna(f"ant{h['n']}", x, OUT_Y + s["washer_t"] + s["nut_t"] + 0.5, "15 antennas")
    return it


# ------------------------------------------------------------------ shelf screws, strap screw
def shelf_fasteners():
    it = []
    for i, (x, y) in enumerate(SHELF_POSTS):
        it.append(Item(f"shelf_screw{i}", U(cyl_z(x, y, ST, ST + M3_HEAD["h"], M3_HEAD["d"]), cyl_z(x, y, ST - 8.0, ST, 3.0)), METAL,
                       allow=(f"shelf_insert{i}",), stage="11 shelf screws"))
        it.append(Item(f"shelf_insert{i}", cyl_z(x, y, SHELF_Z - INSERT_M3["l"], SHELF_Z, INSERT_M3["od"]), BRASS, allow=("base",),
                       stage="0 base"))
    sx, sy = STRAP["screw"]
    zt = CRADLE["wall_top"] + STRAP["t"]
    it.append(Item("strap_screw", U(cyl_z(sx, sy, zt, zt + M3_HEAD["h"], M3_HEAD["d"]), cyl_z(sx, sy, zt - 8.0, zt, 3.0)), METAL,
                   allow=("strap_insert",), stage="14 stop+strap"))
    it.append(Item("strap_insert", cyl_z(sx, sy, CRADLE["wall_top"] - INSERT_M3["l"], CRADLE["wall_top"], INSERT_M3["od"]), BRASS,
                   allow=("shelf",), stage="10 shelf"))
    return it


def all_bought():
    return pi4() + usb_plugs() + esp32() + fan() + floor_parts() + lid_parts() + wn722n() + nrf24() + bulkheads() + shelf_fasteners()


if __name__ == "__main__":
    import time
    t = time.time()
    items = all_bought()
    bad = [i.name for i in items if not i.shape.isValid()]
    print(len(items), "items, invalid:", bad, round(time.time() - t, 1), "s")
