"""Small drawing toolkit: hidden-line projections of the CAD solids (OpenCascade HLR) and dimensioning in matplotlib.
Every view is placed on an A3 sheet in paper millimetres at a stated scale, so a sheet printed at 100 % can be measured."""
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, PathPatch
from matplotlib.path import Path
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.gp import gp_Ax2, gp_Pnt, gp_Dir
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE, TopAbs_WIRE
from OCP.BRepAdaptor import BRepAdaptor_Curve
from OCP.GCPnts import GCPnts_QuasiUniformDeflection
from OCP.TopoDS import TopoDS
from OCP.BRepTools import BRepTools_WireExplorer
import cadquery as cq

A3 = (420.0, 297.0)
INK, THIN, HID = "#111111", "#444444", "#8a8a8a"
DIMC = "#0b4f9c"
FS = 2.6          # text height on paper, mm

# view name -> (direction towards the viewer N, paper x axis Vx); paper y = N x Vx
VIEWS = {
    "top": ((0, 0, 1), (1, 0, 0)),          # plan, x right, y up
    "bottom": ((0, 0, -1), (1, 0, 0)),      # from below, x right, y down
    "front": ((0, -1, 0), (1, 0, 0)),       # viewer in front (y < 0): x right, z up
    "back": ((0, 1, 0), (-1, 0, 0)),        # viewer behind: x to the left, z up
    "left": ((-1, 0, 0), (0, -1, 0)),       # viewer on the left: y to the left... (front at the right), z up
    "right": ((1, 0, 0), (0, 1, 0)),        # viewer on the right: y right, z up
}


def axes_of(view):
    n, vx = (np.array(v, float) for v in VIEWS[view])
    return n, vx, np.cross(n, vx)


def p2(view, p):
    """3D model point -> 2D view coordinates (model mm)."""
    n, vx, vy = axes_of(view)
    p = np.asarray(p, float)
    return np.array([p @ vx, p @ vy])


def _edges(comp, defl=0.02):
    out = []
    if comp is None or comp.IsNull():
        return out
    ex = TopExp_Explorer(comp, TopAbs_EDGE)
    while ex.More():
        e = TopoDS.Edge_s(ex.Current())
        c = BRepAdaptor_Curve(e)
        try:
            d = GCPnts_QuasiUniformDeflection(c, defl)
            pts = [c.Value(d.Parameter(i)) for i in range(1, d.NbPoints() + 1)]
        except Exception:
            pts = [c.Value(c.FirstParameter()), c.Value(c.LastParameter())]
        out.append(np.array([(p.X(), p.Y()) for p in pts]))
        ex.Next()
    return out


def hlr(shape, view, hidden=False):
    n, vx, _ = axes_of(view)
    algo = HLRBRep_Algo()
    algo.Add(shape.wrapped)
    algo.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(0, 0, 0), gp_Dir(*n), gp_Dir(*vx))))
    algo.Update()
    algo.Hide()
    h = HLRBRep_HLRToShape(algo)
    vis = _edges(h.VCompound()) + _edges(h.OutLineVCompound())
    hid = (_edges(h.HCompound()) + _edges(h.OutLineHCompound())) if hidden else []
    return vis, hid


def section_polys(shape, axis, value):
    """Cross-section of a solid by the plane axis = value. Returns a list of faces, each a list of closed 3D polylines
    (first = outer wire)."""
    big = 1000.0
    lo, hi = [-big] * 3, [big] * 3
    i = "xyz".index(axis)
    lo[i], hi[i] = value - 1e-3, value + 1e-3
    slab = cq.Solid.makeBox(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2], cq.Vector(*lo))
    cut = shape.intersect(slab)
    faces = []
    for f in cut.Faces():
        nrm = f.normalAt()
        if abs(abs(nrm.toTuple()[i]) - 1) > 1e-6 or abs(f.Center().toTuple()[i] - (value + 1e-3)) > 1e-4:
            continue
        loops = []
        for w in [f.outerWire()] + f.innerWires():
            pts = []
            for e in w.Edges():
                c = BRepAdaptor_Curve(e.wrapped)
                try:
                    d = GCPnts_QuasiUniformDeflection(c, 0.02)
                    seg = [c.Value(d.Parameter(k)) for k in range(1, d.NbPoints() + 1)]
                except Exception:
                    seg = [c.Value(c.FirstParameter()), c.Value(c.LastParameter())]
                seg = [(p.X(), p.Y(), p.Z()) for p in seg]
                if pts and np.linalg.norm(np.array(seg[-1]) - np.array(pts[-1])) < np.linalg.norm(np.array(seg[0]) - np.array(pts[-1])):
                    seg = seg[::-1]
                pts += seg
            loops.append(np.array(pts))
        faces.append(loops)
    return faces


class Sheet:
    def __init__(self, title, number, of, subtitle=""):
        self.fig = plt.figure(figsize=(A3[0] / 25.4, A3[1] / 25.4))
        self.ax = self.fig.add_axes([0, 0, 1, 1])
        self.ax.set_xlim(0, A3[0])
        self.ax.set_ylim(0, A3[1])
        self.ax.set_aspect("equal")
        self.ax.axis("off")
        a = self.ax
        a.add_patch(Rectangle((10, 10), A3[0] - 20, A3[1] - 20, fill=False, lw=0.8, ec=INK))
        # title block
        x0, y0, w, h = A3[0] - 10 - 150, 10, 150, 26
        a.add_patch(Rectangle((x0, y0), w, h, fill=False, lw=0.8, ec=INK))
        a.plot([x0, x0 + w], [y0 + 13, y0 + 13], color=INK, lw=0.5)
        a.plot([x0 + 105, x0 + 105], [y0, y0 + 26], color=INK, lw=0.5)
        a.text(x0 + 3, y0 + 18, title, fontsize=FS * 4.2, va="center", ha="left", weight="bold", color=INK)
        a.text(x0 + 3, y0 + 6.5, subtitle or "Sentinel enclosure rev 5 - final CAD (PETG, FDM)", fontsize=FS * 2.6, va="center",
               ha="left", color=INK)
        a.text(x0 + 108, y0 + 18, f"Sheet {number} / {of}", fontsize=FS * 3.0, va="center", ha="left", color=INK)
        a.text(x0 + 108, y0 + 6.5, "mm  |  A3", fontsize=FS * 2.6, va="center", ha="left", color=INK)
        self.views = {}

    # ---------------------------------------------------------------- placing views
    def place(self, key, view, origin, scale, shape=None, hidden=False, lw=0.45, lines=None, window=None, color=INK):
        """origin: paper position of model 2D (0, 0) for this view. window: (u0, u1, v0, v1) in view 2D model coords:
        everything drawn for this view is clipped to it."""
        self.views[key] = (view, np.array(origin, float), scale)
        self.clips = getattr(self, "clips", {})
        if window is not None:
            a = self.P(key, (window[0], window[2]))
            b = self.P(key, (window[1], window[3]))
            r = Rectangle((min(a[0], b[0]), min(a[1], b[1])), abs(b[0] - a[0]), abs(b[1] - a[1]), transform=self.ax.transData)
            self.clips[key] = r
            self.ax.add_patch(Rectangle((min(a[0], b[0]), min(a[1], b[1])), abs(b[0] - a[0]), abs(b[1] - a[1]), fill=False, ec="#b8c0c8",
                                        lw=0.4, ls=(0, (4, 2))))
        if shape is not None or lines is not None:
            vis, hid = lines if lines is not None else hlr(shape, view, hidden)
            for pl in hid:
                q = self.P(key, pl)
                ln, = self.ax.plot(q[:, 0], q[:, 1], color=HID, lw=0.25, ls=(0, (2.0, 1.2)))
                self._clip(key, ln)
            for pl in vis:
                q = self.P(key, pl)
                ln, = self.ax.plot(q[:, 0], q[:, 1], color=color, lw=lw, solid_capstyle="round")
                self._clip(key, ln)

    def _clip(self, key, artist):
        r = getattr(self, "clips", {}).get(key)
        if r is not None:
            artist.set_clip_path(r)

    def phantom(self, key, p3s, label=None, dxy=(4, 4)):
        """Bought part outline (chain line) for reference."""
        q = np.array([self.M(key, p) for p in p3s])
        ln, = self.ax.plot(q[:, 0], q[:, 1], color="#a0522d", lw=0.4, ls=(0, (6, 1.5, 1, 1.5)))
        self._clip(key, ln)
        if label:
            self.text(q[0] + np.array(dxy), label, size=FS * 0.75, ha="left", color="#a0522d")

    def P(self, key, pts2):
        _, o, s = self.views[key]
        return o + np.asarray(pts2, float) * s

    def M(self, key, p3):
        """Model 3D point -> paper."""
        view, o, s = self.views[key]
        return o + p2(view, p3) * s

    def section(self, key, faces, hatch="////"):
        view = self.views[key][0]
        for loops in faces:
            verts, codes = [], []
            for lp in loops:
                q = self.P(key, np.array([p2(view, p) for p in lp]))
                verts += list(q) + [q[0]]
                codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
            pp = PathPatch(Path(verts, codes), fc="#e9edf2", ec=INK, lw=0.6, hatch=hatch)
            self.ax.add_patch(pp)
            self._clip(key, pp)

    # ---------------------------------------------------------------- annotation
    def text(self, xy, s, size=FS, ha="center", va="center", color=INK, rot=0, weight="normal", z=6):
        self.ax.text(xy[0], xy[1], s, fontsize=size * 2.835, ha=ha, va=va, color=color, rotation=rot, weight=weight, zorder=z)

    def label(self, key, s, dy=-8, at=None):
        view, o, sc = self.views[key]
        self.text(at if at is not None else (o[0], o[1] + dy), s, size=FS * 1.15, ha="left", weight="bold")

    def dim(self, key, a3, b3, off, text=None, axis="h", tol=None, size=FS):
        """Linear dimension between model points a3, b3 measured along paper x ('h') or y ('v');
        the dimension line sits off paper-mm away (sign gives the side)."""
        a, b = self.M(key, a3), self.M(key, b3)
        s = self.views[key][2]
        if axis == "h":
            y = (min(a[1], b[1]) + off) if off < 0 else (max(a[1], b[1]) + off)
            pa, pb = np.array([a[0], y]), np.array([b[0], y])
            for p, q in ((a, pa), (b, pb)):
                self.ax.plot([p[0], q[0]], [p[1] + math.copysign(1.0, off), q[1] + math.copysign(1.5, off)], color=DIMC, lw=0.3)
            val = abs(b[0] - a[0]) / s
        else:
            x = min(a[0], b[0]) + off if off < 0 else max(a[0], b[0]) + off
            pa, pb = np.array([x, a[1]]), np.array([x, b[1]])
            for p, q in ((a, pa), (b, pb)):
                self.ax.plot([p[0] + math.copysign(1.0, off), q[0] + math.copysign(1.5, off)], [p[1], q[1]], color=DIMC, lw=0.3)
            val = abs(b[1] - a[1]) / s
        self._arrow_line(pa, pb)
        t = text if text is not None else fmt(val)
        if tol:
            t += tol
        mid = (pa + pb) / 2
        if axis == "h":
            self.text((mid[0], mid[1] + 1.6), t, size=size, va="bottom", color=DIMC)
        else:
            self.text((mid[0] - 1.6, mid[1]), t, size=size, va="center", ha="center", rot=90, color=DIMC)
        return val

    def _arrow_line(self, pa, pb):
        L = np.linalg.norm(pb - pa)
        if L < 1e-6:
            return
        if L < 7:            # short: arrows outside
            u = (pb - pa) / L
            self.ax.annotate("", xy=pa, xytext=pa - u * 4, arrowprops=dict(arrowstyle="-|>", lw=0.3, color=DIMC, mutation_scale=5))
            self.ax.annotate("", xy=pb, xytext=pb + u * 4, arrowprops=dict(arrowstyle="-|>", lw=0.3, color=DIMC, mutation_scale=5))
            self.ax.plot([pa[0], pb[0]], [pa[1], pb[1]], color=DIMC, lw=0.3)
        else:
            self.ax.annotate("", xy=pa, xytext=pb, arrowprops=dict(arrowstyle="<|-|>", lw=0.3, color=DIMC, mutation_scale=5,
                                                                   shrinkA=0, shrinkB=0))

    def ordinate(self, key, values, axis, at, origin_val=0.0, labels=None, size=FS * 0.9, side=-1, coord=None):
        """Ordinate dimensions: for each model coordinate value along x ('x' axis of the view) a tick line runs from the
        feature (coord gives the other model coordinate of each feature, in view 2D) to the baseline at paper position at."""
        view, o, s = self.views[key]
        for i, v in enumerate(values):
            lab = labels[i] if labels else fmt(v - origin_val)
            if axis == "x":
                px = o[0] + v * s
                y0 = o[1] + (coord[i] if coord is not None else 0) * s
                self.ax.plot([px, px], [y0, at], color=DIMC, lw=0.25, ls=(0, (1, 1)))
                self.text((px, at + side * 1.2), lab, size=size, rot=90, va="top" if side < 0 else "bottom", color=DIMC)
            else:
                py = o[1] + v * s
                x0 = o[0] + (coord[i] if coord is not None else 0) * s
                self.ax.plot([x0, at], [py, py], color=DIMC, lw=0.25, ls=(0, (1, 1)))
                self.text((at + side * 1.2, py), lab, size=size, ha="right" if side < 0 else "left", color=DIMC)

    def leader(self, key, p3, text, dxy, size=FS * 0.95, model2d=False):
        a = self.P(key, p3) if model2d else self.M(key, p3)
        b = a + np.array(dxy, float)
        self.ax.annotate("", xy=a, xytext=b, arrowprops=dict(arrowstyle="-|>", lw=0.3, color=DIMC, mutation_scale=5, shrinkA=0, shrinkB=0))
        ha = "left" if dxy[0] >= 0 else "right"
        self.ax.plot([b[0], b[0] + (3 if ha == "left" else -3)], [b[1], b[1]], color=DIMC, lw=0.3)
        self.text((b[0] + (3.6 if ha == "left" else -3.6), b[1]), text, size=size, ha=ha, color=DIMC)

    def note(self, xy, lines, size=FS * 0.95, width=None):
        y = xy[1]
        for ln in lines:
            self.text((xy[0], y), ln, size=size, ha="left", va="top")
            y -= size * 1.55

    def image(self, png, x0, y0, w, h=None):
        img = plt.imread(png)
        ih, iw = img.shape[:2]
        if h is None:
            h = w * ih / iw
        self.ax.imshow(img, extent=(x0, x0 + w, y0, y0 + h), zorder=0, interpolation="lanczos")
        self.ax.set_xlim(0, A3[0])
        self.ax.set_ylim(0, A3[1])
        return h

    def save(self, pdf=None, png=None, dpi=200):
        if pdf is not None:
            pdf.savefig(self.fig)
        if png:
            self.fig.savefig(png, dpi=dpi)
        plt.close(self.fig)


def fmt(v):
    v = round(float(v), 2)
    return f"{v:.2f}".rstrip("0").rstrip(".")


def tag(sheet, key, p3, label, dxy, r=2.6, model2d=False):
    """Circled feature tag with a leader to the feature."""
    a = sheet.P(key, p3) if model2d else sheet.M(key, p3)
    b = a + np.array(dxy, float)
    u = (a - b) / max(np.linalg.norm(a - b), 1e-9)
    sheet.ax.plot([b[0] + u[0] * r, a[0]], [b[1] + u[1] * r, a[1]], color=DIMC, lw=0.3)
    sheet.ax.plot([a[0]], [a[1]], marker="o", ms=1.2, color=DIMC)
    sheet.ax.add_patch(Circle(b, r, fill=True, fc="white", ec=DIMC, lw=0.5, zorder=5))
    sheet.text(b, label, size=FS * 0.82, color=DIMC, weight="bold")


def table(sheet, x0, y_top, cols, rows, size=FS * 0.82, row_h=4.6, head=True):
    """cols: list of (title, width). rows: list of tuples of strings. Returns the bottom y."""
    w = sum(c[1] for c in cols)
    y = y_top
    allrows = ([tuple(c[0] for c in cols)] if head else []) + list(rows)
    for i, r in enumerate(allrows):
        x = x0
        bold = head and i == 0
        if bold:
            sheet.ax.add_patch(Rectangle((x0, y - row_h), w, row_h, fc="#e8eef6", ec="none"))
        for (t, cw), cell in zip(cols, r):
            sheet.text((x + 1.2, y - row_h / 2), cell, size=size, ha="left", weight="bold" if bold else "normal")
            x += cw
        sheet.ax.plot([x0, x0 + w], [y - row_h, y - row_h], color="#9aa3ad", lw=0.25)
        y -= row_h
    sheet.ax.add_patch(Rectangle((x0, y), w, y_top - y, fill=False, ec=INK, lw=0.5))
    x = x0
    for t, cw in cols[:-1]:
        x += cw
        sheet.ax.plot([x, x], [y, y_top], color="#9aa3ad", lw=0.25)
    return y
