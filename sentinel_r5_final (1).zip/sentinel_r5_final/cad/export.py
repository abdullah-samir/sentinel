"""Exports: STL of every printed part in its print orientation, STEP of every part (assembly coordinates),
the full assembly as STEP and GLB, and a parts table (volume, size on the bed)."""
import json, os, math
import cadquery as cq
from cadquery import Vector as V
from assembly import printed_items, all_items
from coupon import build_coupon
from shelf import build_nic_rail
from params import *
from geom import nonmanifold_edges
import trimesh

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "deliverables")
STL, STEP = os.path.join(OUT, "stl"), os.path.join(OUT, "step")
os.makedirs(STL, exist_ok=True)
os.makedirs(STEP, exist_ok=True)
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)

# print orientation: flip = rotate 180 deg about x so the named face goes on the bed
PRINT = {
    "base": dict(file="sentinel_r5_base", flip=False, bed="floor", supports="none", qty=1),
    "lid": dict(file="sentinel_r5_lid", flip=True, bed="top face (outside)", supports="none", qty=1),
    "shelf": dict(file="sentinel_r5_shelf", flip=False, bed="shelf underside", supports="none", qty=1),
    "nrf_strap": dict(file="sentinel_r5_nrf_strap", flip=True, bed="strap top", supports="none", qty=1),
    "nrf_stop": dict(file="sentinel_r5_nrf_stop", flip=True, bed="bar top (pegs up)", supports="none", qty=1),
    "fan_spacers": dict(file="sentinel_r5_fan_spacers_x4", flip=False, bed="ring face", supports="none", qty=1),
    "nic_rail_l": dict(file="sentinel_r5_nic_rail_left", flip=False, bed="rail foot", supports="none", qty=1),
    "coupon": dict(file="sentinel_r5_fit_test_coupon", flip=False, bed="base plate", supports="none", qty=1),
}
for _v in NIC_PCB_W_VARIANTS:            # right rail: one version per WN722N board width, print the one that matches
    PRINT[f"nic_rail_r_w{_v:.1f}"] = dict(file=f"sentinel_r5_nic_rail_right_w{_v:.1f}", flip=False, bed="rail foot", supports="none",
                                          qty=1, board_w=_v)


def to_bed(shape, flip):
    """Returns the part in print orientation and the translation t such that bed = R(asm) + t,
    R = identity, or a 180 deg turn about x (x, -y, -z) when flipped."""
    s = shape
    if flip:
        s = s.rotate(V(0, 0, 0), V(1, 0, 0), 180)
    bb = s.BoundingBox(tolerance=1e-4)
    t = (-bb.xmin, -bb.ymin, -bb.zmin)
    return s.translate(V(*t)), t


def export_stl(shape, fn):
    cq.exporters.export(cq.Workplane().add(shape), fn, tolerance=0.01, angularTolerance=0.08)


def main():
    parts = {it.name: it.shape for it in printed_items()}
    spacers = [parts.pop(k) for k in sorted(list(parts)) if k.startswith("fan_spacer")]
    # lay the 4 spacers out on one plate
    sp = []
    for i, s in enumerate(spacers):
        bb = s.BoundingBox()
        sp.append(s.translate(V(-bb.xmin + (i % 2) * 10.0, -bb.ymin + (i // 2) * 10.0, -bb.zmin)))
    parts["fan_spacers"] = cq.Compound.makeCompound(sp)
    parts["coupon"] = build_coupon()
    parts.pop("nic_rail_r")                     # the assembly's right rail is the NIC_PCB_W version; export every version
    for v in NIC_PCB_W_VARIANTS:
        parts[f"nic_rail_r_w{v:.1f}"] = build_nic_rail("r", v)
    for d in (STL, STEP):                       # old files of parts that no longer exist (e.g. the single right rail)
        keep = {PRINT[k]["file"] for k in parts} | {"sentinel_r5_assembly"}
        for f in os.listdir(d):
            if os.path.splitext(f)[0] not in keep:
                os.remove(os.path.join(d, f))
    info = {}
    for k, shape in parts.items():
        meta = PRINT[k]
        bad = [e for s_ in shape.Solids() for e in nonmanifold_edges(s_)]
        if bad:
            raise RuntimeError(f"{k}: edges shared by more than two faces at {bad}")
        bed, t = to_bed(shape, meta["flip"])
        fn = os.path.join(STL, meta["file"] + ".stl")
        export_stl(bed, fn)
        cq.exporters.export(cq.Workplane().add(shape), os.path.join(STEP, meta["file"] + ".step"))
        m = trimesh.load(fn)
        vol = sum(s.Volume() for s in shape.Solids())
        info[k] = dict(file=meta["file"] + ".stl", bed=meta["bed"], supports=meta["supports"], qty=meta["qty"], board_w=meta.get("board_w"),
                       volume_cm3=round(vol / 1000, 4), size_mm=[round(float(e), 1) for e in m.extents],
                       bed_from_asm=dict(flip=meta["flip"], t=[round(v, 4) for v in t]) if k != "fan_spacers" else None)
        print(k, info[k])
    # assembly
    assy = cq.Assembly(name="sentinel_rev5")
    for it in all_items():
        if it.kind != "solid":
            continue
        h = it.color.lstrip("#")
        rgb = tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
        assy.add(cq.Workplane().add(it.shape), name=it.name.replace(".", "_"), color=cq.Color(*rgb, 1.0))
    assy.save(os.path.join(STEP, "sentinel_r5_assembly.step"))
    assy.save(os.path.join(OUT, "sentinel_r5_assembly.glb"), "GLTF", tolerance=0.05, angularTolerance=0.2)
    json.dump(info, open(os.path.join(HERE, "out", "parts.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
