"""Base: the main enclosure body (floor, walls, 5 mm antenna band, internal mounts). Printed floor-down."""
import math
import cadquery as cq
from cadquery import Vector as V
from params import *
from geom import *


# ------------------------------------------------------------------ shell
def outer_solid():
    o = rrect_prism(OUT["x0"], OUT["x1"], OUT["y0"], OUT["y1"], OUT["z0"], H, R_OUT)
    wp = cq.Workplane().add(o).faces("<Z").edges().chamfer(EDGE_CHAMFER)
    return S(wp)


def shell():
    outer = outer_solid()
    cav = rrect_prism(0, L, 0, W, 0, H + 5, R_IN)
    sh = outer.cut(cav)
    # 5 mm antenna band from the shelf up, 45 deg underside (prints without support)
    band = S(cq.Workplane("YZ", origin=(0, 0, 0)).polyline(
        [(REAR_IN, BAND_Z0), (REAR_IN, H), (W, H), (W, BAND_Z0 - BAND_CHAMFER)]).close().extrude(L))
    return sh.fuse(band).clean(), outer


# ------------------------------------------------------------------ lid posts (M3 x 8 inserts)
def lid_posts(outer):
    out = []
    for p in LID_POSTS:
        x, y, z0, d = p["x"], p["y"], p["z0"], p.get("d", LID_POST_D)
        r = d / 2
        post = cyl_z(x, y, z0, H, d)
        if p["wall"] == "front":                      # hangs from the front wall: 45 deg corbel below
            reach = y + r                             # distance from the wall's inner face (y = 0)
            zc = z0 - reach
            cor = cyl_z(x, y, zc - WALL, z0, d).intersect(
                S(cq.Workplane("YZ").polyline([(-WALL, zc - WALL), (reach + 0.01, z0 + 0.01), (-WALL, z0 + 0.01)]).close()
                  .extrude(L + 2 * WALL).translate((-WALL, 0, 0))))
            post = post.fuse(cor)
        elif p["wall"] == "band":                     # hangs from the band: corbel in front of it
            reach = REAR_IN - (y - r)
            zc = z0 - reach
            cor = cyl_z(x, y, zc, z0, d).intersect(
                S(cq.Workplane("YZ").polyline([(REAR_IN + 0.01, zc), (REAR_IN - reach - 0.01, z0 + 0.01), (REAR_IN + 0.01, z0 + 0.01)])
                  .close().extrude(L).translate((0, 0, 0))))
            post = post.fuse(cor)
        out.append(post.intersect(outer))
    return out


def lid_post_holes():
    return [cyl_z(p["x"], p["y"], H - INSERT_M3["depth"], H + 1, INSERT_M3["hole"]) for p in LID_POSTS] + \
           [cone_z(p["x"], p["y"], H - 0.6, H + 0.01, INSERT_M3["hole"], INSERT_M3["hole"] + 1.2) for p in LID_POSTS]


# ------------------------------------------------------------------ shelf supports
def shelf_supports():
    out = []
    top = SHELF_Z
    for y0, y1 in LEDGE_L_Y:
        out += [box(0, LEDGE_W, y0, y1, top - LEDGE_H, top), wedge_under_y(y0, y1, 0.0, LEDGE_W, top - LEDGE_H)]
    for y0, y1 in LEDGE_R_Y:
        out += [box(L - LEDGE_W, L, y0, y1, top - LEDGE_H, top), wedge_under_y(y0, y1, L, L - LEDGE_W, top - LEDGE_H)]
    (x0, y0), (x1, y1) = SHELF_POSTS
    out.append(cyl_z(x0, y0, 0, SHELF_Z, SHELF_POST_D))
    out.append(cone_z(x0, y0, 0, 3.0, SHELF_POST_D + 3.5, SHELF_POST_D))      # flared foot
    out.append(cyl_z(x1, y1, 0, SHELF_Z, SHELF_POST_D))
    out.append(box(x1, L, y1 - SHELF_POST_D / 2, y1 + SHELF_POST_D / 2, 0, SHELF_Z))   # merged with the right wall
    return out


def shelf_post_holes():
    return [cyl_z(x, y, SHELF_Z - INSERT_M3["depth"], SHELF_Z + 1, INSERT_M3["hole"]) for x, y in SHELF_POSTS]


# ------------------------------------------------------------------ Raspberry Pi standoffs (M2.5 x 4 inserts)
def pi_standoffs():
    return [cyl_z(x, y, 0, PI["z0"], PI_STANDOFF["d"]) for x, y in PI_HOLES]


def pi_standoff_holes():
    return [cyl_z(x, y, PI["z0"] - INSERT_M25["depth"], PI["z0"] + 1, INSERT_M25["hole"]) for x, y in PI_HOLES]


# ------------------------------------------------------------------ ESP32-S3 holder (bed, frame, snap lip)
def esp_holder():
    ex, ey = ESP["x0"], ESP["y0"]
    X = lambda a: ex + a
    Y = lambda b: ey + b
    zb = ESP_MOD["z"][0]                                  # 3.0: underside of the module shield and the USB-C shells
    out = [
        box(X(2.6), X(24.4), Y(0.5), Y(8.2), 0, zb),     # pad under both USB-C shells
        box(X(3.5), X(24.0), Y(40.0), Y(ESP_SHIELD_LY[1] - 0.5), 0, zb),   # pad under the shield
        box(X(-1.8), X(-0.3), Y(9.0), Y(54.0), 0, 7.5),  # left frame wall
        box(X(27.8), X(29.3), Y(9.0), Y(53.5), 0, 7.5),  # right frame wall (gap behind for the IPEX lead)
        box(X(27.8), X(29.3), Y(60.0), Y(64.0), 0, 7.5),
        box(X(-1.8), X(0.5), Y(-1.8), Y(-0.3), 0, 7.5),  # USB-end corner stops (clear of a 90 deg plug in either port)
        box(X(27.0), X(29.3), Y(-1.8), Y(-0.3), 0, 7.5),
        box(X(3.5), X(24.0), Y(ESP["l"] + 0.3), Y(ESP["l"] + 2.3), 0, ESP_END_TOP),        # end wall
        box(X(3.5), X(24.0), Y(ESP["l"] - 0.5), Y(ESP["l"] + 0.3), ESP_MOD["z"][1] + 0.4, ESP_END_TOP),   # snap lip over the module end
    ]
    return out


# ------------------------------------------------------------------ breadboard frame
def bb_frame():
    g, w, h = BB_RIM["gap"], BB_RIM["w"], BB_RIM["h"]
    x0, x1, y1 = BB["x0"] - g, BB["x1"] + g, BB["y1"] + g
    return [box(x0 - w, 81.0, y1, y1 + w, 0, h), box(x0 - w, x0, 0, y1, 0, h), box(x1, x1 + w, 0, y1, 0, h)]   # back rim stops at x 81 (USB-C plug)


# ------------------------------------------------------------------ PN532 slide-up holder (left wall)
def pn_holder():
    g = 0.3
    xo, xi = PN["x0"] - g, PN["x0"] + PN["t"] + g          # 0.9 / 3.1: slot faces
    return [
        box(0, xo, 0, 2.6, 0, 45.0), box(xi, xi + PN_WALL, 0, 2.6, 0, 45.0),      # front channel (full height)
        box(0, xo, 2.6, PN["y1"] + g, 0, 3.8), box(xi, xi + PN_WALL, 2.6, PN["y1"] + g, 0, 3.8),   # bottom groove
        box(xo, xi, 0, PN["y1"] + g, 0, PN["z0"]),                                 # floor ledge under the board
        box(0, xi + PN_WALL, PN["y1"] + g, PN["y1"] + g + 1.4, 0, 3.8),           # back stop, spans the groove walls (no edge-only joints)
        box(0, xo, PN["y1"] - 2.7, PN["y1"] + g, 3.8, PN["z1"]),                   # back rail behind the board
    ]


# ------------------------------------------------------------------ buzzer bracket (ears drop into slots)
def buzzer_bracket():
    cy, cz = BUZ["cy"], BUZ["cz"]
    ear0, ear1 = cz - BUZ["ear_w"] / 2, cz + BUZ["ear_w"] / 2      # 13.5 / 20.5
    top = ear1 + 3.5
    yf0, yf1 = cy - BUZ["ear_pitch"] / 2 - 4.0, cy - BUZ["d"] / 2 - 0.5     # front ear zone 3 .. 10
    yb0, yb1 = cy + BUZ["d"] / 2 + 0.5, cy + BUZ["ear_pitch"] / 2 + 4.0     # back ear zone 34 .. 41
    x_face = BUZ["x0"]                                                      # ears bear on x = 110
    lip0 = x_face + BUZ["ear_t"] + 0.3                                      # 112.3
    out = [box(106.5, x_face, yf0, yb1, 0, top).cut(box(106.4, x_face + 0.1, cy - 4.0, cy + 4.0, 8.0, top + 0.1))]   # plate, notch for the leads
    for (a, b, lip_a, lip_b, end) in ((yf0, yf1, yf0, yf1 - 0.5, (yf0 - BUZ_END_T, yf0)), (yb0, yb1, yb0 + 0.5, yb1, (yb1, yb1 + BUZ_END_T))):
        out.append(box(x_face, lip0 + BUZ_LIP_T, a, b, 0, ear0))            # block the ear rests on
        out.append(box(lip0, lip0 + BUZ_LIP_T, lip_a, lip_b, ear0, top))    # outer lip
        out.append(box(106.5, lip0 + BUZ_LIP_T, end[0], end[1], 0, top))    # slot end wall, runs into the plate (no edge-only joint)
    return out


# ------------------------------------------------------------------ KY-013 snap holder (back wall, below the band)
def ky_holder():
    """Ledge under the board + a guide at its left end; the board is held to the wall with foam tape.
    The right end stays open for its 3-pin header."""
    x0, x1, z0 = KY["x0"], KY["x1"], KY["z0"]
    yw = W                                   # back wall inner face below the band
    return [box(x0 - 1.6, x1 + 0.5, yw - 4.0, yw, z0 - 1.5, z0), wedge_under_x(x0 - 1.6, x1 + 0.5, yw, yw - 4.0, z0 - 1.5),
            box(x0 - 0.2 - KY_GUIDE_T, x0 - 0.2, KY["parts_y"][0] + 0.8, yw, z0 - 1.5, KY["z1"] - 3.0)]


# ------------------------------------------------------------------ openings in the walls
def wall_cuts():
    cuts = []
    e = 0.05
    # front wall: KCD11, lower and upper vents
    cw, ch = SW["cut"]
    cuts.append(box(SW["cx"] - cw / 2, SW["cx"] + cw / 2, -WALL - 1, e, SW["cz"] - ch / 2, SW["cz"] + ch / 2))
    for x0, z0, w, h in F_LOW + F_UP:
        cuts.append(box(x0, x0 + w, -WALL - 1, e, z0, z0 + h))
    # back wall below the band: exhaust slots, SD slot with a flared outer mouth
    for x0, z0, w, h in EXH:
        cuts.append(box(x0, x0 + w, W - e, OUT_Y + 1, z0, z0 + h))
    x0, x1, z0, z1 = SD_SLOT
    cuts.append(box(x0, x1, W - e, OUT_Y + 1, z0, z1))
    f = SD_FLARE                                   # mouth widens sideways and upward only: the floor edge stays whole
    flare = S(cq.Workplane("XZ", origin=(0, OUT_Y + 0.01, 0)).center((x0 + x1) / 2, (z0 + z1 + f["up"]) / 2)
              .rect(x1 - x0 + 2 * f["side"], z1 - z0 + f["up"])
              .workplane(offset=f["depth"]).center(0, -f["up"] / 2).rect(x1 - x0, z1 - z0).loft())
    cuts.append(flare)
    # left wall: power plug hole, vents
    y0, y1, z0, z1 = PWR
    cuts.append(box(-WALL - 1, e, y0, y1, z0, z1))
    for y0, z0, w, h in L_VENT:
        cuts.append(box(-WALL - 1, e, y0, y0 + w, z0, z0 + h))
    # right wall: vents, buzzer sound holes
    for y0, z0, w, h in R_VENT:
        cuts.append(box(L - e, L + WALL + 1, y0, y0 + w, z0, z0 + h))
    bh = BUZ_HOLES
    pts = [(BUZ["cy"], BUZ["cz"])] + [(BUZ["cy"] + bh["r"] * math.cos(math.radians(60 * k + 30)),
                                       BUZ["cz"] + bh["r"] * math.sin(math.radians(60 * k + 30))) for k in range(bh["n"])]
    for y, z in pts:
        cuts.append(cyl_x(y, z, L - e, L + WALL + 1, bh["d"]))
    return cuts


def antenna_cuts():
    cuts = []
    e = 0.05
    for h in HOLES:
        x = h["x"]
        if h["kind"] == "nrf":
            cuts.append(teardrop_y(x, ROW_Z, REAR_IN - e, OUT_Y + 1, NRF_HOLE))
            p = NRF_POCKET
            cuts.append(pocket_45_roof_y(x - p["w"] / 2, x + p["w"] / 2, REAR_IN, p["depth"], p["z0"], p["z0"] + p["h"]))
        else:
            cuts.append(teardrop_y(x, ROW_Z, REAR_IN - e, OUT_Y + 1, SMA["hole"]))
            cuts.append(teardrop_y(x, ROW_Z, REAR_IN - e, REAR_IN + SPOT_DEPTH, SMA["spot_d"]))
    return cuts


# ------------------------------------------------------------------ assemble
def build_base():
    sh, outer = shell()
    adds = lid_posts(outer) + shelf_supports() + pi_standoffs() + esp_holder() + bb_frame() + pn_holder() + \
        buzzer_bracket() + ky_holder()
    b = fuse_all(sh, adds)
    cuts = lid_post_holes() + shelf_post_holes() + pi_standoff_holes() + wall_cuts() + antenna_cuts()
    b = cut_all(b, cuts)
    return b


if __name__ == "__main__":
    import time
    t = time.time()
    b = build_base()
    print("valid", b.isValid(), "solids", len(b.Solids()), "volume cm3", round(b.Volume() / 1000, 1), "bbox", [round(v, 2) for v in bbox(b)],
          "t", round(time.time() - t, 1))
