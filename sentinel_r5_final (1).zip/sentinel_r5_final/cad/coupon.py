"""Fit-test coupon (about 1 h 45 min, 16 g): print it first and check the bought parts against it before the 14-16 h base.
Holds: SMA bulkhead hole + spot face in a 5 mm wall, nRF24 jack hole + pocket, KCD11 cut-out in a 2 mm wall,
a PBS-11A button hole in a 2 mm plate, a 20 mm piece of each NIC rail profile (slide the WN722N's antenna edge into the
left one and run its button edge along the right one: the plunger must pass the recess untouched), an M3 x 8 and an
M2.5 x 4 insert post."""
import cadquery as cq
from params import *
from geom import *


def build_coupon():
    W_, D_, T = 74.0, 36.0, 2.0
    plate = box(0, W_, 0, D_, 0, T)
    wall_y0 = D_ - 5.0
    wall5 = box(0, 46.0, wall_y0, D_, 0, 26.0)                 # 5 mm wall like the antenna band
    wall2 = box(46.0, W_, D_ - 2.0, D_, 0, 26.0)               # 2 mm wall like the front wall
    # NIC rail samples, 20 mm long, board level as in the rails: the left rail's wall with a support and a hold-down rib
    # (antenna edge), and the right rail's ledge, kerb and plunger recess (button edge); one board edge at a time
    r, t, g = NIC_RAIL, NIC_RAIL["rib"], NIC_RAIL["gap"]
    zp = 6.0                                                    # PCB bottom on the samples
    zs, zt = zp - r["sup_gap"], zp + 1.6 + r["hold_gap"]
    xw = 26.0                                                   # left sample: wall face
    xk, xr = 40.0, 40.0 + r["recess"]                           # right sample: kerb face, recess face
    prism = lambda pts: S(cq.Workplane("XZ", origin=(0, 2.0, 0)).polyline(pts).close().extrude(-20.0))
    rail = [box(23.0, xw, 2.0, 22.0, 0, 11.0),
            prism([(xw - 0.01, zs), (xw + t, zs), (xw - 0.01, zs - t - 0.01)]),
            prism([(xw - 0.01, zt - g), (xw + t, zt + t - g), (xw - 0.01, zt + t - g)]),
            box(xr, xr + 3.0, 2.0, 22.0, 0, 11.0),
            prism([(xr + 0.01, zs), (xk - t, zs), (xr + 0.01, zs - (xr - xk + t) - 0.01)]),
            box(xk, xr + 0.01, 2.0, 22.0, zs - 0.01, zp + r["kerb"])]
    posts = [cyl_z(55.0, 10.0, 0, 14.0, LID_POST_D), cyl_z(66.0, 10.0, 0, 8.0, PI_STANDOFF["d"])]
    c = fuse_all(plate, [wall5, wall2] + rail + posts)
    zc = 15.0
    cuts = [teardrop_y(11.0, zc, wall_y0 - 0.05, D_ + 1, SMA["hole"]), teardrop_y(11.0, zc, wall_y0 - 0.05, wall_y0 + SPOT_DEPTH, SMA["spot_d"]),
            teardrop_y(31.0, zc, wall_y0 - 0.05, D_ + 1, NRF_HOLE),
            pocket_45_roof_y(31.0 - NRF_POCKET["w"] / 2, 31.0 + NRF_POCKET["w"] / 2, wall_y0, NRF_POCKET["depth"],
                             zc - 1.45, zc - 1.45 + NRF_POCKET["h"]),
            box(60.0 - SW["cut"][0] / 2, 60.0 + SW["cut"][0] / 2, D_ - 3, D_ + 1, zc - SW["cut"][1] / 2, zc + SW["cut"][1] / 2),
            cyl_z(10.0, 12.0, -1, T + 1, BTN["hole"]),
            cyl_z(55.0, 10.0, 14.0 - INSERT_M3["depth"], 15.0, INSERT_M3["hole"]),
            cyl_z(66.0, 10.0, 8.0 - INSERT_M25["depth"], 9.0, INSERT_M25["hole"])]
    return cut_all(c, cuts)


if __name__ == "__main__":
    c = build_coupon()
    print("coupon", c.isValid(), len(c.Solids()), round(c.Volume() / 1000, 2), [round(v, 1) for v in bbox(c)])
