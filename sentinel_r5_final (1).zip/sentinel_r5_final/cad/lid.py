"""Lid: 2 mm plate with the screen window, 5 button holes, vents, locating lips and the screen's screw bosses.
Printed top face down (no supports)."""
import cadquery as cq
from params import *
from geom import *


def lip_segments():
    """Lips inside the walls, interrupted at the corners and around the lid posts."""
    w, h, g, c = LID_LIP["w"], LID_LIP["h"], LID_LIP["gap"], LID_LIP["corner"]
    z0, z1 = H - h, H
    r = LID_POST_D / 2 + 0.5           # every post is <= LID_POST_D
    segs = []
    # front (y 0.3..1.9): avoid the front posts
    fx = [(c, LID_POSTS[0]["x"] - r), (LID_POSTS[0]["x"] + r, LID_POSTS[1]["x"] - r)]
    for a, b in fx:
        segs.append(box(a, b, g, g + w, z0, z1))
    # back (in front of the band): avoid the rear posts
    by0, by1 = REAR_IN - g - w, REAR_IN - g
    bx = [(c, LID_POSTS[2]["x"] - r), (LID_POSTS[2]["x"] + r, LID_POSTS[3]["x"] - r)]
    for a, b in bx:
        segs.append(box(a, b, by0, by1, z0, z1))
    # left: full length between the corners
    segs.append(box(g, g + w, c, REAR_IN - c, z0, z1))
    # right: between the front-right and rear-right posts
    segs.append(box(L - g - w, L - g, LID_POSTS[1]["y"] + r, LID_POSTS[3]["y"] - r, z0, z1))
    return segs


def tft_bosses():
    out, holes = [], []
    for hx, hy in TFT_HOLES:
        x, y = TFT_X0 + hx, TFT_Y0 + hy
        out.append(cyl_z(x, y, TFT_TOP, H + 0.01, TFT_BOSS["d"]))
        holes.append(cyl_z(x, y, TFT_TOP - 0.1, TFT_TOP + TFT_BOSS["depth"], TFT_BOSS["pilot"]))
    return out, holes


def build_lid():
    plate = rrect_prism(OUT["x0"], OUT["x1"], OUT["y0"], OUT["y1"], H, H + LID_T, R_OUT)
    plate = S(cq.Workplane().add(plate).faces(">Z").edges().chamfer(EDGE_CHAMFER))      # top face prints on the bed
    bosses, pilots = tft_bosses()
    lid = fuse_all(plate, lip_segments() + bosses)
    cuts = []
    z0, z1 = H - 5, H + LID_T + 1
    ow, oh = OPEN
    cuts.append(box(GCX - ow / 2, GCX + ow / 2, GCY - oh / 2, GCY + oh / 2, z0, z1))
    for x, y in BTNS:
        cuts.append(cyl_z(x, y, z0, z1, BTN["hole"]))
    for x0, y0, w, l in LID_VENTS:
        cuts.append(box(x0, x0 + w, y0, y0 + l, z0, z1))
    for p in LID_POSTS:
        cuts.append(cyl_z(p["x"], p["y"], z0, z1, M3_CLEAR))
    lid = cut_all(lid, cuts + pilots)
    return lid


if __name__ == "__main__":
    l = build_lid()
    print("lid valid", l.isValid(), "solids", len(l.Solids()), "vol cm3", round(l.Volume() / 1000, 1), [round(v, 2) for v in bbox(l)])
