"""Slices every exported STL with PrusaSlicer 2.7 (command line) to get filament use and print time.

Printer/material base: PrusaSlicer's bundled Creality profiles ('Creality Ender-3 V2 (0.4 mm nozzle)',
'0.20 mm NORMAL (0.4 mm nozzle) @CREALITY', 'Generic PETG @CREALITY'), flattened from the vendor bundle, then the
part settings below are applied on top. The times are the slicer's estimate for that stock profile (500 mm/s2,
25-50 mm/s); a faster printer will be quicker. Writes the flattened settings to deliverables/slicer/*.ini,
G-code to out/gcode/ and the results to out/slice.json.
"""
import configparser, json, os, re, subprocess, sys
from params import NIC_PCB_W, NIC_PCB_W_VARIANTS

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = "/usr/share/PrusaSlicer/profiles/Creality.ini"
PRESETS = dict(printer="Creality Ender-3 V2 (0.4 mm nozzle)", print="0.20 mm NORMAL (0.4 mm nozzle) @CREALITY",
               filament="Generic PETG @CREALITY")
SPEEDS = {"normal": "0.20 mm NORMAL (0.4 mm nozzle) @CREALITY",          # 40/25/50 mm/s perimeters/outer/infill (recommended)
          "speed": "0.20 mm NORMAL SPEED (0.4 mm nozzle) @CREALITY"}     # 60/30/60 mm/s
DROP = ("inherits", "renamed_from", "alias", "compatible_printers", "compatible_printers_condition", "compatible_prints",
        "compatible_prints_condition")

# Settings for this enclosure (PETG, functional part, no supports)
COMMON = dict(perimeters=4, top_solid_layers=5, bottom_solid_layers=4, fill_density="25%", fill_pattern="gyroid",
              support_material=0, support_material_auto=0, brim_width=0, seam_position="rear",
              first_layer_temperature=240, temperature=240, first_layer_bed_temperature=80, bed_temperature=75,
              min_fan_speed=20, max_fan_speed=50, bridge_fan_speed=100, overhangs=1, ensure_vertical_shell_thickness=1,
              xy_size_compensation=0, elefant_foot_compensation=0.1, layer_height=0.2, first_layer_height=0.2)
SMALL = dict(COMMON, fill_density="100%", fill_pattern="rectilinear")
RAILS = dict(SMALL, brim_width=5)       # tall thin parts: a 5 mm brim keeps them from rocking on the bed
PARTS = {   # stl name -> (settings, note)
    "sentinel_r5_base": (COMMON, "floor on the bed"),
    "sentinel_r5_lid": (COMMON, "outside face on the bed (smooth face from the bed surface)"),
    "sentinel_r5_shelf": (COMMON, "plate underside on the bed"),
    "sentinel_r5_nrf_strap": (SMALL, "strap top on the bed, tab up"),
    "sentinel_r5_nrf_stop": (SMALL, "bar top on the bed, pegs up"),
    "sentinel_r5_fan_spacers_x4": (SMALL, "4 rings, flat"),
    "sentinel_r5_nic_rail_left": (RAILS, "rail foot on the bed (upright), 5 mm brim"),
    "sentinel_r5_fit_test_coupon": (COMMON, "base plate on the bed - print and check this first"),
}
for _v in NIC_PCB_W_VARIANTS:       # one right rail per board width; only the one that matches the boards is printed
    PARTS[f"sentinel_r5_nic_rail_right_w{_v:.1f}"] = (RAILS, f"rail foot on the bed (upright), 5 mm brim; for a {_v:.1f} mm board")
RIGHT_IN_TOTAL = f"sentinel_r5_nic_rail_right_w{NIC_PCB_W:.1f}"      # the version counted in the enclosure total


def load_vendor():
    cp = configparser.ConfigParser(interpolation=None, strict=False)
    cp.optionxform = str
    cp.read(VENDOR, encoding="utf-8")
    return cp


def resolve(cp, typ, name):
    sec = cp[f"{typ}:{name}"]
    out = {}
    for parent in [p.strip() for p in sec.get("inherits", "").split(";") if p.strip()]:
        out.update(resolve(cp, typ, parent))
    out.update({k: v for k, v in sec.items() if k not in DROP})
    return out


def flat_config(print_preset):
    cp = load_vendor()
    cfg = {}
    for typ in ("printer", "filament", "print"):
        cfg.update(resolve(cp, typ, print_preset if typ == "print" else PRESETS[typ]))
    return cfg


def write_ini(cfg, fn):
    with open(fn, "w") as f:
        f.write(f"# Sentinel rev 5 - PrusaSlicer 2.7 settings flattened from {PRESETS}\n")
        for k in sorted(cfg):
            f.write(f"{k} = {cfg[k]}\n")


def footer(gcode):
    txt = open(gcode, errors="ignore").read()[-60000:]
    def g(pat):
        m = re.search(pat, txt)
        return m.group(1).strip() if m else None
    return dict(time=g(r"estimated printing time \(normal mode\) = (.+)"), filament_mm=g(r"filament used \[mm\] = ([\d.]+)"),
                filament_cm3=g(r"filament used \[cm3\] = ([\d.]+)"), filament_g=g(r"filament used \[g\] = ([\d.]+)"),
                cost=g(r"filament cost = ([\d.]+)"))


def to_min(t):
    if not t:
        return None
    d = {u: n for n, u in re.findall(r"(\d+)([dhms])", t)}
    return int(d.get("d", 0)) * 1440 + int(d.get("h", 0)) * 60 + int(d.get("m", 0)) + int(d.get("s", 0)) / 60


def main():
    os.makedirs(os.path.join(HERE, "deliverables", "slicer"), exist_ok=True)
    os.makedirs(os.path.join(HERE, "out", "gcode"), exist_ok=True)
    res = {}
    for sp, preset in SPEEDS.items():
        base = flat_config(preset)
        res[sp] = {}
        for name, (over, note) in PARTS.items():
            cfg = dict(base)
            cfg.update({k: str(v) for k, v in over.items()})
            kind = {id(SMALL): "small_parts", id(RAILS): "nic_rails"}.get(id(over), "main_parts")
            ini = os.path.join(HERE, "deliverables", "slicer", f"sentinel_r5_PETG_0.20_{kind}_{sp}.ini")
            write_ini(cfg, ini)
            stl = os.path.join(HERE, "deliverables", "stl", name + ".stl")
            gc = os.path.join(HERE, "out", "gcode", f"{name}_{sp}.gcode")
            info = subprocess.run(["prusa-slicer", "--info", stl], capture_output=True, text=True, timeout=600).stdout
            r = subprocess.run(["prusa-slicer", "--load", ini, "--export-gcode", "--output", gc, stl], capture_output=True,
                               text=True, timeout=3600)
            warn = [ln for ln in (r.stdout + r.stderr).splitlines() if re.search(r"warn|error|empty|detected|stability", ln, re.I)]
            f = footer(gc) if os.path.exists(gc) else {}
            f.update(minutes=to_min(f.get("time")), returncode=r.returncode, warnings=warn, orientation=note,
                     settings=kind, prusa_info=[ln.strip() for ln in info.splitlines() if "=" in ln])
            res[sp][name] = f
            print(sp, name, f["time"], f.get("filament_g"), "g", f.get("filament_mm"), "mm", "rc", r.returncode, warn[:3])
        parts = {k: v for k, v in res[sp].items() if "coupon" not in k and ("rail_right" not in k or k == RIGHT_IN_TOTAL)}
        tot_min = sum(v["minutes"] or 0 for v in parts.values())
        res[sp]["_total_enclosure"] = dict(minutes=round(tot_min, 1), hours=round(tot_min / 60, 2),
                                           filament_g=round(sum(float(v["filament_g"] or 0) for v in parts.values()), 1),
                                           filament_m=round(sum(float(v["filament_mm"] or 0) for v in parts.values()) / 1000, 2))
        res[sp]["_total_enclosure"]["right_rail_counted"] = RIGHT_IN_TOTAL
        print(sp, "enclosure total (without the coupon, one right rail):", res[sp]["_total_enclosure"])
    res["vent_comparison"] = vent_comparison()
    res["_settings"] = dict(presets=PRESETS, speeds=SPEEDS, common=COMMON, small=SMALL, rails=RAILS)
    json.dump(res, open(os.path.join(HERE, "out", "slice.json"), "w"), indent=1)


def vent_comparison():
    """Slices the shelf a second time without the vent holes (same settings) so the gram/time effect of the
    vents is on record. The no-vent STL goes to out/, not to the deliverables."""
    from shelf import build_shelf
    from export import to_bed, export_stl
    stl = os.path.join(HERE, "out", "shelf_no_vents.stl")
    export_stl(to_bed(build_shelf(vents=False), False)[0], stl)
    cfg = flat_config(SPEEDS["normal"])
    cfg.update({k: str(v) for k, v in COMMON.items()})
    ini = os.path.join(HERE, "out", "shelf_no_vents.ini")
    write_ini(cfg, ini)
    gc = os.path.join(HERE, "out", "gcode", "shelf_no_vents_normal.gcode")
    r = subprocess.run(["prusa-slicer", "--load", ini, "--export-gcode", "--output", gc, stl], capture_output=True,
                       text=True, timeout=3600)
    f = footer(gc) if os.path.exists(gc) else {}
    f.update(minutes=to_min(f.get("time")), returncode=r.returncode)
    print("shelf without vents (normal):", f.get("time"), f.get("filament_g"), "g")
    return dict(no_vents_normal=f, note="same shelf, build_shelf(vents=False), sliced with the main_parts normal settings")


if __name__ == "__main__":
    main()
