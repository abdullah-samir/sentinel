"""Rendered views of the full assembly (OpenSCAD, from the CAD meshes): closed, lid off, cut-away and exploded.
Writes deliverables/views/*.png."""
import os, sys
import numpy as np
from assembly import all_items, explode_offset
from render import render, stl_of

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "deliverables", "views")
os.makedirs(OUT, exist_ok=True)
SIZE = (2400, 1700)


def entries(items, explode=False, skip=()):
    out = []
    for it in items:
        if it.kind != "solid" or any(it.name.startswith(s) for s in skip):
            continue
        off = explode_offset(it.name) if explode else (0, 0, 0)
        out.append(dict(file=stl_of(it.shape, it.name), color=it.color, offset=off))
    return out


def main():
    items = all_items()
    for f in os.listdir(OUT):
        if f.endswith(".scad"):
            os.remove(os.path.join(OUT, f))
    lid_parts = ("lid", "tft", "btn", "tft_screw", "lid_screw")
    c = np.array([61.5, 72.5, 28.0])

    def cam(d, dist, cc=c):
        d = np.array(d, float) / np.linalg.norm(d)
        return tuple(cc + d * dist), tuple(cc)
    e_all = entries(items)
    eye, cen = cam((0.9, -1.25, 0.95), 420)
    render(e_all, os.path.join(OUT, "assembled_closed_front.png"), eye, cen, SIZE)
    eye, cen = cam((-0.75, 1.3, 0.8), 430)
    render(e_all, os.path.join(OUT, "assembled_closed_back.png"), eye, cen, SIZE)
    e_open = entries(items, skip=lid_parts)
    eye, cen = cam((0.55, -0.9, 1.25), 400)
    render(e_open, os.path.join(OUT, "assembled_lid_off.png"), eye, cen, SIZE)
    e_floor = entries(items, skip=lid_parts + ("shelf", "fan", "wn", "socket", "strap", "nrf", "nic_rail", "ant1", "ant2", "coax", "shelf_screw"))
    render(e_floor, os.path.join(OUT, "floor_level_shelf_off.png"), eye, cen, SIZE)
    # cut-away: everything right of x = 61.5 removed, seen from the right
    eye, cen = cam((1.0, -0.35, 0.3), 360)
    render(e_all, os.path.join(OUT, "cutaway_x61.png"), eye, cen, SIZE, clip=(-5, 61.5, -5, 175, -5, 180))
    e_exp = entries(items, explode=True)
    cc = np.array([61.5, 80.0, 95.0])
    eye, cen = cam((0.95, -1.3, 0.75), 760, cc)
    render(e_exp, os.path.join(OUT, "exploded.png"), eye, cen, (2400, 2000))
    for f in os.listdir(OUT):                       # keep only the pictures
        if f.endswith(".scad"):
            os.remove(os.path.join(OUT, f))
    print("views written to", OUT)


if __name__ == "__main__":
    main()
