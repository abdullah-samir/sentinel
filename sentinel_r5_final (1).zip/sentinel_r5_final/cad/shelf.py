"""Radio shelf (plate + nRF24 cradle + pegs for the removable NIC rails), the two NIC rails (the right one in a version per
board width) and the small loose printed parts. The shelf prints plate-down, the rails foot-down."""
import math
import cadquery as cq
from shapely.geometry import Polygon, Point, box as sbox
from shapely.ops import unary_union
from params import *
from geom import *


def plate_outline():
    x0, x1 = SHELF_X
    return [(x0, SHELF_FRONT_L), (SHELF_STEP_X, SHELF_FRONT_L), (SHELF_STEP_X, SHELF_FRONT_R), (NIC_PLATE_X, SHELF_FRONT_R),
            (NIC_PLATE_X, NIC_PLATE_Y0), (x1, NIC_PLATE_Y0), (x1, RR_NOTCH[1]), (CUT[1], RR_NOTCH[1]), (CUT[1], CUT[2]),
            (CUT[0], CUT[2]), (CUT[0], SHELF_BACK), (x0, SHELF_BACK)]


def fan_holes():
    p = FAN["pitch"] / 2
    return [(FAN["cx"] + dx, FAN["cy"] + dy) for dx in (-p, p) for dy in (-p, p)]


# ------------------------------------------------------------------ NIC rails (separate, removable) and their pegs
def nic_pegs():
    p = NIC_PEG
    out = []
    for x, y in NIC_PEGS:
        out.append(cyl_z(x, y, ST - 0.01, ST + p["h"] - p["chamfer"], p["d"]))
        out.append(cone_z(x, y, ST + p["h"] - p["chamfer"] - 0.01, ST + p["h"], p["d"], p["d"] - 2 * p["chamfer"]))
    return out


def _prism(pts, y0, y1):
    """Polygon in the XZ plane (x, z) extruded from y0 to y1."""
    return S(cq.Workplane("XZ", origin=(0, y0, 0)).polyline(pts).close().extrude(-(y1 - y0)))


def build_nic_rail(side, w=None):
    """One rail for the two WN722N boards (assembly coordinates); the boards slide in and out at the back, and a block at
    the front end stops them 0.2 mm in front of their PCB edge. Printed foot-down without support (45 deg undersides).
    Left rail (antenna side): each board edge runs between a support rib and a hold-down rib, 2.0 mm over the board.
    Right rail (button side), made for a board of width w: each board edge rests on a ledge 2.0 mm under the board, a kerb
    rising 1.2 above the PCB underside stops it sideways, and above the kerb a 1.4 mm recess leaves room for the button's
    1 mm plunger along the whole sliding path; nothing reaches over the board. Two peg holes locate each rail on the shelf;
    the lid holds them down (right rail under the lid's lip, left rail by two posts)."""
    r, t, p = NIC_RAIL, NIC_RAIL["rib"], NIC_PEG
    y0 = r["y0"]
    fw, fh = r["flange"]
    adds = []
    if side == "l":
        x0, xw = r["wl"]
        y1, top, pegs, idx = r["y1_l"], r["top"], NIC_PEGS[:2], (0, 1)
        g = r["gap"]
        wall = box(x0, xw, y0, y1, ST, top)
        for zp in WN_PCB_Z:
            zs, zt = zp - r["sup_gap"], zp + 1.6 + r["hold_gap"]     # support top under the PCB; hold-down over its nominal edge
            adds.append(_prism([(xw - 0.01, zs), (xw + t, zs), (xw - 0.01, zs - t - 0.01)], y0, y1))
            adds.append(_prism([(xw - 0.01, zt - g), (xw + t, zt + t - g), (xw - 0.01, zt + t - g)], y0, y1))
        adds.append(box(xw - 0.01, xw + fw, y0, y1, ST, ST + fh))
        adds.append(box(xw - 0.01, xw + 1.9, y0, r["stop_y1"], ST, top))     # front stop
        for ly in r["lidstop_y"]:
            adds.append(box(x0, xw, ly - r["lidstop_l"] / 2, ly + r["lidstop_l"] / 2, top - 0.01, r["lidstop_top"]))
        trim = box(x0 - 6.0, xw + 4.0, y0 - 3.0, y1, ST, H)
    else:
        gr = nic_right(w)
        xk, xr, xo = gr["kerb"], gr["recess"], gr["outer"]
        y1, top, pegs, idx = r["y1_r"], r["top_r"], NIC_PEGS[2:], (2, 3)
        wall = box(xr, xo, y0, y1, ST, top)
        reach = xr - (xk - t)                                       # ledge from the recess face to 2.0 inside the kerb face
        for zp in WN_PCB_Z:
            zs = zp - r["sup_gap"]
            adds.append(_prism([(xr + 0.01, zs), (xk - t, zs), (xr + 0.01, zs - reach - 0.01)], y0, y1))   # ledge
            adds.append(box(xk, xr + 0.01, y0, y1, zs - 0.01, zp + r["kerb"]))                              # kerb
        adds.append(box(xr - fw, xr + 0.01, y0, y1, ST, ST + fh))
        adds.append(box(xk - 1.7, xr + 0.01, y0, r["stop_y1"], ST, top))     # front stop
        trim = box(xk - 6.0, SHELF_X[1], y0 - 3.0, y1, ST, H)                  # also trims the bosses at the shelf's right edge
    low = [i in NIC_PEG_LOW for i in idx]          # a low boss sits under the boards' parts; its hole goes through
    for (x, y), lw in zip(pegs, low):
        adds.append(cyl_z(x, y, ST, ST + (p["boss_h_low"] if lw else p["boss_h"]), p["boss_d"]))
    rail = fuse_all(wall, adds)
    cuts = []
    for (x, y), lw in zip(pegs, low):
        cuts.append(cyl_z(x, y, ST - 0.1, ST + (p["boss_h_low"] + 0.3 if lw else p["hole_depth"]), p["hole"]))
        cuts.append(cone_z(x, y, ST - 0.01, ST + 0.4, p["hole"] + 0.8, p["hole"]))     # lead-in
    if side == "r":                                 # windows behind the right-wall vents, below the upper ledge's root
        ztop = min(48.0, WN_PCB_Z[1] - r["sup_gap"] - reach - 0.3)
        for vy, _, vw, _ in R_VENT:
            cuts.append(box(xr - 0.5, xo + 0.5, vy, vy + vw, 39.5, ztop))
    rail = cut_all(rail, cuts)
    return S(rail.intersect(trim))


# ------------------------------------------------------------------ vent / lightening holes in the plate
def vent_keepout():
    """Areas of the plate that stay solid: a 6 mm border on every edge, the fan footprint, posts, slot, stop bar,
    cradle, NIC rail feet and pegs, and the front lip."""
    e = SHELF_VENTS["edge"]
    keep = [sbox(FAN["cx"] - FAN["s"] / 2 - 3, FAN["cy"] - FAN["s"] / 2 - 3, FAN["cx"] + FAN["s"] / 2 + 3, FAN["cy"] + FAN["s"] / 2 + 3)]
    keep += [Point(x, y).buffer(9.0) for x, y in SHELF_POSTS]
    keep.append(sbox(SLOT[0], SLOT[2], SLOT[1], SLOT[3]).buffer(4.0))
    keep.append(sbox(NRF_X[0] - 9.5, NRF_STOP["y0"], NRF_X[1] + 9.5, NRF_STOP["y1"]).buffer(4.0))
    keep.append(sbox(SHELF_X[0], CRADLE["y0"], CUT[0], CRADLE["y1"]).buffer(4.0))
    keep.append(sbox(SHELF_LIP[0], SHELF_LIP[2], SHELF_LIP[1], SHELF_LIP[3]).buffer(4.0))
    r = NIC_RAIL
    keep.append(sbox(r["wl"][0] - 3.0, r["y0"] - 2, r["wl"][1] + r["flange"][0] + 0.5, r["y1_l"] + 3))
    xr_min = min(nic_right(v)["recess"] for v in NIC_PCB_W_VARIANTS)        # widest right rail (narrowest board)
    keep.append(sbox(xr_min - r["flange"][0] - 2.5, r["y0"] - 2, SHELF_X[1], r["y1_r"] + 3))
    keep += [Point(x, y).buffer(NIC_PEG["boss_d"] / 2 + 3.0) for x, y in NIC_PEGS]
    keep += [Point(x, y).buffer(6.0) for x, y in fan_holes()]
    return unary_union(keep), Polygon(plate_outline()).buffer(-e, join_style=2)


def vent_holes():
    """Hexagonal holes on a triangular grid; a hole is kept only if it lies wholly inside the allowed area."""
    v = SHELF_VENTS
    af, web = v["af"], v["web"]
    rc = af / math.sqrt(3)                          # circumradius (pointy along x)
    d = af + web                                    # centre spacing across flats
    keep, inner = vent_keepout()
    allowed = inner.difference(keep)
    out = []
    xs = [SHELF_X[0] + i * d * math.cos(math.radians(30)) for i in range(0, 20)]
    for i, x in enumerate(xs):
        for j in range(-2, 20):
            y = NIC_PLATE_Y0 + j * d + (d / 2 if i % 2 else 0.0)
            hexp = Polygon([(x + rc * math.cos(math.radians(60 * k)), y + rc * math.sin(math.radians(60 * k))) for k in range(6)])
            if allowed.contains(hexp) and any(x0 <= x <= x1 and y0 <= y <= y1 for x0, x1, y0, y1 in v["zones"]):
                out.append((x, y))
    return out


def vent_cuts():
    rc = SHELF_VENTS["af"] / math.sqrt(3)
    cuts = []
    for x, y in vent_holes():
        pts = [(x + rc * math.cos(math.radians(60 * k)), y + rc * math.sin(math.radians(60 * k))) for k in range(6)]
        cuts.append(S(cq.Workplane("XY", origin=(0, 0, SHELF_Z - 0.1)).polyline(pts).close().extrude(SHELF_T + 0.2)))
    return cuts


def cradle_parts():
    c = CRADLE
    xa, xb = SHELF_X[0], CUT[0]
    out = [box(xa, xb, c["y0"], c["y1"], ST, c["top"])]
    gaps = [(x - 8.05, x + 8.05) for x in NRF_X]          # 16.1 wide channels for the 15.5 modules
    edges = [xa] + [v for g in gaps for v in g] + [xb]
    for i in range(0, len(edges), 2):
        out.append(box(edges[i], edges[i + 1], c["y0"], c["y1"], ST, c["wall_top"]))
    return out


def cradle_cuts():
    c = CRADLE
    sx, sy = STRAP["screw"]
    cuts = [cyl_z(sx, sy, c["wall_top"] - INSERT_M3["depth"], c["wall_top"] + 1, INSERT_M3["hole"]),
            cone_z(sx, sy, c["wall_top"] - 0.6, c["wall_top"] + 0.01, INSERT_M3["hole"], INSERT_M3["hole"] + 1.2)]
    # groove under each module's jack (it hangs 2.5 below the PCB) so the module can slide back over the block
    for x in NRF_X:
        cuts.append(box(x - 3.75, x + 3.75, c["y0"] - 0.1, c["y1"] + 0.1, ROW_Z - 3.25 - 0.5, c["top"] + 0.1))
    # notch through the right wall for the strap's locating tab (stops the strap turning about its screw)
    x2 = NRF_X[1] + 8.05
    n, sy = STRAP_NOTCH, STRAP["screw"][1]
    cuts.append(box(x2 - 0.1, CUT[0] + 0.1, sy - n["w"] / 2, sy + n["w"] / 2, c["wall_top"] - n["depth"], c["wall_top"] + 0.1))
    return cuts


def plate_cuts():
    cuts = []
    zb, zt = SHELF_Z - 0.1, ST + 0.1
    cuts.append(cyl_z(FAN["cx"], FAN["cy"], zb, zt, FAN_OPEN_D))
    x0, x1, y0, y1 = SLOT
    cuts.append(box(x0, x1, y0, y1, zb, zt))
    for x, y in SHELF_POSTS:
        cuts.append(cyl_z(x, y, zb, zt, M3_CLEAR))
    for x, y in fan_holes():
        cuts.append(cyl_z(x, y, zb, zt, M3_CLEAR))
        cuts.append(cone_z(x, y, ST - M3_CSK["h"] - 0.1, ST + 0.01, M3_CLEAR - 0.2, M3_CSK["d"] + 0.4))   # countersink, head flush
    for px in NRF_STOP["pegs"]:
        cuts.append(cyl_z(px, (NRF_STOP["y0"] + NRF_STOP["y1"]) / 2, zb, zt, NRF_STOP["peg_d"] + 0.3))
    return cuts


def build_shelf(vents=True):
    plate = S(cq.Workplane("XY", origin=(0, 0, SHELF_Z)).polyline(plate_outline()).close().extrude(SHELF_T))
    x0, x1, y0, y1, hh = SHELF_LIP
    adds = [box(x0, x1, y0, y1, ST, ST + hh)] + cradle_parts() + nic_pegs()
    sh = fuse_all(plate, adds)
    sh = cut_all(sh, plate_cuts() + cradle_cuts() + (vent_cuts() if vents else []))
    return sh


# ------------------------------------------------------------------ loose printed parts (assembly coordinates)
def build_nrf_strap():
    st = STRAP
    c = CRADLE
    y0, y1 = st["screw"][1] - st["w"] / 2, st["screw"][1] + st["w"] / 2
    bar = box(st["x0"], st["x1"], y0, y1, c["wall_top"], c["wall_top"] + st["t"])
    x2 = NRF_X[1] + 8.05
    n, g = STRAP_NOTCH, STRAP_NOTCH["gap"]
    sy = st["screw"][1]
    tab = box(x2 + g, CUT[0] - 0.1, sy - n["w"] / 2 + g, sy + n["w"] / 2 - g, c["wall_top"] - n["depth"] + 0.3, c["wall_top"])
    bar = bar.fuse(tab).clean()
    sx, sy = st["screw"]
    return S(bar.cut(cyl_z(sx, sy, c["wall_top"] - 1, c["wall_top"] + st["t"] + 1, M3_CLEAR)))


def build_nrf_stop():
    s = NRF_STOP
    bar = box(NRF_X[0] - 9.5, NRF_X[1] + 9.5, s["y0"], s["y1"], ST, ST + s["h"])
    yc = (s["y0"] + s["y1"]) / 2
    pegs = [cyl_z(px, yc, SHELF_Z + 0.2, ST + 0.01, s["peg_d"]) for px in s["pegs"]]
    return fuse_all(bar, pegs)


def build_fan_spacers():
    sp = FAN_SPACER
    z0 = FAN_Z0 + FAN["t"]
    out = []
    for x, y in fan_holes():
        out.append(cyl_z(x, y, z0, z0 + sp["h"], sp["od"]).cut(cyl_z(x, y, z0 - 1, z0 + sp["h"] + 1, sp["id"])))
    return out


if __name__ == "__main__":
    import time
    t = time.time()
    s = build_shelf()
    print("shelf valid", s.isValid(), "solids", len(s.Solids()), "vol cm3", round(s.Volume() / 1000, 2), [round(v, 2) for v in bbox(s)], round(time.time() - t, 1))
    print("vent holes", len(vent_holes()))
    for sd in "lr":
        rl = build_nic_rail(sd)
        print("rail", sd, rl.isValid(), len(rl.Solids()), round(rl.Volume() / 1000, 2), [round(v, 2) for v in bbox(rl)])
    for n, f in (("strap", build_nrf_strap), ("stop", build_nrf_stop)):
        p = f()
        print(n, p.isValid(), len(p.Solids()), round(p.Volume(), 1), [round(v, 2) for v in bbox(p)])
    print("spacers", [round(sp.Volume(), 1) for sp in build_fan_spacers()])
