"""Full assembly: printed parts + bought parts, the fitting sequence with each part's installation motion,
and the exploded-view offsets."""
from bought import Item, all_bought
from base import build_base
from shelf import build_shelf, build_nrf_strap, build_nrf_stop, build_fan_spacers, build_nic_rail
from lid import build_lid
from params import *

PRINT_COLORS = {"base": "#5b6770", "shelf": "#8a96a0", "lid": "#5b6770", "nrf_strap": "#c07a2c", "nrf_stop": "#c07a2c",
                "fan_spacer": "#c07a2c", "nic_rail": "#c07a2c"}


def printed_items():
    it = [Item("base", build_base(), PRINT_COLORS["base"], stage="0 base"),
          Item("shelf", build_shelf(), PRINT_COLORS["shelf"], stage="10 shelf"),
          Item("nrf_stop", build_nrf_stop(), PRINT_COLORS["nrf_stop"], stage="14 stop+strap"),
          Item("nrf_strap", build_nrf_strap(), PRINT_COLORS["nrf_strap"], stage="14 stop+strap"),
          Item("lid", build_lid(), PRINT_COLORS["lid"], stage="16 lid"),
          Item("nic_rail_l", build_nic_rail("l"), PRINT_COLORS["nic_rail"], stage="11b NIC stack"),
          Item("nic_rail_r", build_nic_rail("r"), PRINT_COLORS["nic_rail"], stage="11b NIC stack")]
    for i, s in enumerate(build_fan_spacers()):
        it.append(Item(f"fan_spacer{i}", s, PRINT_COLORS["fan_spacer"], stage="10 shelf"))
    return it


def all_items():
    return printed_items() + all_bought()


# Fitting sequence. Each step: the items it installs (name prefixes) and how they move into place.
#   ("lower", h)        straight down from h mm above the final position
#   ("push", (dx,dy,dz)) along this vector, ending at the final position (starts at final - vector)
#   a list of motions is done in order (the offsets add up backwards from the final position)
STEPS = [
    dict(step="0 base", desc="Print the base; press the M3 and M2.5 heat-set inserts into the posts and standoffs.",
         items=["base", "pi_insert", "lid_insert", "shelf_insert"], motion=None),
    dict(step="1 SMA leads", desc="SMA/RP-SMA leads into holes 4-6 from inside (thread out through the hole); washer + nut outside.",
         items=["sma4.flange", "sma4.body", "sma4.thread", "sma5.flange", "sma5.body", "sma5.thread", "sma6.flange", "sma6.body", "sma6.thread"],
         motion=[("lower", 40.0), ("push", (0, 13.0, 0))]),
    dict(step="1b SMA nuts", desc="Washers and nuts onto the bulkhead threads from outside.",
         items=["sma4.washer", "sma4.nut", "sma5.washer", "sma5.nut", "sma6.washer", "sma6.nut"], motion=[("push", (0, -12.0, 0))]),
    dict(step="2 Pi", desc="Raspberry Pi (SD card NOT fitted) lowered straight onto its 4 standoffs; 4 x M2.5 x 5 screws.",
         items=["pi.pcb", "pi.underside", "pi.usb2", "pi.usb3", "pi.eth", "pi.gpio", "pi.hs_soc", "pi.hs_ram", "pi.usbc", "pi.hdmi0",
                "pi.hdmi1", "pi.audio", "pi_screw"], motion=[("lower", 70.0)]),
    dict(step="2b SD card", desc="microSD card pushed into the Pi through the back slot.", items=["pi.sdcard"], motion=[("push", (0, -16.0, 0))]),
    dict(step="3 NIC B plug", desc="NIC B's short USB plug into the Pi's USB 3 lower port (before the breadboard).",
         items=["usbplug.wn2"], motion=[("push", (0, 14.0, 0))]),
    dict(step="5 ESP", desc="ESP32-S3: IPEX lead and 90 deg USB-C plug fitted on the bench; tilt the module end under the snap lip, "
         "swing the USB end down onto the bed.", items=["esp.", "usbc90.plug"], motion="esp_tilt"),
    dict(step="6 Pi plugs", desc="ESP link into USB 3 upper, NIC A into USB 2 upper.", items=["usbplug.esp", "usbplug.wn1"],
         motion=[("push", (0, 14.0, 0))]),
    dict(step="7 small parts", desc="Buzzer ears down into their slots; PN532 slid down its rails.", items=["buz.body", "pn.pcb", "pn.parts", "pn.hdr"], motion=[("lower", 60.0)]),
    dict(step="7b KY-013", desc="KY-013: lowered 12 mm in front of its place, slid back onto the ledge, taped to the wall.",
         items=["ky.pcb", "ky.parts", "ky.pins"], motion=[("lower", 40.0), ("push", (0, 12.0, 0))]),
    dict(step="8 breadboard", desc="Breadboard into its frame (not glued), jumpers fitted.", items=["bb.body"], motion=[("lower", 60.0)]),
    dict(step="9 KCD11", desc="KCD11 pushed in from outside until it snaps; wires on.", items=["sw.bezel", "sw.body", "sw.terms"],
         motion=[("push", (0, 20.0, 0))]),
    dict(step="10 shelf", desc="Shelf assembled on the bench (fan + spacers + 4 countersunk screws/nuts underneath, strap insert), "
         "then lowered in from the top.",
         items=["shelf", "fan.body", "fan_spacer", "fan_screw", "fan_nut", "strap_insert"], motion=[("lower", 45.0)]),
    dict(step="11 shelf screws", desc="2 x M3 x 8 into the shelf posts.", items=["shelf_screw"], motion=[("lower", 20.0)]),
    dict(step="11b NIC stack", desc="On the bench: both WN722N slid into the two rails from the back until they touch the front stops, "
         "USB connectors plugged onto their plugs. The stack is lowered onto the 4 pegs on the shelf (no screws; the lid holds it down).",
         items=["nic_rail_l", "nic_rail_r", "wn1.", "wn2.", "socket"], motion=[("lower", 45.0)]),
    dict(step="12 RA plugs", desc="Right-angle RP-SMA plugs screwed onto the two WN722N jacks (leads to holes 4 and 5).",
         items=["wn1ra", "wn2ra"], motion=[("lower", 25.0), ("push", (6.0, 0, 0))]),
    dict(step="13 nRF24", desc="Each nRF24 + adapter set on the shelf 11 mm forward, then slid back so its jack passes hole 1 or 2 "
         "and the module end enters its pocket.", items=["nrf1.adapter", "nrf1.socket", "nrf1.hdr", "nrf1.module", "nrf1.jack",
                                                         "nrf2.adapter", "nrf2.socket", "nrf2.hdr", "nrf2.module", "nrf2.jack"],
         motion=[("lower", 30.0), ("push", (0, 11.0, 0))]),
    dict(step="14 stop+strap", desc="nRF stop bar (pegs into the shelf) and strap (tab into the notch in the cradle wall, 1 x M3 x 8).",
         items=["nrf_stop", "nrf_strap", "strap_screw"], motion=[("lower", 25.0)]),
    dict(step="15 antennas", desc="Antennas screwed onto the 5 connectors outside.", items=["ant"], motion=[("push", (0, -15.0, 0))]),
    dict(step="16 lid", desc="Lid with screen (4 x M2.5 x 4) and 5 buttons, wired to the breadboard, lowered on; lips locate it.",
         items=["lid", "tft.pcb", "tft.glass", "tft.j2", "tft.j4", "tft.sd", "tft_screw", "btn"], motion=[("lower", 50.0)]),
    dict(step="17 lid screws", desc="4 x M3 x 8 lid screws.", items=["lid_screw"], motion=[("lower", 15.0)]),
    dict(step="18 power", desc="Power bank cable into the Pi's USB-C through the left-side hole.", items=["power.plug"],
         motion=[("push", (18.0, 0, 0))]),
]

# exploded view: offsets per item prefix (first match wins)
EXPLODE = [("lid_screw", (0, 0, 150)), ("lid", (0, 0, 120)), ("tft", (0, 0, 120)), ("btn", (0, 0, 120)), ("tft_screw", (0, 0, 120)),
           ("ant", (0, 60, 0)), ("sma4.nut", (0, 35, 0)), ("sma5.nut", (0, 35, 0)), ("sma6.nut", (0, 35, 0)), ("sma4.washer", (0, 30, 0)),
           ("sma5.washer", (0, 30, 0)), ("sma6.washer", (0, 30, 0)),
           ("nrf_strap", (0, 0, 85)), ("strap_screw", (0, 0, 95)), ("nrf_stop", (0, 0, 75)), ("nrf", (0, -15, 65)),
           ("shelf_screw", (0, 0, 80)), ("wn1ra", (-20, 0, 85)), ("wn2ra", (-20, 0, 85)), ("coax", (0, 0, 60)),
           ("nic_rail", (0, 0, 85)), ("shelf", (0, 0, 60)), ("strap_insert", (0, 0, 60)), ("fan", (0, 0, 45)), ("fan_spacer", (0, 0, 52)),
           ("wn", (0, 0, 85)), ("socket", (0, 0, 85)), ("sw.", (0, -25, 0)), ("power", (-25, 0, 0))]


def explode_offset(name):
    for pref, off in EXPLODE:
        if name.startswith(pref):
            return off
    return (0, 0, 0)
