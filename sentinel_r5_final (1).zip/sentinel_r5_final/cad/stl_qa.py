"""QA of the exported STL files, read back from disk in their print orientation.

1. mesh integrity  - watertight, consistent winding, edges shared by more than two faces, degenerate faces,
                     number of bodies, mesh volume against the CAD volume
2. bed             - lowest point at z = 0, first-layer contact area, footprint against the 220 x 220 bed
3. overhangs       - printcheck.analyse (bridges, cantilevers, islands)
4. wall thickness  - rays cast inward from area-weighted surface samples; regions thinner than 1.2 mm are
                     clustered and reported with their position in assembly coordinates
5. narrow gaps     - rays cast outward; slots inside one part narrower than 0.6 mm (they can close up when printed)
Writes out/stl_qa.json.
"""
import json, os, sys
import numpy as np
import trimesh
from printcheck import analyse

HERE = os.path.dirname(os.path.abspath(__file__))
STL = os.path.join(HERE, "deliverables", "stl")
BED_XY = (220.0, 220.0)
THIN_WARN, THIN_FAIL = 1.2, 0.8        # mm: 3 and 2 extrusion widths of a 0.4 mm nozzle
GAP_WARN = 0.6
DENSITY = 4.0                          # samples per mm2 of surface
EXPECT_BODIES = {"sentinel_r5_fan_spacers_x4": 4}


def cast(m, origins, dirs):
    """Distance to the first surface hit along each ray (inf if none) and the hit face's normal."""
    loc, ri, ti = m.ray.intersects_location(origins, dirs, multiple_hits=False)
    d = np.full(len(origins), np.inf)
    nh = np.zeros((len(origins), 3))
    if len(ri):
        dist = np.einsum("ij,ij->i", loc - origins[ri], dirs[ri])
        order = np.argsort(-dist)                       # write nearest last
        d[ri[order]] = dist[order]
        nh[ri[order]] = m.face_normals[ti[order]]
    return d, nh


def clusters(pts, cell=1.5):
    """Group points that lie within neighbouring grid cells."""
    keys = np.floor(pts / cell).astype(np.int64)
    uniq, inv = np.unique(keys, axis=0, return_inverse=True)
    index = {tuple(k): i for i, k in enumerate(uniq)}
    parent = list(range(len(uniq)))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for i, k in enumerate(uniq):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    j = index.get((k[0] + dx, k[1] + dy, k[2] + dz))
                    if j is not None:
                        ra, rb = find(i), find(j)
                        if ra != rb:
                            parent[ra] = rb
    lab = np.array([find(i) for i in range(len(uniq))])[inv.ravel()]
    return [np.where(lab == r)[0] for r in np.unique(lab)]


def to_asm(p, tf):
    if tf is None:
        return p
    q = p - np.array(tf["t"])
    if tf["flip"]:
        q = q * np.array([1.0, -1.0, -1.0])
    return q


def thickness_report(m, tf, outward=False, limit=THIN_WARN, seed=7):
    """Inward rays measure wall thickness, outward rays measure gaps between faces of the same part.
    A reading counts as a parallel-faced section ('sheet' / 'slot') when the face the ray reaches is within ~18 deg of
    parallel to the face it left; otherwise it is a taper (a knife edge of a chamfer, corbel, rib or the cusp where a
    round post meets a wall), which is reported separately and not counted as a thin wall."""
    n = int(min(400000, max(20000, m.area * DENSITY)))
    pts, fi = trimesh.sample.sample_surface(m, n, seed=seed)
    nrm = m.face_normals[fi]
    sgn = 1.0 if outward else -1.0
    d, nh = cast(m, pts + sgn * nrm * 1e-3, sgn * nrm)
    parallel = np.einsum("ij,ij->i", nrm, nh) < -0.95
    out = {}
    for kind, mask in (("parallel", parallel), ("taper", ~parallel)):
        sel = np.where((d < limit - 0.01) & mask)[0]
        rows = []
        if len(sel):
            for g in clusters(pts[sel]):
                idx = sel[g]
                area = len(idx) / DENSITY
                if area < 0.5:                   # a few samples on a sharp edge
                    continue
                a = to_asm(pts[idx], tf)
                rows.append(dict(min=round(float(d[idx].min()), 3), median=round(float(np.median(d[idx])), 3),
                                 area_mm2=round(area, 1),
                                 asm_bbox=[np.round(a.min(0), 1).tolist(), np.round(a.max(0), 1).tolist()]))
        rows.sort(key=lambda r: r["min"])
        out[kind] = rows
    return out, dict(samples=n, p01=round(float(np.percentile(d[np.isfinite(d)], 1)), 3))


def integrity(m, cad_cm3):
    e = m.edges_sorted
    _, cnt = np.unique(e, axis=0, return_counts=True)
    bodies = m.split(only_watertight=False)
    area = m.area_faces
    bottom = (m.face_normals[:, 2] < -0.999) & (m.triangles_center[:, 2] < 1e-3)
    return dict(watertight=bool(m.is_watertight), winding_consistent=bool(m.is_winding_consistent),
                edges_not_shared_by_two=int((cnt != 2).sum()), degenerate_faces=int((area < 1e-10).sum()),
                bodies=len(bodies), faces=int(len(m.faces)),
                volume_cm3=round(float(m.volume) / 1000, 3), cad_volume_cm3=cad_cm3,
                volume_dev_pct=round(100 * (m.volume / 1000 - cad_cm3) / cad_cm3, 3) if cad_cm3 else None,
                z_min=round(float(m.bounds[0][2]), 4), size=[round(float(v), 2) for v in m.extents],
                fits_bed=bool(m.extents[0] <= BED_XY[0] - 10 and m.extents[1] <= BED_XY[1] - 10),
                first_layer_mm2=round(float(area[bottom].sum()), 1))


def main():
    parts = json.load(open(os.path.join(HERE, "out", "parts.json")))
    res = {}
    for k, info in parts.items():
        fn = os.path.join(STL, info["file"])
        name = info["file"][:-4]
        m = trimesh.load(fn)
        r = dict(integrity=integrity(m, info["volume_cm3"]))
        ov = analyse(m)
        r["overhang_problems"] = [o for o in ov if not o["ok"]]
        r["overhang_patches"] = len(ov)
        tf = info.get("bed_from_asm")
        r["thin"], r["thin_stats"] = thickness_report(m, tf)
        r["narrow_gaps"], r["gap_stats"] = thickness_report(m, tf, outward=True, limit=GAP_WARN)
        ii = r["integrity"]
        ok = (ii["watertight"] and ii["winding_consistent"] and ii["edges_not_shared_by_two"] == 0 and ii["degenerate_faces"] == 0
              and ii["bodies"] == EXPECT_BODIES.get(name, 1) and abs(ii["volume_dev_pct"]) < 0.5 and abs(ii["z_min"]) < 1e-3
              and ii["fits_bed"])
        r["integrity_ok"] = bool(ok)
        res[name] = r
        th, gp = r["thin"], r["narrow_gaps"]
        print(f"{name:30s} integrity {'OK ' if ok else 'BAD'} bodies {ii['bodies']} vol {ii['volume_cm3']} (CAD {ii['cad_volume_cm3']}, "
              f"{ii['volume_dev_pct']}%) size {ii['size']} bed contact {ii['first_layer_mm2']} mm2 | overhang problems "
              f"{len(r['overhang_problems'])} | walls<{THIN_WARN}: {len(th['parallel'])} (tapers {len(th['taper'])}) | "
              f"slots<{GAP_WARN}: {len(gp['parallel'])} (cusps {len(gp['taper'])})")
        if not ok:
            print("     ", ii)
        for o in r["overhang_problems"]:
            print("      overhang", o)
        for t in th["parallel"]:
            print(f"      WALL  min {t['min']:.2f} median {t['median']:.2f} area {t['area_mm2']} asm {t['asm_bbox']}")
        for t in th["taper"]:
            print(f"      taper min {t['min']:.2f} median {t['median']:.2f} area {t['area_mm2']} asm {t['asm_bbox']}")
        for t in gp["parallel"]:
            print(f"      SLOT  min {t['min']:.2f} median {t['median']:.2f} area {t['area_mm2']} asm {t['asm_bbox']}")
    json.dump(res, open(os.path.join(HERE, "out", "stl_qa.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
