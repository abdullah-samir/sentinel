"""Sentinel enclosure, rev 5 - every dimension in one place (mm).

Coordinate system for every part and the assembly ("inner coordinates"):
  origin = inside front-left corner of the floor's top surface
  +x to the right, +y to the back, +z up
  outer faces: x = -WALL and L + WALL, y = -WALL and W + WALL, bottom z = -FLOOR, lid top z = H + LID_T
  The drawings use the same system: datums X0 / Y0 = inside faces of the left / front wall, Z0 = floor top.

Source tags:
  [U] measured or stated by Samir     [D] datasheet / official drawing / shop listing
  [P] scaled from Samir's photo       [A] assumption (checked by the fit-test coupon or flagged)
  [C] design choice                   [R5] approved in the rev 5 review (13 Nov)
  [CAD] changed during CAD validation and STL QA (13 Nov) - see CHANGES below and the report
"""
import math, os

# ---------------------------------------------------------------- box
L, W, H = 123.0, 145.0, 59.0          # [R5] inner length (x), depth (y), height (z, floor top to lid underside)
WALL, FLOOR, LID_T = 2.0, 2.0, 2.0    # [R5]
R_OUT, R_IN = 4.0, 2.0                # [C] vertical corner radii outside / inside (uniform 2 mm corner wall)
EDGE_CHAMFER = 0.6                    # [C] chamfer on the bed-side outer edges (elephant's foot)
OUT = dict(x0=-WALL, x1=L + WALL, y0=-WALL, y1=W + WALL, z0=-FLOOR, z1=H + LID_T)

# rear antenna band: 5 mm thick from the shelf up, 2 mm wall below          [R5]
REAR_IN = 142.0                       # inner face of the band
OUT_Y = W + WALL                      # 147, outer back face
BAND_Z0 = 28.5                        # band starts at the shelf's underside
BAND_CHAMFER = OUT_Y - WALL - REAR_IN  # 3.0: 45 deg underside so the band prints without support

# ---------------------------------------------------------------- shelf
SHELF_Z, SHELF_T = 28.5, 2.4          # [R5]
ST = SHELF_Z + SHELF_T                # 30.9 shelf top
SHELF_GAP = 0.5                       # [C] clearance shelf edge -> wall / band
SHELF_X = (0.5, L - 0.5)              # 0.5 .. 122.5
SHELF_BACK = REAR_IN - SHELF_GAP      # 141.5
SHELF_FRONT_L, SHELF_FRONT_R = 45.0, 48.0   # [R5] front edge left of x 70 / right of x 70
SHELF_STEP_X = 70.0
CUT = (45.5, 116.0, 126.0)            # [R5][CAD] back cut-out x0, x1, y0 (to the back edge): passes the SMA bodies (x1 116 -> 1.5 mm)
SLOT = (76.0, 91.0, 58.0, 82.0)       # [R5] screen jumpers <-> ESP left pin row
SHELF_LIP = (0.5, 70.0, 45.0, 47.0, 4.0)   # [R5] upward lip on the left part of the front edge: x0, x1, y0, y1, height
RR_NOTCH = (CUT[1], 138.0)            # [CAD] rear-right strip x from the cut-out, back edge 0.5 short of the rear-right post
LEDGE_W, LEDGE_H = 2.0, 2.5           # [C] side ledges under the shelf (2.0 wide: 0.5 mm clear of the Pi's side ports)
LEDGE_L_Y = [(45.0, 84.0), (93.0, SHELF_BACK)]   # [CAD] left ledge, interrupted at the Pi's audio jack (y 85.5-91.5)
LEDGE_R_Y = [(35.0, SHELF_BACK)]      # [C] right ledge starts behind the buzzer
SHELF_POSTS = [(70.0, 53.0), (119.5, 116.0)]     # [R5] M3 insert posts (right one merged with the right wall)
SHELF_POST_D = 8.5

# ---------------------------------------------------------------- lid fixing posts           [CAD]
# Rev 5 had posts at the 4 corners. CAD validation found the rear-left post above the Pi's corner (blocks
# lowering the Pi in) and the front-left post above the PN532 (blocks sliding it up to free NIC A's plug).
LID_POSTS = [
    dict(name="front_left", x=12.0, y=2.0, z0=46.0, wall="front"),      # moved 9.5 right: clear of the PN532 (x <= 6.2)
    dict(name="front_right", x=121.0, y=2.0, z0=46.0, wall="front"),
    dict(name="rear_mid", x=64.25, y=142.5, z0=47.0, wall="band", d=8.0),   # replaces the rear-left post: between holes 3 and 4; 0.75 clear of the Pi, 1 of SMA 4
    dict(name="rear_right", x=121.0, y=143.0, z0=0.0, wall="floor"),
]
LID_POST_D = 9.0                      # [R5]
INSERT_M3 = dict(od=4.5, l=8.0, hole=4.0, depth=9.0)   # [D] Makers C3604 M3 x 8 x 4.5 / [A] hole 4.0 (coupon)
INSERT_M25 = dict(od=3.6, l=4.0, hole=3.2, depth=4.6)  # [A] M2.5 x 4 insert (not at Makers), hole per coupon
M3_CLEAR, M25_CLEAR = 3.4, 2.9        # [C]
M3_HEAD = dict(d=5.7, h=1.65)         # [D] ISO 7380 button head
M3_CSK = dict(d=6.0, h=1.7)           # [D] ISO 10642 countersunk head

# ---------------------------------------------------------------- lid
LID_LIP = dict(w=1.6, h=3.0, gap=0.3, corner=2.5)   # [R5] locating lips inside the walls
OPEN = (46.0, 36.0)                   # [R5] screen opening (screen 45 x 35 + 0.5 all round)
TFT_X0, TFT_Y0 = L / 2 - 29.0, 53.25  # [R5] TFT PCB corner (landscape 58 x 34.5)
TFT_PCB = (58.0, 34.5, 1.6)           # [D]
TFT_HOLES = [(3.0, 3.0), (55.0, 3.0), (3.0, 31.5), (55.0, 31.5)]   # [D] dia 3.2, landscape
GLASS = (45.0, 35.0, 3.0)             # [U] screen 45 x 35, 3 above the PCB
TFT_TOP = H + LID_T - GLASS[2]        # 58.0 PCB top: glass flush with the lid top
TFT_BOSS = dict(d=5.5, pilot=2.2, depth=2.4)   # [C] M2.5 x 4 self-tapping: 1.6 PCB + 2.4 in the boss; 0.6 mm skin left under the lid face
GCX, GCY = TFT_X0 + 29.0, TFT_Y0 + 17.25       # screen centre (61.5, 70.5)
LID_VENTS = [*[(99 + 4.4 * k, 30.0, 2.2, 66.0) for k in range(5)],          # [R5] x0, y0, w, l (over the NIC sled)
             *[(48 + 4.4 * k, 96.0, 2.2, 30.0) for k in range(10)]]         # [R5] behind the screen

# ---------------------------------------------------------------- buttons (PBS-11A, Makers 12 mm)   [D] shop drawing
BTN = dict(hole=12.3, pitch=22.0, y0=13.0, head_d=18.4, head_h=6.3, cap_d=11.9, above=10.3,
           thr_d=11.8, thr_l=9.13, body_d=10.5, body_l=23.2, pin_l=28.7,
           nut_af=18.0, nut_t=2.0)    # nut not on the drawing: worst case M12 thin nut 18 AF        [A]
BTN_NAMES = ("left", "down", "right", "up", "OK")
BTNS = [(L / 2 - BTN["pitch"], BTN["y0"]), (L / 2, BTN["y0"]), (L / 2 + BTN["pitch"], BTN["y0"]),
        (L / 2, BTN["y0"] + BTN["pitch"]), (L / 2 + BTN["pitch"], BTN["y0"] + BTN["pitch"])]

# ---------------------------------------------------------------- antennas (back band)        [R5]
ROW_Z = ST + 1.0 + 9.75               # 41.65
HOLES = [dict(n=1, x=16.0, kind="nrf", label="nRF24 #1"), dict(n=2, x=35.0, kind="nrf", label="nRF24 #2"),
         dict(n=3, x=54.0, kind="spare", label="spare"), dict(n=4, x=73.0, kind="sma", label="WN722N lower"),
         dict(n=5, x=92.0, kind="sma", label="WN722N upper"), dict(n=6, x=110.5, kind="sma", label="ESP32-S3")]
SMA = dict(hole=6.6, spot_d=10.5, clamp=2.0, thread_min=9.5, thread=6.35, flange_af=8.0, flange_t=3.0,
           body_d=8.0, body_l=8.6, nut_af=8.0, nut_t=2.5, washer_d=9.5, washer_t=0.5)   # [D] typical / [A] check on arrival
SPOT_DEPTH = OUT_Y - SMA["clamp"] - REAR_IN     # 3.0
NRF_HOLE = 9.4                        # [R5] clearance for any SMA shoulder
NRF_POCKET = dict(w=16.1, h=5.0, depth=OUT_Y - 2.5 - REAR_IN, z0=ST + 1.0 + 8.3)   # 2.5 deep, z 40.2-45.2

# ---------------------------------------------------------------- Raspberry Pi 4 (r8 placement)  [D] official drawing
PI = dict(x0=3.5, y0=57.0, x1=59.5, y1=142.0, z0=4.0, t=1.4)    # PCB footprint; USB/Ethernet end at the front (y0)
PI_STANDOFF = dict(d=6.0, h=4.0)      # [C]
PI_HOLES = [(7.0, 138.5), (7.0, 80.5), (56.0, 138.5), (56.0, 80.5)]   # [D] (bx, by) = (3.5/61.5, 3.5/52.5)
# ports (inner coords): USB 2.0 stack nearest the USB-C edge, USB 3.0 the middle stack, Ethernet by the GPIO  [D]
PI_USB2 = (5.0, 20.0, 54.5, 72.0, 5.4, 21.4)
PI_USB3 = (23.0, 38.0, 54.5, 72.0, 5.4, 21.4)
PI_ETH = (41.2, 57.2, 54.5, 76.0, 5.4, 18.9)
PI_USBC_Y, PI_HDMI_Y, PI_AUDIO_Y = 130.75, (116.0, 102.5), 88.5

# ---------------------------------------------------------------- ESP32-S3 DevKitC-1 (flipped, pins up)   [U]/[P]
ESP = dict(x0=81.25, y0=53.5, w=27.5, l=65.0, carrier_l=58.5, dz=2.5)   # [R5] centred, 1.5 back, raised 2.5
ESP_PCB_Z = (3.7 + 2.5, 5.3 + 2.5)    # 6.2 - 7.8
ESP_MOD = dict(ax=(3.0, 24.5), ly=(39.0, 65.0), z=(3.0, 6.2))   # module + shield, local x / y
ESP_SHIELD_LY = (39.0, 54.0)          # [A] shield under the module (IPEX area free)
ESP_IPEX = dict(ax=(6.1, 9.1), ly=(55.2, 58.2), z=(2.9, 5.4))
ESP_USBC = [(3.1, 11.8), (15.2, 23.9)]  # [P] local x of the two receptacles, ly -0.2..8.7, z 3.0-6.2
ESP_HDR = [(-0.2, 2.3), (25.2, 27.7)]   # header plastic local x, ly 0.1-56, z 7.8-10.3, pins to 16.3
USBC_PORT = 0                         # [A] receptacle used (0 = nearer the left edge)
USBC90 = dict(w=12.0, d=7.8, up=16.0, below=3.5)   # [A] 90 deg plug body (check on arrival: <= 12 x 7)

# ---------------------------------------------------------------- fan 4010
FAN = dict(cx=31.5, cy=104.0, s=40.0, t=10.0, pitch=32.0, bore=38.0, hub=16.0)   # [R5]/[D]
HS_MAX = 10.0                         # [U] CPU heatsink under 10 mm
FAN_Z0 = PI["z0"] + PI["t"] + HS_MAX + 1.0      # 16.4
FAN_SPACER = dict(od=7.0, id=3.4, h=SHELF_Z - (FAN_Z0 + 10.0))   # 2.1
FAN_OPEN_D = 38.0

# ---------------------------------------------------------------- floor parts
BB = dict(x0=18.0, x1=103.0, y0=0.5, y1=37.5, h=10.0)      # [U]/[R5]
BB_RIM = dict(w=1.5, h=3.0, gap=0.3)                       # [C]
PN = dict(x0=1.2, t=1.6, y0=0.3, y1=43.3, z0=0.8, z1=41.8, parts=(2.8, 6.2, 6.3, 37.3, 6.8, 35.8),
          hdr=(2.8, 11.3, 40.7, 43.3, 16.3, 26.5))         # [D] Makers 43 x 41 / [E]
BUZ = dict(x0=110.0, x1=122.0, cy=22.0, cz=17.0, d=23.0, ear_pitch=30.0, ear_w=7.0, ear_t=2.0)   # [D] SFM-20B / [R5] centre height
SW = dict(cx=25.1, cz=38.05, cut=(13.5, 8.5), body=(13.2, 8.3, 12.0), bezel=(15.0, 10.0, 2.0))   # [R5]/[D] KCD11
KY = dict(x0=69.0, x1=87.5, z0=8.0, z1=23.0, pcb_y=(143.4, 145.0), parts_y=(141.4, 143.4))   # [CAD] 5 mm right; [A] 3-pin header at the right end, foam tape on the wall

# ---------------------------------------------------------------- radio shelf parts            [R5]
DZ_R = ST - 36.8                      # r6 radio shift
NIC_X0, NIC_YUSB = 95.7, 42.0          # WN722N PCB: left (antenna-side) edge x, front edge y (the USB plug sticks out in front of it)
#                                       [CAD] 13 Nov: 1.0 further left than before, so the widest right rail keeps a 2 mm wall
# ---- WN722N board (your data, 13 Nov): width 21-23 mm; a 2 mm button on the chip face at the edge opposite the antenna jack,
#      near the USB end, its plunger 1 mm past the PCB edge (no access needed); nothing else within 2.5 mm of the long edges.  [U]
NIC_PCB_W_VARIANTS = (21.0, 21.5, 22.0, 22.5, 23.0)      # right rail printed for the measured width (round up to the next 0.5)
NIC_PCB_W = float(os.environ.get("SENTINEL_NIC_W", "22.0"))   # width used for the assembly, drawings and default validation run
NIC_BTN = dict(h=2.0, out=1.0, edge_band=2.5)             # [U] button height, plunger past the edge, clear band along both long edges
# ---- NIC rails (your change, 13 Nov): the WN722N boards slide in two separate rails that drop onto 4 pegs on the shelf;
#      the lid holds them down; nothing surrounds the USB ends.                                      [U] 13 Nov
NIC_PLATE_Y0 = 37.0                    # shelf front edge under the NICs (the rev 5 sled reached y 25)
NIC_PLATE_X = 90.0                     # where the shelf's front edge steps from y 48 to y 37
NIC_RAIL = dict(y0=NIC_YUSB - 3.0, y1_l=91.0, y1_r=108.0,     # left rail stops at y 91: the RP-SMA jacks leave the boards' left side there
                gap=0.25,                                   # nominal side gap at each PCB edge (channel = board width + 0.5)
                rib=2.0,                                    # 45 deg ribs / ledge reach over the board edge (inside the 2.5 mm clear band)
                wl_t=3.0,                                   # left rail wall thickness
                kerb=1.2,                                   # right rail: kerb (side stop) rises 1.2 above the PCB underside, 0.4 below its top face
                recess=1.4,                                 # right rail: recess above the kerb for the 1 mm plunger (0.4 clear)
                wr_outer=122.5,                             # right rail outer face, under the lid's right lip
                top_r=H - LID_LIP["h"] - 0.3,              # 55.7: right rail sits 0.3 under the lid's right lip
                lidstop_y=(50.0, 80.0), lidstop_l=6.0, lidstop_top=H - 0.3,   # two posts on the left rail, 0.3 under the lid
                stop_y1=NIC_YUSB - 0.2,                     # front stops 0.2 in front of the PCB edge
                sup_gap=0.1, hold_gap=0.2,                 # board fit: support 0.1 under the PCB, left hold-down 0.2 over it
                flange=(3.0, 2.0))                          # inner foot flange 3 wide x 2 high: steadier print, stiffer rail
NIC_RAIL["wl"] = (NIC_X0 - NIC_RAIL["gap"] - NIC_RAIL["wl_t"], NIC_X0 - NIC_RAIL["gap"])      # 92.45 .. 95.45
NIC_RAIL["top"] = round(42.1 + DZ_R + 14.0 + 1.6 + NIC_RAIL["hold_gap"] + NIC_RAIL["rib"] - NIC_RAIL["gap"] + 0.4, 2)   # over the upper hold-down rib


def nic_right(w=None):
    """Right rail x positions for a board of width w: kerb face (side stop), recess face and outer face."""
    w = NIC_PCB_W if w is None else w
    kerb = NIC_X0 + w + NIC_RAIL["gap"]
    return dict(w=w, kerb=kerb, recess=kerb + NIC_RAIL["recess"], outer=NIC_RAIL["wr_outer"])


NIC_PEGS = ((93.6, 44.0), (93.6, 87.0), (118.8, 48.0), (118.8, 104.0))   # pegs on the shelf (left rail 2, right rail 2)
NIC_PEG = dict(d=3.0, h=3.0, chamfer=0.4, hole=3.3, hole_depth=3.4, boss_d=6.6, boss_h=5.0,
               boss_h_low=3.4)                              # low boss (through hole) where the boss sits under the boards' parts
NIC_PEG_LOW = (2,)                    # right rail's front peg: under the lower board, so the space in front of the USB plugs stays empty
NIC_PLUG_CX = NIC_X0 + NIC_PCB_W / 2  # [A] USB plug centred on the board width
NIC_USB_ENVELOPE = (NIC_PLUG_CX - 10.0, NIC_PLUG_CX + 10.0, 7.0, 39.0, ST, H - LID_LIP["h"])   # [CAD] connector space checked
#                     empty of printed parts: 20 mm wide centred on the plugs, from the mating face (y 39) to y 7 (front-right
#                     lid post), shelf top to the lid lips
SHELF_VENTS = dict(af=7.0, web=3.0, edge=6.0,   # [U] 13 Nov: hexagonal vent holes in the shelf, 7 across flats, 3 mm webs, 6 mm from edges
                   zones=((6.0, 72.0, 50.0, 86.0), (98.0, 116.0, 40.0, 120.0)))   # only in front of the nRF stop bar and under the NIC
#                  boards: the bending check showed the area between the fan opening, the slot and the cut-out's free edge is the
#                  most flexible part of the plate, so it stays solid
WN_PCB_Z = [42.1 + DZ_R, 42.1 + DZ_R + 14.0]   # 36.2 / 50.2 bottom of each WN722N PCB
NRF_X = (16.0, 35.0)
NRF_YS = OUT_Y - 2.5 - 62.0           # 82.5 adapter front edge
CRADLE = dict(y0=124.0, y1=134.0, top=ST + 10.0 - 0.05, wall_top=ST + 1.0 + 13.3)
NRF_STOP = dict(y0=NRF_YS - 3.5, y1=NRF_YS - 0.3, h=3.5, pegs=(10.0, 25.5, 41.0), peg_d=3.0)
STRAP = dict(t=2.0, w=8.0, x0=0.5, x1=45.5, screw=(4.2, 129.0))
SOCKET = dict(w=13.15, h=5.75, l=14.0, y0=25.0, gap=0.22, lip=1.0, cx=NIC_PLUG_CX, cz=(36.95, 50.95))   # [A] reference connector: bare USB-A female
#        socket with soldered wires, plugged onto each WN722N plug and hanging free (any female end that fits the free space will do)

# ---------------------------------------------------------------- outside features (inner coords)  [R5]
F_LOW = [(18 + 4.4 * k, 12.0, 2.2, 14.0) for k in range(20)]       # front wall: x0, z0, w, h
F_UP = [(38 + 4.4 * k, 32.0, 2.2, 18.0) for k in range(18)]
EXH = [(20 + 4.4 * k, 8.0, 2.2, 16.0) for k in range(10)]           # back wall below the band
SD_SLOT = (23.5, 39.5, 1.0, 5.0)      # x0, x1, z0, z1
PWR = (123.5, 138.5, 2.5, 11.5)       # left wall: y0, y1, z0, z1  (15 x 9)
L_VENT = [(93 + 4.4 * k, 14.0, 2.2, 10.0) for k in range(6)]        # left wall: y0, z0, w, h  (top at 24 = foot of the ledge corbel)
R_VENT = [(59 + 4.4 * k, 39.0, 2.2, 10.0) for k in range(6)]        # right wall
BUZ_HOLES = dict(d=2.5, r=6.0, n=6)   # right wall: 1 centre + 6 on a ring

# ---------------------------------------------------------------- strength / printability details        [C] CAD QA
PN_WALL = 1.6                         # PN532 channel and groove walls (were 1.2)
KY_GUIDE_T = 1.6                      # KY-013 end guide (was 1.2)
BUZ_LIP_T = 1.6                       # buzzer ear-slot lips (were 1.2)
BUZ_END_T = 1.6                       # buzzer ear-slot end walls (were 1.0)
ESP_END_TOP = 9.0                     # ESP end wall and snap lip top (was 7.3: the lip was 0.7 mm thick, now 2.4)
STRAP_NOTCH = dict(w=4.0, depth=2.4, gap=0.2)   # strap locating notch through the cradle's right wall (was a 1.3 slot leaving 0.57 mm walls)
SD_FLARE = dict(side=3.0, up=2.0, depth=1.0)    # SD slot mouth widens sideways and upward only (it used to cut 1 mm into the floor edge); 1.0 straight rim; top 1 mm below the exhaust slots

PRINT_TOL = 0.3                       # [C] clearance per side for parts that slide/drop into printed features

CHANGES = [
    "Lid posts: rear-left post moved to the back band between holes 3 and 4 (x 64.25, 8 mm dia); it stood over the Pi's corner and blocked lowering the Pi in.",
    "Lid posts: front-left post moved 9.5 mm right (x 12): it stood over the PN532, which must slide up to free NIC A's USB plug.",
    "Shelf: rear-left corner no longer notched (no post there now).",
    "KY-013 moved 5 mm right (x 69-87.5) so it can be lowered in past the new rear-middle lid post.",
    "Left shelf ledge interrupted at the Pi's audio jack, which would otherwise hit it while the Pi is lowered in.",
    "Fan screws countersunk from the top: a screw head at (15.5, 88) would sit under nRF24 #1's adapter.",
    "nRF cradle gets a groove under each jack, so the module can be set down 11 mm forward and slid back (its jack hangs 2.5 mm below the PCB).",
    "nRF24 modules slide back 11 mm, not 9: the jack (8 mm) and the 2.5 mm pocket must both clear the band before it can be lowered.",
    "microSD card goes in through the back slot after the Pi is fitted (the card's 2.5 mm overhang passes under the band otherwise).",
    "Breadboard frame's back rim stops at x 81: the ESP's 90 deg USB-C plug needs the room to be pulled out.",
    "ESP snap lip raised to 0.4 mm above the module so the board can be tilted in under it.",
    "Right NIC rail has windows behind the right-side vents (it stands 0.5 mm behind them).",
    "Your change (13 Nov): the WN722N boards slide in two removable rails that drop onto 4 pegs on the shelf and are held down by the lid; nothing surrounds their USB ends (rev 5: a sled with perfboard sockets).",
    "Your data (13 Nov): WN722N boards 21-23 mm wide (rev 5: 23) with a 2 mm button and 1 mm plunger at the edge opposite the antenna. The right rail is printed for the measured width (5 versions, 21.0-23.0 mm in 0.5 steps); it carries that edge on a ledge with a low kerb as side stop and a recess above for the plunger, with nothing over the board. The left rail's ribs now reach 2.0 mm.",
    "NIC stack 1.0 mm further left (board edge X 95.7, left rail X 92.45-95.45, left pegs X 93.6): the 23 mm right rail keeps a 2.15 mm wall behind the plunger recess.",
    "Right rail's front peg moved back under the lower board (Y 48, low boss, hole through): its boss reached 1.8 mm into the space in front of the USB plugs.",
    "Buzzer held by its ears in two printed slots (no screws: a screwdriver could not reach screws facing the right wall).",
    "Your change (13 Nov): the shelf's front edge under the NICs is at y 37 (rev 5 sled front y 25), leaving the space in front of the boards free for the USB connectors and their cables.",
    "Your change (13 Nov): hexagonal vent holes (7 mm across flats, 3 mm webs) in the shelf plate, kept 6 mm from every edge, screw, peg and support (see the strength check in the report).",
    "No cable-tie anchor: the 15 x 9 power hole itself carries the plug body's side loads.",
    # ---- final CAD QA (STL inspection), no position or fit dimension changed
    "Base: two places where solids met only along an edge (PN532 back stop, buzzer slot end walls) made the STL non-manifold; the parts now overlap.",
    "Base: nRF pocket roofs slope at 45 deg (they were 2.5 mm flat overhangs); the pocket is unchanged where the module sits.",
    "Base: ESP end wall and snap lip raised from 7.3 to 9.0 (lip 2.4 mm thick instead of 0.7); clearance over the module unchanged at 0.4.",
    "Base: SD slot mouth no longer flares downward (it left 0.4 mm of material at the floor edge).",
    "Base: left-wall vents now z 14-24 (were 16-27): they cut into the shelf ledge's corbel and left thin slivers.",
    "Base: PN532 channel walls, KY-013 guide and buzzer slot lips thickened from 1.2 to 1.6 mm.",
    "Shelf/strap: the strap's 1 mm tab in a 1.3 slot (0.57 mm walls either side) replaced by a 3.6 x 2.15 tab in a 4 mm notch through the cradle wall.",
    "Base: buzzer ear-slot end walls 1.6 mm (were 1.0).",
    "Lid: TFT screw pilot 2.4 deep (was 2.5) to keep 0.6 mm of skin under the lid face; use M2.5 x 4 screws, not longer.",
]
