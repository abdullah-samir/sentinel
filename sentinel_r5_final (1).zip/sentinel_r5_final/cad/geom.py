"""Geometry helpers on top of CadQuery. All solids are built in inner box coordinates (see params.py)."""
import math
import cadquery as cq
from cadquery import Vector as V


def S(wp):
    """Workplane / Shape -> single Shape (a lone solid inside a compound is unwrapped)."""
    if isinstance(wp, cq.Workplane):
        vals = [v for v in wp.vals() if isinstance(v, cq.Shape)]
        wp = vals[0] if len(vals) == 1 else cq.Compound.makeCompound(vals)
    if isinstance(wp, cq.Compound):
        sol = wp.Solids()
        if len(sol) == 1:
            return sol[0]
    return wp


def box(x0, x1, y0, y1, z0, z1):
    """Axis-aligned box from ranges."""
    return cq.Solid.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))


def cyl_z(cx, cy, z0, z1, d):
    return cq.Solid.makeCylinder(d / 2, z1 - z0, V(cx, cy, z0), V(0, 0, 1))


def cyl_y(cx, cz, y0, y1, d):
    return cq.Solid.makeCylinder(d / 2, y1 - y0, V(cx, y0, cz), V(0, 1, 0))


def cyl_x(cy, cz, x0, x1, d):
    return cq.Solid.makeCylinder(d / 2, x1 - x0, V(x0, cy, cz), V(1, 0, 0))


def cone_z(cx, cy, z0, z1, d0, d1):
    return cq.Solid.makeCone(d0 / 2, d1 / 2, z1 - z0, V(cx, cy, z0), V(0, 0, 1))


def _prism_xz(pts, y0, y1):
    """Prism from a polygon in the XZ plane (points (x, z)), extruded from y0 to y1."""
    wp = cq.Workplane("XZ", origin=(0, y0, 0)).polyline(pts).close().extrude(-(y1 - y0))
    return S(wp)


def _prism_yz(pts, x0, x1):
    """Prism from a polygon in the YZ plane (points (y, z)), extruded from x0 to x1."""
    wp = cq.Workplane("YZ", origin=(x0, 0, 0)).polyline(pts).close().extrude(x1 - x0)
    return S(wp)


def _prism_xy(pts, z0, z1):
    wp = cq.Workplane("XY", origin=(0, 0, z0)).polyline(pts).close().extrude(z1 - z0)
    return S(wp)


def teardrop_y(cx, cz, y0, y1, d):
    """Horizontal hole along y with a 45 deg pointed top, so it prints in a vertical wall without support."""
    r = d / 2
    c = cyl_y(cx, cz, y0, y1, d)
    k = r * math.sqrt(0.5)
    tri = _prism_xz([(cx - k, cz + k), (cx + k, cz + k), (cx, cz + r * math.sqrt(2))], y0, y1)
    return c.fuse(tri).clean()


def teardrop_x(cy, cz, x0, x1, d):
    r = d / 2
    c = cyl_x(cy, cz, x0, x1, d)
    k = r * math.sqrt(0.5)
    tri = _prism_yz([(cy - k, cz + k), (cy + k, cz + k), (cy, cz + r * math.sqrt(2))], x0, x1)
    return c.fuse(tri).clean()


def rrect_prism(x0, x1, y0, y1, z0, z1, r):
    """Box with vertical edges rounded to r."""
    wp = (cq.Workplane("XY", origin=((x0 + x1) / 2, (y0 + y1) / 2, z0))
          .rect(x1 - x0, y1 - y0).extrude(z1 - z0))
    if r > 0:
        wp = wp.edges("|Z").fillet(r)
    return S(wp)


def hex_prism_z(cx, cy, z0, z1, af, rot=0.0):
    """Hexagon (across flats af) prism along z; rot in degrees (0 = flats parallel to x)."""
    rr = af / math.sqrt(3)
    pts = [(cx + rr * math.cos(math.radians(30 + 60 * i + rot)), cy + rr * math.sin(math.radians(30 + 60 * i + rot))) for i in range(6)]
    return _prism_xy(pts, z0, z1)


def hex_prism_y(cx, cz, y0, y1, af, rot=0.0):
    rr = af / math.sqrt(3)
    pts = [(cx + rr * math.cos(math.radians(60 * i + rot)), cz + rr * math.sin(math.radians(60 * i + rot))) for i in range(6)]
    return _prism_xz(pts, y0, y1)


def wedge_under_x(x0, x1, y_wall, y_far, z_top):
    """45 deg corbel under a ledge that sticks out from a wall facing +y or -y.
    The ledge's underside is at z_top; it reaches from y_wall to y_far. Returns the triangular support prism."""
    depth = abs(y_far - y_wall)
    return _prism_yz([(y_wall, z_top), (y_far, z_top), (y_wall, z_top - depth)], x0, x1)


def wedge_under_y(y0, y1, x_wall, x_far, z_top):
    """Same as wedge_under_x for a ledge sticking out from a wall facing +x or -x."""
    depth = abs(x_far - x_wall)
    return _prism_xz([(x_wall, z_top), (x_far, z_top), (x_wall, z_top - depth)], y0, y1)


def pocket_45_roof_y(x0, x1, y_face, depth, z0, z1, e=0.05):
    """Recess cut into a wall face at y = y_face, going +y by depth, from z0 to z1. Its roof rises at 45 deg toward
    the face (z1 at the back of the pocket, z1 + depth at the face), so it prints without support."""
    return _prism_yz([(y_face - e, z0), (y_face + depth, z0), (y_face + depth, z1), (y_face - e, z1 + depth + e)], x0, x1)


def fuse_all(base, parts):
    """Boolean union of base with every part (multi-tool fuse handles overlapping tools)."""
    parts = [p for p in parts if p is not None]
    if not parts:
        return base
    return S(base.fuse(*parts).clean())


def cut_all(base, parts):
    parts = [p for p in parts if p is not None]
    if not parts:
        return base
    return S(base.cut(*parts).clean())


def translate(shape, dx=0, dy=0, dz=0):
    return shape.translate(V(dx, dy, dz))


def bbox(shape):
    bb = shape.BoundingBox()
    return (bb.xmin, bb.xmax, bb.ymin, bb.ymax, bb.zmin, bb.zmax)


def nonmanifold_edges(shape):
    """Edges shared by more than two faces (two bodies touching only along a line). They are legal in the B-rep but give
    a non-manifold STL, so every printed part must report none. Returns the midpoints of the offending edges."""
    from OCP.TopExp import TopExp
    from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
    from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE
    m = TopTools_IndexedDataMapOfShapeListOfShape()
    TopExp.MapShapesAndUniqueAncestors_s(shape.wrapped, TopAbs_EDGE, TopAbs_FACE, m)
    bad = []
    for i in range(1, m.Extent() + 1):
        if m.FindFromIndex(i).Extent() > 2:
            e = cq.Edge(m.FindKey(i))
            p = e.positionAt(0.5)
            bad.append((round(p.x, 2), round(p.y, 2), round(p.z, 2)))
    return bad
