"""Dimensioned engineering drawings of every printed part (A3 PDF + PNG per sheet), generated from the CAD solids.
All dimensions are taken from params.py / the solids, so they match the STL and STEP files exactly.
Datums for the base and lid: X0 = inside face of the left wall, Y0 = inside face of the front wall, Z0 = top of the floor."""
import os, math
import cadquery as cq
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from drawlib import *
from params import *
from base import build_base
from lid import build_lid
from shelf import build_shelf, build_nrf_strap, build_nrf_stop, build_fan_spacers, fan_holes, build_nic_rail, vent_holes
from coupon import build_coupon

HERE = os.path.dirname(os.path.abspath(__file__))
OUTD = os.path.join(HERE, "deliverables", "drawings")
os.makedirs(OUTD, exist_ok=True)
NSHEETS = 8


def fm(v):
    return fmt(v)


# ====================================================================== sheet 1: base plan
def sheet_base_plan(base, pdf):
    sh = Sheet("BASE - plan view", 1, NSHEETS, "Main body, printed floor-down. Scale 1:1 on A3")
    o = (42.0, 92.0)
    sh.place("t", "top", o, 1.0, base)
    sh.label("t", "PLAN VIEW (from above)   1:1", at=(o[0] - 2, 262))
    # overall
    sh.dim("t", (OUT["x0"], OUT["y0"], 0), (OUT["x1"], OUT["y0"], 0), -14, axis="h")
    sh.dim("t", (0, 0, 0), (L, 0, 0), -7, axis="h", text=f"{fm(L)} inside")
    sh.dim("t", (OUT["x0"], OUT["y0"], 0), (OUT["x0"], OUT["y1"], 0), -14, axis="v")
    sh.dim("t", (0, 0, 0), (0, W, 0), -7, axis="v", text=f"{fm(W)} inside")
    sh.dim("t", (OUT["x1"], REAR_IN, 0), (OUT["x1"], OUT_Y, 0), 7, axis="v", text="5 band")
    sh.leader("t", (OUT["x1"] - 1.0, 60, 0), "wall 2.0", (10, -6))
    sh.leader("t", (OUT["x1"] - 1.2, OUT["y0"] + 1.2, 0), f"R{fm(R_OUT)} outside, R{fm(R_IN)} inside", (10, -16))
    sh.text((o[0] - 2, o[1] - 2), "X0,Y0", size=FS * 0.8, ha="right", va="top", color=DIMC)
    sh.ax.plot([o[0]], [o[1]], marker="+", ms=8, color=DIMC, mew=0.6)
    # feature tags
    T = []
    for i, (x, y) in enumerate(PI_HOLES):
        T.append((f"P{i + 1}", (x, y), [(8, -9), (8, -8), (-2, -11), (9, -8)][i]))
    for i, (x, y) in enumerate(SHELF_POSTS):
        T.append((f"S{i + 1}", (x, y), [(-9, -7), (-10, -6)][i]))
    for i, p in enumerate(LID_POSTS):
        T.append((f"L{i + 1}", (p["x"], p["y"]), [(9, 8), (-10, 8), (12, -4), (-10, -9)][i]))
    T += [("E", (ESP["x0"] + ESP["w"] / 2, ESP["y0"] + 30), (0, 0)),
          ("B", (60.0, 18.0), (0, 0)),
          ("N", (2.0, 22.0), (8, 0)),
          ("Z", (108.3, 22.0), (-8, 0)),
          ("K", (78.0, 143.0), (0, -9)),
          ("LL", (1.0, 110.0), (9, 0)),
          ("RL", (122.0, 80.0), (-9, 0))]
    for lab, (x, y), d in T:
        if d == (0, 0):
            p = sh.M("t", (x, y, 0))
            sh.ax.add_patch(Circle(p, 2.6, fc="white", ec=DIMC, lw=0.5, zorder=5))
            sh.text(p, lab, size=FS * 0.82, color=DIMC, weight="bold")
        else:
            tag(sh, "t", (x, y, 0), lab, d)
    # feature table
    ins3 = f"M3 heat-set insert hole {fm(INSERT_M3['hole'])} x {fm(INSERT_M3['depth'])} deep"
    ins25 = f"M2.5 insert hole {fm(INSERT_M25['hole'])} x {fm(INSERT_M25['depth'])} deep"
    rows = []
    for i, (x, y) in enumerate(PI_HOLES):
        rows.append((f"P{i + 1}", "Pi standoff", fm(x), fm(y), f"dia {fm(PI_STANDOFF['d'])}, top Z {fm(PI['z0'])}; {ins25}"))
    rows.append(("S1", "Shelf post", fm(SHELF_POSTS[0][0]), fm(SHELF_POSTS[0][1]),
                 f"dia {fm(SHELF_POST_D)} (foot dia {fm(SHELF_POST_D + 3.5)}), top Z {fm(SHELF_Z)}; M3 insert"))
    rows.append(("S2", "Shelf post + web to wall", fm(SHELF_POSTS[1][0]), fm(SHELF_POSTS[1][1]), f"dia {fm(SHELF_POST_D)}, top Z {fm(SHELF_Z)}; M3 insert"))
    for i, p in enumerate(LID_POSTS):
        d = p.get("d", LID_POST_D)
        how = {"front": "45 deg corbel on the front wall", "band": "45 deg corbel on the band", "floor": "from the floor"}[p["wall"]]
        rows.append((f"L{i + 1}", "Lid post", fm(p["x"]), fm(p["y"]), f"dia {fm(d)}, Z {fm(p['z0'])}-{fm(H)}, {how}; M3 insert"))
    rows += [("E", "ESP32-S3 bed", f"{fm(ESP['x0'])}-{fm(ESP['x0'] + ESP['w'])}", f"{fm(ESP['y0'])}-{fm(ESP['y0'] + ESP['l'])}",
              f"pads Z 0-{fm(ESP_MOD['z'][0])}; end wall + snap lip top Z {fm(ESP_END_TOP)}, lip underside Z {fm(ESP_MOD['z'][1] + 0.4)}"),
             ("B", "Breadboard frame", f"{fm(BB['x0'] - BB_RIM['gap'])}-{fm(BB['x1'] + BB_RIM['gap'])}", f"0-{fm(BB['y1'] + BB_RIM['gap'])}",
              f"rim {fm(BB_RIM['w'])} wide x {fm(BB_RIM['h'])} high; back rim ends at X 81"),
             ("N", "PN532 slot", f"{fm(PN['x0'] - 0.3)}-{fm(PN['x0'] + PN['t'] + 0.3)}", f"0-{fm(PN['y1'] + 0.3)}",
              f"groove Z 0.8-3.8, front channel full height (Z 45), walls {fm(PN_WALL)}"),
             ("Z", "Buzzer ear slots", "106.5-113.9", "1.4-42.6", f"slots X 110-112.3, ears rest at Z {fm(BUZ['cz'] - BUZ['ear_w'] / 2)}"),
             ("K", "KY-013 ledge", f"{fm(KY['x0'] - 1.6)}-{fm(KY['x1'] + 0.5)}", "141-145", f"ledge top Z {fm(KY['z0'])}, end guide {fm(KY_GUIDE_T)}"),
             ("LL", "Left shelf ledges", f"0-{fm(LEDGE_W)}", "45-84, 93-141.5", f"top Z {fm(SHELF_Z)}, {fm(LEDGE_H)} deep + 45 deg corbel"),
             ("RL", "Right shelf ledge", f"{fm(L - LEDGE_W)}-{fm(L)}", "35-141.5", f"top Z {fm(SHELF_Z)}, {fm(LEDGE_H)} deep + 45 deg corbel")]
    sh.text((190, 270), "FEATURES (inner datums X0 / Y0 / Z0, see note 1)", size=FS * 1.05, ha="left", weight="bold")
    yb = table(sh, 190, 266, [("Tag", 9), ("Feature", 36), ("X", 21), ("Y", 24), ("Size / height / fastener", 120)], rows)
    sh.note((190, yb - 6), [
        "Notes",
        "1  X0 = inside face of the left wall, Y0 = inside face of the front wall, Z0 = top of the floor (2.0 thick).",
        "    Outer box X -2..125, Y -2..147, Z -2..59 (lid adds 2.0 above Z 59).",
        f"2  Heat-set inserts: M3 x 8 (OD 4.5) in {fm(INSERT_M3['hole'])} holes, M2.5 x 4 in {fm(INSERT_M25['hole'])} holes;",
        "    hole sizes to be confirmed on the fit-test coupon before printing the base.",
        "3  Back band (Y 142-147, from Z 28.5) carries all six antenna holes - see sheets 2 and 3.",
        "4  Printed floor-down, no supports: overhangs are 45 deg or short bridges; the one flat ledge is the 0.8 mm ESP snap lip.",
        "5  General tolerance of printed features +-0.2; mating clearances are built into the model.",
    ], size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet1_base_plan.png"))


# ====================================================================== sheet 2: base elevations
def wall_slab(base, axis, a, b):
    lo, hi = [-50.0, -50.0, -50.0], [200.0, 200.0, 200.0]
    i = "xyz".index(axis)
    lo[i], hi[i] = a, b
    return base.intersect(cq.Solid.makeBox(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2], cq.Vector(*lo)))


def sheet_base_elev(base, pdf):
    sh = Sheet("BASE - elevations", 2, NSHEETS, "Openings in the walls and the antenna band (wall faces only). Scale 1:1")
    cols = [("Tag", 11), ("Opening", 44), ("Size and position (X0 / Y0 / Z0 datums)", 108)]
    # ---------------- front (top left): u = x, v = z
    sh.place("f", "front", (45.0, 212.0), 1.0, wall_slab(base, "y", -WALL - 0.05, 0.05))
    sh.label("f", "FRONT  (viewed from the front)", at=(30, 281))
    sh.dim("f", (OUT["x0"], 0, H), (OUT["x1"], 0, H), 5, axis="h")
    sh.dim("f", (OUT["x0"], 0, OUT["z0"]), (OUT["x0"], 0, H), -6, axis="v")
    cw, ch = SW["cut"]
    tag(sh, "f", (SW["cx"] - cw / 2, 0, SW["cz"]), "KC", (-9, 4))
    tag(sh, "f", (F_LOW[0][0], 0, F_LOW[0][1] + 3), "F1", (-9, -3))
    tag(sh, "f", (F_UP[-1][0] + 2.2, 0, F_UP[-1][1] + F_UP[-1][3] - 3), "F2", (9, 3))
    rows = [("KC", "KCD11 rocker cut-out", f"{fm(cw)} x {fm(ch)}, centre X {fm(SW['cx'])}, Z {fm(SW['cz'])}"),
            ("F1", "lower vents", f"{len(F_LOW)} slots {fm(F_LOW[0][2])} x {fm(F_LOW[0][3])}, pitch 4.4, X {fm(F_LOW[0][0])}-{fm(F_LOW[-1][0] + F_LOW[-1][2])}, "
                                  f"Z {fm(F_LOW[0][1])}-{fm(F_LOW[0][1] + F_LOW[0][3])}"),
            ("F2", "upper vents", f"{len(F_UP)} slots {fm(F_UP[0][2])} x {fm(F_UP[0][3])}, pitch 4.4, X {fm(F_UP[0][0])}-{fm(F_UP[-1][0] + F_UP[-1][2])}, "
                                  f"Z {fm(F_UP[0][1])}-{fm(F_UP[0][1] + F_UP[0][3])}")]
    table(sh, 30, 196, cols, rows)
    # ---------------- back (bottom left): u = -x
    sh.place("b", "back", (45.0 + 125.0, 95.0), 1.0, wall_slab(base, "y", REAR_IN - 0.05, OUT_Y + 0.05))
    sh.label("b", "BACK  (viewed from behind; X runs right to left)", at=(30, 173))
    for hh in HOLES:
        p = sh.M("b", (hh["x"], OUT_Y, ROW_Z))
        sh.ax.plot([p[0], p[0]], [p[1] + 6, 156], color=DIMC, lw=0.25, ls=(0, (1, 1)))
        sh.text((p[0], 157), f"A{hh['n']}  X {fm(hh['x'])}", size=FS * 0.78, rot=90, va="bottom", color=DIMC)
    sh.dim("b", (0, OUT_Y, 0), (0, OUT_Y, ROW_Z), 6, axis="v")
    sh.dim("b", (0, OUT_Y, BAND_Z0), (0, OUT_Y, H), 13, axis="v", text=f"band Z {fm(BAND_Z0)}-{fm(H)}")
    x0, x1, z0, z1 = SD_SLOT
    tag(sh, "b", ((x0 + x1) / 2, OUT_Y, z0), "SD", (12, -6))
    tag(sh, "b", (EXH[0][0] + 1.1, OUT_Y, EXH[0][1] + 2), "EX", (9, -6))
    rows = [("A1-A2", "nRF24 jack holes", f"dia {fm(NRF_HOLE)} teardrop at X 16 / 35, Z {fm(ROW_Z)}; inside: pocket {fm(NRF_POCKET['w'])} x "
                                             f"{fm(NRF_POCKET['h'])} x {fm(NRF_POCKET['depth'])} deep, 45 deg roof"),
            ("A3-A6", "SMA bulkhead holes", f"dia {fm(SMA['hole'])} teardrop at X 54 / 73 / 92 / 110.5, Z {fm(ROW_Z)}; inside: spot face dia "
                                              f"{fm(SMA['spot_d'])} x {fm(SPOT_DEPTH)} (leaves {fm(SMA['clamp'])} to clamp)"),
            ("SD", "microSD slot", f"{fm(x1 - x0)} x {fm(z1 - z0)}, X {fm(x0)}-{fm(x1)}, Z {fm(z0)}-{fm(z1)}; outside mouth "
                                   f"{fm(x1 - x0 + 2 * SD_FLARE['side'])} x {fm(z1 - z0 + SD_FLARE['up'])}, {fm(SD_FLARE['depth'])} deep"),
            ("EX", "exhaust slots", f"{len(EXH)} slots {fm(EXH[0][2])} x {fm(EXH[0][3])}, pitch 4.4, X {fm(EXH[0][0])}-{fm(EXH[-1][0] + EXH[-1][2])}, "
                                    f"Z {fm(EXH[0][1])}-{fm(EXH[0][1] + EXH[0][3])}")]
    table(sh, 30, 80, cols, rows)
    # ---------------- left (top right): u = -y
    sh.place("l", "left", (232.0 + 147.0, 212.0), 1.0, wall_slab(base, "x", -WALL - 0.05, 0.05))
    sh.label("l", "LEFT SIDE  (viewed from the left)", at=(218, 281))
    sh.dim("l", (0, OUT["y1"], H), (0, OUT["y0"], H), 5, axis="h")
    y0, y1, z0, z1 = PWR
    tag(sh, "l", (0, (y0 + y1) / 2, z1), "PW", (0, 9))
    tag(sh, "l", (0, L_VENT[-1][0] + 1.1, L_VENT[-1][1] + L_VENT[-1][3]), "LV", (0, 9))
    rows = [("PW", "power plug hole", f"{fm(y1 - y0)} x {fm(z1 - z0)}, Y {fm(y0)}-{fm(y1)}, Z {fm(z0)}-{fm(z1)} (Pi USB-C at Y {fm(PI_USBC_Y)})"),
            ("LV", "vents", f"{len(L_VENT)} slots {fm(L_VENT[0][2])} x {fm(L_VENT[0][3])}, pitch 4.4, Y {fm(L_VENT[0][0])}-"
                            f"{fm(L_VENT[-1][0] + L_VENT[-1][2])}, Z {fm(L_VENT[0][1])}-{fm(L_VENT[0][1] + L_VENT[0][3])}")]
    table(sh, 218, 196, cols, rows)
    # ---------------- right (bottom right): u = y
    sh.place("r", "right", (234.0, 95.0), 1.0, wall_slab(base, "x", L - 0.05, L + WALL + 0.05))
    sh.label("r", "RIGHT SIDE  (viewed from the right)", at=(218, 173))
    bh = BUZ_HOLES
    tag(sh, "r", (L, R_VENT[0][0] + 1.1, R_VENT[0][1] + R_VENT[0][3]), "RV", (0, 8))
    tag(sh, "r", (L, BUZ["cy"] + bh["r"] + 1.25, BUZ["cz"]), "BZ", (9, 5))
    rows = [("RV", "vents", f"{len(R_VENT)} slots {fm(R_VENT[0][2])} x {fm(R_VENT[0][3])}, pitch 4.4, Y {fm(R_VENT[0][0])}-"
                            f"{fm(R_VENT[-1][0] + R_VENT[-1][2])}, Z {fm(R_VENT[0][1])}-{fm(R_VENT[0][1] + R_VENT[0][3])}"),
            ("BZ", "buzzer sound holes", f"{bh['n'] + 1}x dia {fm(bh['d'])}: centre Y {fm(BUZ['cy'])}, Z {fm(BUZ['cz'])}, "
                                         f"+ {bh['n']} on R{fm(bh['r'])} at 30 + k x 60 deg")]
    table(sh, 218, 80, cols, rows)
    sh.note((30, 52), ["Slots have flat tops bridged over 2.2 mm; holes in the band are teardrops (45 deg point up), so nothing needs support.",
                       "Z values are measured from Z0 = top of the floor; the bed side of the box is Z -2. Overall height 61."],
            size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet2_base_elevations.png"))


# ====================================================================== sheet 3: base sections
def half(shape, axis, value, keep):
    lo, hi = [-60.0, -60.0, -60.0], [220.0, 220.0, 220.0]
    i = "xyz".index(axis)
    if keep == "below":
        hi[i] = value
    else:
        lo[i] = value
    return shape.intersect(cq.Solid.makeBox(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2], cq.Vector(*lo)))


def sect(sh, key, shape, axis, value, ll, scale, window, title, beyond=True):
    """Section view. x-sections are seen from +x (view 'right', u = y), y-sections from -y (view 'front', u = x).
    Section faces hatched; edges beyond the cut drawn thin and grey."""
    view = "right" if axis == "x" else "front"
    keep = "below" if axis == "x" else "above"
    origin = (ll[0] - window[0] * scale, ll[1] - window[2] * scale)
    part = half(shape, axis, value, keep)
    sh.place(key, view, origin, scale, part if beyond else None, window=window, lw=0.3, color="#8c8c8c")
    sh.section(key, section_polys(shape, axis, value))
    sh.text((ll[0], ll[1] + (window[3] - window[2]) * scale + 8), title, size=FS * 0.95, ha="left", weight="bold")


def sheet_base_sections(base, pdf):
    sh = Sheet("BASE - sections", 3, NSHEETS, "Wall build-up, antenna band, posts and holders. Scales as noted")
    # A-A full section at x = 73 (through SMA hole A4)
    sect(sh, "A", base, "x", 73.0, (32, 196), 1.0, (-2.5, 147.5, -2.5, 60.0), "SECTION A-A  at X 73 (through hole A4)  1:1")
    sh.dim("A", (73, REAR_IN, H), (73, OUT_Y, H), 3, axis="h", text="5")
    sh.dim("A", (73, 147, OUT["z0"]), (73, 147, H), 8, axis="v")
    sh.leader("A", (73, 30.0, -1.0), "floor 2.0", (14, -8))
    sh.leader("A", (73, -1.0, 15.0), "walls 2.0", (12, -6))
    sh.leader("A", (73, REAR_IN + 1.5, BAND_Z0 - 1.5), "band underside 45 deg (no support)", (-36, -8))
    # B: band detail at x = 73, 2:1
    sect(sh, "B", base, "x", 73.0, (205, 185), 2.0, (134.0, 148.0, 22.0, 60.0), "DETAIL B  SMA hole A4, X 73  2:1")
    sh.dim("B", (73, REAR_IN, H), (73, OUT_Y, H), 3, axis="h", text="5")
    sh.text(sh.M("B", (73, 134.6, 57.0)), f"spot face {fm(SPOT_DEPTH)} deep", size=FS * 0.8, ha="left", color=DIMC)
    sh.dim("B", (73, OUT_Y, ROW_Z - SMA["spot_d"] / 2), (73, OUT_Y, ROW_Z + SMA["spot_d"] / 2), 5, axis="v", text=f"dia {fm(SMA['spot_d'])}")
    sh.dim("B", (73, OUT_Y, ROW_Z - SMA["hole"] / 2), (73, OUT_Y, ROW_Z + SMA["hole"] / 2), 12, axis="v", text=f"dia {fm(SMA['hole'])}")
    sh.text((205, 181), f"hole axis Z {fm(ROW_Z)}", size=FS * 0.8, ha="left", color=DIMC)
    # C: nRF pocket at x = 12, 2:1
    sect(sh, "C", base, "x", 12.0, (268, 185), 2.0, (134.0, 148.0, 22.0, 60.0), "DETAIL C  nRF pocket, X 12  2:1")
    p = NRF_POCKET
    sh.dim("C", (12, REAR_IN, p["z0"]), (12, REAR_IN + p["depth"], p["z0"]), -7, axis="h", text=f"{fm(p['depth'])}")
    sh.dim("C", (12, REAR_IN + p["depth"], p["z0"]), (12, REAR_IN + p["depth"], p["z0"] + p["h"]), 9, axis="v", text=f"{fm(p['h'])}")
    sh.leader("C", (12, REAR_IN + 1.2, p["z0"] + p["h"] + 1.4), "45 deg roof", (-14, 12))
    sh.text((268, 181), f"pocket Z {fm(p['z0'])}-{fm(p['z0'] + p['h'])}", size=FS * 0.8, ha="left", color=DIMC)
    # D: lid post L1 at x = 12, 2:1
    sect(sh, "D", base, "x", 12.0, (335, 196), 2.0, (-3.0, 10.0, 34.0, 60.0), "DETAIL D  lid post L1, X 12  2:1")
    lp = LID_POSTS[0]
    sh.dim("D", (12, lp["y"] - INSERT_M3["hole"] / 2, H), (12, lp["y"] + INSERT_M3["hole"] / 2, H), 3, axis="h",
           text=f"dia {fm(INSERT_M3['hole'])}")
    sh.dim("D", (12, 10, H - INSERT_M3["depth"]), (12, 10, H), 3, axis="v", text=f"{fm(INSERT_M3['depth'])}")
    sh.leader("D", (12, 3.0, lp["z0"] - 1.0), "45 deg corbel", (10, -12))
    sh.leader("D", (12, lp["y"] + 2.6, H - 0.3), "0.6 x 45 deg lead-in", (12, -18))
    # E: ESP end wall + snap lip at x = 95, 4:1
    sect(sh, "E", base, "x", 95.0, (36, 98), 4.0, (112.0, 122.5, -2.5, 11.0), "DETAIL E  ESP end wall, snap lip, X 95  4:1")
    ye = ESP["y0"] + ESP["l"]
    zm0, zm1 = ESP_MOD["z"]
    sh.phantom("E", [(95, 112.0, zm1), (95, ye, zm1), (95, ye, zm0), (95, 112.0, zm0)], "ESP module end (ref.)", dxy=(1, 2))
    sh.dim("E", (95, ye - 0.5, ESP_END_TOP), (95, ye + 0.3, ESP_END_TOP), 4, axis="h", text="0.8")
    sh.dim("E", (95, ye + 0.3, ESP_END_TOP), (95, ye + 2.3, ESP_END_TOP), 4, axis="h", text="2")
    sh.dim("E", (95, 122.0, 0), (95, 122.0, zm1 + 0.4), 3, axis="v")
    sh.dim("E", (95, 122.0, 0), (95, 122.0, ESP_END_TOP), 11, axis="v")
    sh.leader("E", (95, ye - 0.3, zm1 + 0.2), "0.4 over the module", (-6, 20))
    # F: buzzer slots at y = 6, 2:1
    e0 = BUZ["cz"] - BUZ["ear_w"] / 2
    ztop = e0 + BUZ["ear_w"] + 3.5                       # top of the slot lips
    sect(sh, "F", base, "y", 6.0, (122, 98), 2.0, (104.0, 125.5, -2.5, ztop + 2.4), "DETAIL F  buzzer ear slot, Y 6  2:1")
    xs = 110.0 + BUZ["ear_t"] + 0.3
    sh.dim("F", (110.0, 6, ztop + 1.0), (xs, 6, ztop + 1.0), 2, axis="h", text="2.3")
    sh.leader("F", (xs + BUZ_LIP_T, 6, (e0 + ztop) / 2), f"lip {fm(BUZ_LIP_T)}", (22, 14))
    sh.dim("F", (104.0, 6, 0), (104.0, 6, e0), -3, axis="v")
    sh.dim("F", (104.0, 6, 0), (104.0, 6, ztop), -10, axis="v")
    # G: PN532 groove at y = 20, 4:1
    sect(sh, "G", base, "y", 20.0, (205, 108), 4.0, (-2.5, 6.0, -2.5, 6.0), "DETAIL G  PN532 groove, Y 20  4:1")
    sh.dim("G", (PN["x0"] - 0.3, 20, 3.8), (PN["x0"] + PN["t"] + 0.3, 20, 3.8), 4, axis="h", text="2.2")
    sh.leader("G", (PN["x0"] + PN["t"] + 0.3 + PN_WALL / 2, 20, 3.8), f"wall {fm(PN_WALL)}", (12, 9))
    sh.dim("G", (6.0, 20, 0), (6.0, 20, 3.8), 3, axis="v")
    sh.dim("G", (-2.5, 20, 0), (-2.5, 20, PN["z0"]), -3, axis="v", text=fm(PN["z0"]))
    # H: Pi standoff P2 at x = 7, 4:1
    sect(sh, "H", base, "x", 7.0, (270, 108), 4.0, (75.0, 86.0, -2.5, 6.0), "DETAIL H  Pi standoff P2, X 7  4:1")
    yc = PI_HOLES[1][1]
    sh.dim("H", (7, yc - PI_STANDOFF["d"] / 2, PI["z0"]), (7, yc + PI_STANDOFF["d"] / 2, PI["z0"]), 9, axis="h", text=f"dia {fm(PI_STANDOFF['d'])}")
    sh.dim("H", (7, yc - INSERT_M25["hole"] / 2, PI["z0"]), (7, yc + INSERT_M25["hole"] / 2, PI["z0"]), 3, axis="h",
           text=f"dia {fm(INSERT_M25['hole'])}")
    sh.dim("H", (7, 86.0, PI["z0"] - INSERT_M25["depth"]), (7, 86.0, PI["z0"]), 3, axis="v", text=fm(INSERT_M25["depth"]))
    sh.dim("H", (7, 75.0, 0), (7, 75.0, PI["z0"]), -3, axis="v")
    sh.note((330, 170), ["Section faces hatched; grey lines are edges",
                         "beyond the cut. Brown chain line = bought",
                         "part, for reference only.",
                         "All values in mm from the X0 / Y0 / Z0",
                         "datums (sheet 1)."], size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet3_base_sections.png"))


# ====================================================================== sheet 4: lid
def sheet_lid(lid, pdf):
    sh = Sheet("LID", 4, NSHEETS, "Printed outside face down on the bed. Scale 1:1 (details 2:1 / 4:1)")
    o = (42.0, 100.0)
    sh.place("t", "top", o, 1.0, lid, hidden=True)
    sh.label("t", "TOP VIEW (outside face; lips and bosses underneath shown dashed)   1:1", at=(o[0] - 2, 262))
    sh.dim("t", (OUT["x0"], OUT["y0"], H), (OUT["x1"], OUT["y0"], H), -10, axis="h")
    sh.dim("t", (OUT["x0"], OUT["y0"], H), (OUT["x0"], OUT["y1"], H), -10, axis="v")
    ow, oh = OPEN
    sh.dim("t", (GCX - ow / 2, GCY + oh / 2, H), (GCX + ow / 2, GCY + oh / 2, H), 2, axis="h")
    sh.dim("t", (GCX + ow / 2, GCY - oh / 2, H), (GCX + ow / 2, GCY + oh / 2, H), 4, axis="v")
    T = [("O", (GCX - ow / 2, GCY), (-9, 6))]
    for i, (x, y) in enumerate(BTNS):
        T.append((f"B{i + 1}", (x, y), [(-11, -2), (0, 0), (0, 0), (-11, 3), (0, 0)][i]))
    for i, p in enumerate(LID_POSTS):
        T.append((f"H{i + 1}", (p["x"], p["y"]), [(9, 7), (-10, 7), (-9, -7), (-9, -7)][i]))
    for i, (hx, hy) in enumerate(TFT_HOLES):
        T.append((f"T{i + 1}", (TFT_X0 + hx, TFT_Y0 + hy), [(-8, -7), (8, -7), (-8, 7), (8, 7)][i]))
    T += [("V1", (LID_VENTS[2][0] + 1.1, 60.0), (0, 0)), ("V2", (LID_VENTS[9][0] + 1.1, 116.0), (0, 0)),
          ("LP", (LID_LIP["gap"] + 0.8, 70.0), (9, 0))]
    for lab, (x, y), d in T:
        if d == (0, 0):
            p = sh.M("t", (x, y, H))
            sh.ax.add_patch(Circle(p, 2.6, fc="white", ec=DIMC, lw=0.5, zorder=5))
            sh.text(p, lab, size=FS * 0.82, color=DIMC, weight="bold")
        else:
            tag(sh, "t", (x, y, H), lab, d)
    rows = [("O", "Screen opening", fm(GCX), fm(GCY), f"{fm(ow)} x {fm(oh)} (glass {fm(GLASS[0])} x {fm(GLASS[1])} + 0.5 all round)")]
    for i, (x, y) in enumerate(BTNS):
        rows.append((f"B{i + 1}", "Button hole", fm(x), fm(y), f"dia {fm(BTN['hole'])} for PBS-11A (thread {fm(BTN['thr_d'])}), pitch {fm(BTN['pitch'])}"))
    for i, p in enumerate(LID_POSTS):
        rows.append((f"H{i + 1}", "Screw hole", fm(p["x"]), fm(p["y"]), f"dia {fm(M3_CLEAR)} for M3 x 8 button head into the M3 insert"))
    for i, (hx, hy) in enumerate(TFT_HOLES):
        rows.append((f"T{i + 1}", "TFT boss", fm(TFT_X0 + hx), fm(TFT_Y0 + hy),
                     f"dia {fm(TFT_BOSS['d'])}, Z {fm(TFT_TOP)}-{fm(H)}; pilot dia {fm(TFT_BOSS['pilot'])} x {fm(TFT_BOSS['depth'])} for M2.5 x 4"))
    v1, v2 = LID_VENTS[0], LID_VENTS[5]
    rows += [("V1", "Vents over the sled", f"{fm(v1[0])}-{fm(LID_VENTS[4][0] + v1[2])}", f"{fm(v1[1])}-{fm(v1[1] + v1[3])}",
              f"5 slots {fm(v1[2])} x {fm(v1[3])}, pitch 4.4"),
             ("V2", "Vents behind screen", f"{fm(v2[0])}-{fm(LID_VENTS[-1][0] + v2[2])}", f"{fm(v2[1])}-{fm(v2[1] + v2[3])}",
              f"10 slots {fm(v2[2])} x {fm(v2[3])}, pitch 4.4"),
             ("LP", "Locating lips", "", "", f"{fm(LID_LIP['w'])} wide x {fm(LID_LIP['h'])} deep, {fm(LID_LIP['gap'])} inside the walls; gaps at posts and corners")]
    sh.text((190, 270), "FEATURES (same X0 / Y0 datums as the base)", size=FS * 1.05, ha="left", weight="bold")
    yb = table(sh, 190, 266, [("Tag", 9), ("Feature", 36), ("X", 21), ("Y", 21), ("Size / fastener", 123)], rows)
    # section through the button row and the lip, 2:1
    sect(sh, "S1", lid, "y", 13.0, (190, yb - 32), 2.0, (-2.5, 44.0, 55.5, 61.5), "SECTION J-J at Y 13 (button B1, left lip)  2:1", beyond=False)
    sh.dim("S1", (-2.0, 13, H), (-2.0, 13, H + LID_T), -3, axis="v", text="2")
    sh.dim("S1", (LID_LIP["gap"], 13, H - LID_LIP["h"]), (LID_LIP["gap"] + LID_LIP["w"], 13, H - LID_LIP["h"]), -6, axis="h",
           text=fm(LID_LIP["w"]))
    sh.dim("S1", (LID_LIP["gap"] + LID_LIP["w"], 13, H - LID_LIP["h"]), (LID_LIP["gap"] + LID_LIP["w"], 13, H), 3, axis="v",
           text=fm(LID_LIP["h"]))
    sh.dim("S1", (BTNS[0][0] - BTN["hole"] / 2, 13, H + LID_T), (BTNS[0][0] + BTN["hole"] / 2, 13, H + LID_T), 3, axis="h",
           text=f"dia {fm(BTN['hole'])}")
    # section through two TFT bosses, 4:1
    yt = TFT_Y0 + TFT_HOLES[0][1]
    sect(sh, "S2", lid, "y", yt, (300, yb - 40), 4.0, (31.0, 41.0, 56.5, 61.5), f"SECTION K-K at Y {fm(yt)} (boss T1)  4:1", beyond=False)
    xb = TFT_X0 + TFT_HOLES[0][0]
    sh.dim("S2", (xb - TFT_BOSS["pilot"] / 2, yt, TFT_TOP), (xb + TFT_BOSS["pilot"] / 2, yt, TFT_TOP), -4, axis="h", text=f"dia {fm(TFT_BOSS['pilot'])}")
    sh.dim("S2", (xb + TFT_BOSS["d"] / 2, yt, TFT_TOP), (xb + TFT_BOSS["d"] / 2, yt, TFT_TOP + TFT_BOSS["depth"]), 4, axis="v",
           text=fm(TFT_BOSS["depth"]))
    sh.dim("S2", (31.0, yt, TFT_TOP), (31.0, yt, H), -3, axis="v", text="1")
    sh.note((190, yb - 62), ["Notes",
                             "1  Print the lid outside-face down: the face you see is the smooth bed side; lips and bosses point up.",
                             f"2  TFT screws M2.5 x 4 max: the pilot stops {fm(H + LID_T - TFT_TOP - TFT_BOSS['depth'])} below the outside face.",
                             "3  Button nuts are fitted from below; neighbours sit 22 apart (see the report for nut clearance).",
                             "4  Glass of the 1.8 in TFT lies in the opening, flush with the outside face (TFT PCB top at Z 58)."],
            size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet4_lid.png"))


# ====================================================================== sheet 5: shelf
def sheet_shelf(shelf, pdf):
    sh = Sheet("RADIO SHELF", 5, NSHEETS, "Plate + nRF24 cradle + pegs for the removable NIC rails, one piece. 1:1 / 2:1")
    o = (40.0, 112.0)
    sh.place("t", "top", o, 1.0, shelf)
    sh.label("t", "TOP VIEW   1:1", at=(o[0] - 2, 272))
    sh.dim("t", (SHELF_X[0], SHELF_BACK, ST), (SHELF_X[1], SHELF_BACK, ST), 6, axis="h")
    sh.dim("t", (SHELF_X[0], NIC_PLATE_Y0, ST), (SHELF_X[0], SHELF_BACK, ST), -8, axis="v")
    vh = vent_holes()
    inzone = lambda x, y, z: z[0] <= x <= z[1] and z[2] <= y <= z[3]
    rng = lambda v: (f"{min(v):.1f}" if max(v) - min(v) < 0.05 else f"{min(v):.0f}-{max(v):.0f}") if v else "-"
    T = [("FN", (FAN["cx"], FAN["cy"]), (0, 0)), ("SL", ((SLOT[0] + SLOT[1]) / 2, (SLOT[2] + SLOT[3]) / 2), (0, 0)),
         ("CO", (80.0, 133.0), (0, 0)), ("PH", SHELF_POSTS[0], (-9, -7)), ("PH", SHELF_POSTS[1], (-10, 4)),
         ("PG", (NRF_STOP["pegs"][1], (NRF_STOP["y0"] + NRF_STOP["y1"]) / 2), (0, -9)), ("LIP", (30.0, 46.0), (0, -9)),
         ("CR", (25.5, 129.0), (0, 0)), ("IN", STRAP["screw"], (-2, 9)), ("NO", (44.3, 129.0), (5, 10)),
         ("NP", NIC_PEGS[0], (-9, -6)), ("NP", NIC_PEGS[2], (9, -6)),
         ("VH", vh[1], (-10, 6)), ("VH", vh[-1], (10, 6))]
    for lab, (x, y), d in T:
        if d == (0, 0):
            p = sh.M("t", (x, y, ST))
            sh.ax.add_patch(Circle(p, 2.9, fc="white", ec=DIMC, lw=0.5, zorder=5))
            sh.text(p, lab, size=FS * 0.75, color=DIMC, weight="bold")
        else:
            tag(sh, "t", (x, y, ST), lab, d, r=2.9)
    rows = [("", "Plate", f"{fm(SHELF_X[0])}-{fm(SHELF_X[1])}", f"{fm(NIC_PLATE_Y0)}-{fm(SHELF_BACK)}",
             f"Z {fm(SHELF_Z)}-{fm(ST)} ({fm(SHELF_T)} thick); front edge Y {fm(SHELF_FRONT_L)} / {fm(SHELF_FRONT_R)} / {fm(NIC_PLATE_Y0)}, "
             f"steps at X {fm(SHELF_STEP_X)} and {fm(NIC_PLATE_X)}"),
            ("FN", "Fan opening + 4 holes", fm(FAN["cx"]), fm(FAN["cy"]),
             f"dia {fm(FAN_OPEN_D)}; holes dia {fm(M3_CLEAR)} on {fm(FAN['pitch'])} square, countersunk dia {fm(M3_CSK['d'] + 0.4)} (M3 x 20 CSK)"),
            ("SL", "Jumper slot", f"{fm(SLOT[0])}-{fm(SLOT[1])}", f"{fm(SLOT[2])}-{fm(SLOT[3])}", "through, screen jumpers to the ESP header"),
            ("CO", "KY-013 lift cut-out", f"{fm(CUT[0])}-{fm(CUT[1])}", f"{fm(CUT[2])}-back", "open to the back edge; strip X 116-122.5 ends at Y 138"),
            ("PH", "Fixing holes", "70 / 119.5", "53 / 116", f"dia {fm(M3_CLEAR)}: M3 x 8 button head into the inserts in posts S1 / S2"),
            ("PG", "Stop-bar peg holes", "10 / 25.5 / 41", fm((NRF_STOP['y0'] + NRF_STOP['y1']) / 2), f"dia {fm(NRF_STOP['peg_d'] + 0.3)} through"),
            ("LIP", "Front lip", f"{fm(SHELF_LIP[0])}-{fm(SHELF_LIP[1])}", f"{fm(SHELF_LIP[2])}-{fm(SHELF_LIP[3])}", f"{fm(SHELF_LIP[4])} high"),
            ("NP", "NIC rail pegs (4)", f"{fm(NIC_PEGS[0][0])} / {fm(NIC_PEGS[2][0])}",
             f"{fm(NIC_PEGS[0][1])}, {fm(NIC_PEGS[1][1])} / {fm(NIC_PEGS[2][1])}, {fm(NIC_PEGS[3][1])}",
             f"dia {fm(NIC_PEG['d'])} x {fm(NIC_PEG['h'])} high, {fm(NIC_PEG['chamfer'])} chamfer; the rails drop onto them"),
            ("VH", f"Vent holes ({len(vh)})", " / ".join(rng([x for x, y in vh if inzone(x, y, z)]) for z in SHELF_VENTS["zones"]),
             " / ".join(rng([y for x, y in vh if inzone(x, y, z)]) for z in SHELF_VENTS["zones"]),
             f"hexagons {fm(SHELF_VENTS['af'])} across flats, {fm(SHELF_VENTS['web'])} webs; only in these two zones"),
            ("CR", "nRF24 cradle", f"{fm(SHELF_X[0])}-{fm(CUT[0])}", f"{fm(CRADLE['y0'])}-{fm(CRADLE['y1'])}",
             f"block top Z {fm(CRADLE['top'])}, walls to Z {fm(CRADLE['wall_top'])}, channels 16.1 at X 16 / 35"),
            ("IN", "Strap insert hole", fm(STRAP["screw"][0]), fm(STRAP["screw"][1]), f"dia {fm(INSERT_M3['hole'])} x {fm(INSERT_M3['depth'])} (M3 x 8 insert)"),
            ("NO", "Strap tab notch", f"{fm(NRF_X[1] + 8.05)}-{fm(CUT[0])}", f"{fm(STRAP['screw'][1] - STRAP_NOTCH['w'] / 2)}-"
             f"{fm(STRAP['screw'][1] + STRAP_NOTCH['w'] / 2)}", f"{fm(STRAP_NOTCH['depth'])} deep from the wall top")]
    sh.text((185, 278), "FEATURES (base datums; shelf sits on the ledges at Z 28.5)", size=FS * 1.05, ha="left", weight="bold")
    yb = table(sh, 185, 274, [("Tag", 9), ("Feature", 36), ("X", 24), ("Y", 24), ("Size / notes", 127)], rows, size=FS * 0.78, row_h=4.3)
    # front view: u = x, v = z
    sh.place("f", "front", (40.0, 58.0 - SHELF_Z), 1.0, shelf)
    sh.label("f", "FRONT VIEW  1:1", at=(38, 92))
    sh.dim("f", (SHELF_X[0], 0, SHELF_Z), (SHELF_X[0], 0, CRADLE["wall_top"]), -4, axis="v")
    sh.dim("f", (SHELF_X[1], 0, SHELF_Z), (SHELF_X[1], 0, ST + NIC_PEG["h"]), 4, axis="v")
    # cradle section at y = 129, 2:1
    sect(sh, "Q", shelf, "y", 129.0, (190, 150), 2.0, (0.0, 46.0, 28.0, 46.5), "SECTION N-N at Y 129 (cradle, insert, notch)  2:1",
         beyond=False)
    sh.dim("Q", (NRF_X[0] - 8.05, 129, CRADLE["wall_top"]), (NRF_X[0] + 8.05, 129, CRADLE["wall_top"]), 3, axis="h", text="16.1")
    sh.dim("Q", (46.0, 129, SHELF_Z), (46.0, 129, CRADLE["top"]), 3, axis="v")
    sh.dim("Q", (46.0, 129, SHELF_Z), (46.0, 129, CRADLE["wall_top"]), 10, axis="v")
    sh.note((190, 132), ["The WN722N boards ride in two separate rails (sheet 6) that drop onto the 4 pegs NP;",
                         "nothing is fixed to the shelf in front of the boards, so their USB ends hang free.",
                         "Vent holes only where the plate is well supported; the area between the fan opening,",
                         "the slot and the cut-out stays solid (bending check in the report).",
                         "nRF modules rest on the cradle block (Z 40.85) and pass the band in the pocket."], size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet5_shelf.png"))


# ====================================================================== sheet 6: NIC rails
def sheet_rails(rail_l, rail_r, pdf):
    w = NIC_PCB_W
    sh = Sheet("NIC RAILS (removable)", 6, NSHEETS, f"WN722N rails; right rail shown for a {fm(w)} mm board. 1:1 / 2:1 / 8:1")
    r = NIC_RAIL
    g = nic_right()
    # left rail, seen from inside (from +x): view 'right', u = y, v = z
    sh.place("li", "right", (30.0 - r["y0"], 205.0 - ST), 1.0, rail_l)
    sh.label("li", "LEFT RAIL (antenna side) - inside face  1:1", at=(28, 270))
    sh.dim("li", (r["wl"][1], r["y0"], ST), (r["wl"][1], r["y1_l"], ST), -6, axis="h")
    sh.dim("li", (r["wl"][1], r["y1_l"], ST), (r["wl"][1], r["y1_l"], r["top"]), 5, axis="v")
    sh.dim("li", (r["wl"][1], r["y1_l"], ST), (r["wl"][1], r["y1_l"], r["lidstop_top"]), 12, axis="v")
    sh.leader("li", (r["wl"][1], r["lidstop_y"][0], r["lidstop_top"]), "lid stops (0.3 under the lid)", (8, 6))
    sh.leader("li", (r["wl"][1], r["y0"] + 1.0, ST + 12.0), "front stop", (-4, 22))
    # right rail, seen from inside (from -x): view 'left', u = -y, v = z
    sh.place("ri", "left", (175.0 + r["y1_r"], 205.0 - ST), 1.0, rail_r)
    sh.label("ri", f"RIGHT RAIL (button side, {fm(w)} mm version) - inside face  1:1", at=(160, 270))
    sh.dim("ri", (g["recess"], r["y1_r"], ST), (g["recess"], r["y0"], ST), -6, axis="h")
    sh.dim("ri", (g["recess"], r["y0"], ST), (g["recess"], r["y0"], r["top_r"]), 5, axis="v")
    sh.leader("ri", (g["recess"], R_VENT[2][0], 44.0), "6 windows behind the right-wall vents", (-10, 22))
    # section through both rails and both boards at y = 60, 2:1
    both = cq.Compound.makeCompound([rail_l, rail_r])
    sect(sh, "S", both, "y", 60.0, (30, 70), 2.0, (r["wl"][0] - 2.0, SHELF_X[1] + 1.0, 30.0, 59.5),
         f"SECTION P-P at Y 60, {fm(w)} mm boards in place  2:1", beyond=False)
    for zp in WN_PCB_Z:
        sh.phantom("S", [(NIC_X0, 60, zp), (NIC_X0 + w, 60, zp), (NIC_X0 + w, 60, zp + 1.6), (NIC_X0, 60, zp + 1.6), (NIC_X0, 60, zp)])
        sh.text(sh.M("S", (NIC_X0 + w / 2, 60, zp + 0.8)), f"WN722N PCB, Z {fm(zp)}", size=FS * 0.7, color="#a0522d")
    sh.dim("S", (r["wl"][0], 60, r["top"]), (r["wl"][1], 60, r["top"]), 3, axis="h", text=fm(r["wl"][1] - r["wl"][0]))
    sh.dim("S", (g["recess"], 60, r["top_r"]), (g["outer"], 60, r["top_r"]), 3, axis="h", text=fm(g["outer"] - g["recess"]))
    sh.dim("S", (r["wl"][1], 60, ST), (g["kerb"], 60, ST), -5, axis="h", text=f"{fm(g['kerb'] - r['wl'][1])} = board + 0.5")
    # detail Q: left rib profile, lower board, 8:1
    zp = WN_PCB_Z[0]
    xw = r["wl"][1]
    sect(sh, "D", rail_l, "y", 60.0, (140, 62), 8.0, (xw - 3.0, xw + 4.0, zp - 2.5, zp + 4.0),
         "DETAIL Q  left rail, lower board  8:1", beyond=False)
    sh.phantom("D", [(NIC_X0, 60, zp), (xw + 4.0, 60, zp), (xw + 4.0, 60, zp + 1.6), (NIC_X0, 60, zp + 1.6), (NIC_X0, 60, zp)], "PCB",
               dxy=(16, 4))
    sh.dim("D", (xw + 3.5, 60, zp - r["sup_gap"]), (xw + 3.5, 60, zp), 4, axis="v", text=f"{fm(r['sup_gap'])} gap")
    sh.dim("D", (xw + 3.5, 60, zp + 1.6), (xw + 3.5, 60, zp + 1.6 + r["hold_gap"]), 4, axis="v", text=f"{fm(r['hold_gap'])} gap")
    sh.dim("D", (xw, 60, zp - 2.5), (xw + r["rib"], 60, zp - 2.5), -4, axis="h", text=fm(r["rib"]))
    sh.dim("D", (xw, 60, zp + 3.6), (NIC_X0, 60, zp + 3.6), 3, axis="h", text=fm(r["gap"]))
    # detail R: right rail profile (ledge, kerb, plunger recess), lower board, 8:1
    xk, xr = g["kerb"], g["recess"]
    sect(sh, "R", rail_r, "y", 60.0, (300, 62), 8.0, (xk - 4.0, xr + 2.5, zp - 4.0, zp + 5.0),
         "DETAIL R  right rail, lower board  8:1", beyond=False)
    xe = xk - r["gap"]                                   # PCB edge, nominal
    sh.phantom("R", [(xk - 4.0, 60, zp), (xe, 60, zp), (xe, 60, zp + 1.6), (xk - 4.0, 60, zp + 1.6)], "PCB", dxy=(2, -9))
    bt = NIC_BTN
    sh.phantom("R", [(xe - bt["edge_band"], 60, zp + 1.6), (xe - bt["edge_band"], 60, zp + 1.6 + bt["h"]),
                     (xe + bt["out"], 60, zp + 1.6 + bt["h"]), (xe + bt["out"], 60, zp + 1.6), (xe - bt["edge_band"], 60, zp + 1.6)],
               "button envelope", dxy=(-26, 10))
    sh.leader("R", (xk - r["rib"] / 2, 60, zp - r["sup_gap"]), f"ledge: {fm(r['rib'])} under the board", (-30, -14))
    sh.dim("R", (xk, 60, zp + 4.5), (xr, 60, zp + 4.5), 3, axis="h", text=fm(r["recess"]))
    sh.leader("R", (xk, 60, zp + 0.6), f"kerb: side stop, top {fm(r['kerb'])} above the PCB underside", (-36, 8))
    sh.leader("R", (xr, 60, zp + 3.0), f"{fm(xr - xk - bt['out'])} clear of the plunger", (5, 14))
    sh.note((300, 56), [f"Button envelope: {fm(bt['h'])} high, plunger {fm(bt['out'])} past the PCB edge; clearances",
                        "given with the board pushed against the kerb (worst case)."], size=FS * 0.72)
    rows = [("Wall", f"left {fm(r['wl'][1] - r['wl'][0])} (X {fm(r['wl'][0])}-{fm(r['wl'][1])}); right: from the recess face to "
                     f"X {fm(g['outer'])} (table below)"),
            ("Length", f"left Y {fm(r['y0'])}-{fm(r['y1_l'])} (open behind: RP-SMA jacks), right Y {fm(r['y0'])}-{fm(r['y1_r'])}"),
            ("Height", f"left Z {fm(r['top'])}, lid stops Z {fm(r['lidstop_top'])}; right Z {fm(r['top_r'])} (under the lid lip)"),
            ("Left ribs", f"{fm(r['rib'])} over the board, 45 deg undersides; {fm(r['sup_gap'])} under, {fm(r['hold_gap'])} over each PCB"),
            ("Right side", f"ledge {fm(r['rib'])} under the board; kerb {fm(r['kerb'])} high; recess {fm(r['recess'])}; nothing over the board"),
            ("Channel", f"board width + {fm(2 * r['gap'])} ({fm(r['gap'])} each side when centred)"),
            ("Front stops", f"0.2 in front of the PCB edge (Y {fm(r['stop_y1'])}); boards exit at the back"),
            ("Feet", f"flange {fm(r['flange'][0])} x {fm(r['flange'][1])}; bosses dia {fm(NIC_PEG['boss_d'])} x {fm(NIC_PEG['boss_h'])} with "
                     f"dia {fm(NIC_PEG['hole'])} x {fm(NIC_PEG['hole_depth'])} peg holes, 0.4 lead-in"),
            ("", f"right rail's front boss {fm(NIC_PEG['boss_h_low'])} high, hole through (it sits under the lower board)"),
            ("Hold-down", "no screws: 4 pegs locate the rails, the lid keeps them down (0.3 play)")]
    sh.text((262, 270), "RAIL FEATURES", size=FS * 1.0, ha="left", weight="bold")
    yb = table(sh, 262, 266, [("Item", 18), ("Value", 124)], rows, size=FS * 0.72, row_h=4.2)
    vrows = []
    for v in NIC_PCB_W_VARIANTS:
        gv = nic_right(v)
        vrows.append((f"{v:.1f}", f"sentinel_r5_nic_rail_right_w{v:.1f}.stl", fm(gv["kerb"]), fm(gv["recess"]),
                      fm(gv["outer"] - gv["recess"])))
    sh.text((262, yb - 7), "RIGHT RAIL VERSIONS (measure the board, round up to the next 0.5 mm)", size=FS * 0.9, ha="left", weight="bold")
    yv = table(sh, 262, yb - 10, [("Board", 13), ("STL", 58), ("Kerb X", 19), ("Recess X", 20), ("Wall", 17)], vrows,
               size=FS * 0.72, row_h=4.2)
    sh.note((262, yv - 5), ["Print the rails upright on their feet, 5 mm brim, 100 % infill.",
                            "A board up to 0.5 mm narrower than its version still rests 1.0 mm on each side.",
                            "Assembly: slide both WN722N in from the back until they touch the front",
                            "stops, plug the USB connectors on, lower the stack onto the 4 pegs.",
                            "Service: lid off, unscrew the two RA plugs, lift the stack out."], size=FS * 0.8)
    sh.save(pdf, os.path.join(OUTD, "sheet6_nic_rails.png"))


# ====================================================================== sheet 7: small parts + coupon
def sheet_small(strap, stop, spacer, coupon, pdf):
    sh = Sheet("SMALL PARTS + FIT COUPON", 7, NSHEETS, "nRF strap, nRF stop bar, fan spacers (2:1) and the fit-test coupon (1:1)")
    st, c = STRAP, CRADLE
    sy = st["screw"][1]
    # strap: top view and front view, 2:1
    sh.place("st", "top", (30.0 - st["x0"] * 2, 236.0 - (sy - st["w"] / 2) * 2), 2.0, strap)
    sh.label("st", "nRF STRAP - top  2:1  (print top face down)", at=(28, 270))
    sh.dim("st", (st["x0"], sy - st["w"] / 2, 0), (st["x1"], sy - st["w"] / 2, 0), -5, axis="h")
    sh.dim("st", (st["x0"], sy - st["w"] / 2, 0), (st["x0"], sy + st["w"] / 2, 0), -4, axis="v")
    sh.leader("st", (st["screw"][0], sy + M3_CLEAR / 2, 0), f"dia {fm(M3_CLEAR)}", (6, 14))
    sh.place("sf", "front", (30.0 - st["x0"] * 2, 205.0 - (c["wall_top"] - STRAP_NOTCH["depth"]) * 2), 2.0, strap)
    sh.label("sf", "front  2:1", at=(28, 222))
    sh.dim("sf", (st["x1"], 0, c["wall_top"]), (st["x1"], 0, c["wall_top"] + st["t"]), 4, axis="v", text=fm(st["t"]))
    sh.dim("sf", (NRF_X[1] + 8.05 + STRAP_NOTCH["gap"], 0, c["wall_top"] - STRAP_NOTCH["depth"] + 0.3), (CUT[0] - 0.1, 0,
           c["wall_top"] - STRAP_NOTCH["depth"] + 0.3), -7, axis="h")
    sh.dim("sf", (st["x1"], 0, c["wall_top"] - STRAP_NOTCH["depth"] + 0.3), (st["x1"], 0, c["wall_top"]), 10, axis="v")
    sh.text((28, 192), f"tab {fm(STRAP_NOTCH['w'] - 2 * STRAP_NOTCH['gap'])} wide (Y) in the 4.0 notch", size=FS * 0.8, ha="left", color=DIMC)
    # stop bar: top + front, 2:1
    s = NRF_STOP
    sh.place("pt", "top", (150.0 - (NRF_X[0] - 9.5) * 2, 250.0 - s["y0"] * 2), 2.0, stop)
    sh.label("pt", "nRF STOP BAR - top  2:1  (print bar top down, pegs up)", at=(148, 270))
    sh.dim("pt", (NRF_X[0] - 9.5, s["y0"], 0), (NRF_X[1] + 9.5, s["y0"], 0), -5, axis="h")
    sh.dim("pt", (NRF_X[1] + 9.5, s["y0"], 0), (NRF_X[1] + 9.5, s["y1"], 0), 4, axis="v")
    sh.place("pf", "front", (150.0 - (NRF_X[0] - 9.5) * 2, 205.0 - SHELF_Z * 2), 2.0, stop)
    sh.label("pf", "front  2:1", at=(148, 228))
    yc = (s["y0"] + s["y1"]) / 2
    sh.dim("pf", (NRF_X[1] + 9.5, 0, ST), (NRF_X[1] + 9.5, 0, ST + s["h"]), 4, axis="v")
    sh.dim("pf", (NRF_X[1] + 9.5, 0, SHELF_Z + 0.2), (NRF_X[1] + 9.5, 0, ST), 11, axis="v")
    sh.leader("pf", (s["pegs"][0], 0, SHELF_Z + 1.0), f"3 pegs dia {fm(s['peg_d'])} at X 10 / 25.5 / 41", (6, -10))
    # spacer, 4:1
    sp = FAN_SPACER
    x, y = fan_holes()[0]
    sh.place("ft", "top", (300.0 - x * 4, 245.0 - y * 4), 4.0, spacer)
    sh.label("ft", "FAN SPACER x4 - top  4:1", at=(272, 270))
    sh.dim("ft", (x - sp["od"] / 2, y, 0), (x + sp["od"] / 2, y, 0), -18, axis="h", text=f"dia {fm(sp['od'])}")
    sh.dim("ft", (x - sp["id"] / 2, y, 0), (x + sp["id"] / 2, y, 0), -9, axis="h", text=f"dia {fm(sp['id'])}")
    sh.text((330, 245), f"height {fm(sp['h'])}", size=FS * 0.9, ha="left", color=DIMC)
    sh.text((330, 238), "between fan and shelf", size=FS * 0.8, ha="left")
    # coupon 1:1 top + front
    sh.place("ct", "top", (40.0, 95.0), 1.0, coupon)
    sh.label("ct", "FIT-TEST COUPON - top  1:1  (print first, about 1 h 45 min)", at=(38, 165))
    sh.dim("ct", (0, 0, 0), (74, 0, 0), -6, axis="h")
    sh.dim("ct", (0, 0, 0), (0, 36, 0), -6, axis="v")
    sh.place("cf", "front", (40.0, 60.0 - 26.0 + 10), 1.0, coupon)
    sh.label("cf", "coupon - front  1:1", at=(38, 78))
    sh.dim("cf", (74, 0, 0), (74, 0, 26), 5, axis="v")
    zc = 15.0
    for lab, key, p3, d in (("1", "cf", (11.0, 0, zc + 4.0), (-8, 6)), ("2", "cf", (31.0, 0, zc + 4.5), (0, 9)),
                            ("3", "cf", (60.0, 0, zc + 4.3), (0, 9)), ("4", "ct", (10.0, 12.0, 2.0), (-9, -4)),
                            ("5", "ct", (25.0, 4.0, 11.0), (0, -9)), ("6", "ct", (55.0, 10.0, 14.0), (2, -9)),
                            ("7", "ct", (66.0, 10.0, 8.0), (8, -6)), ("8", "ct", (42.5, 4.0, 11.0), (0, -9))):
        tag(sh, key, p3, lab, d)
    rows = [("1", "SMA hole + spot face (5 mm wall)", f"bulkhead slides in, nut seats on {fm(SMA['clamp'])} wall; washer + nut turn freely"),
            ("2", "nRF24 jack hole + pocket", f"jack passes dia {fm(NRF_HOLE)}; module end fits the {fm(NRF_POCKET['w'])} x {fm(NRF_POCKET['h'])} pocket"),
            ("3", "KCD11 cut-out (2 mm wall)", f"switch clips in from outside, no play ({fm(SW['cut'][0])} x {fm(SW['cut'][1])})"),
            ("4", "PBS-11A hole (2 mm plate)", f"button thread passes dia {fm(BTN['hole'])}; nut tightens flat"),
            ("5", "NIC rail sample, left (antenna edge)", "the board's antenna edge slides between the ribs with a little play, no binding"),
            ("6", "M3 insert post", f"M3 x 8 insert in dia {fm(INSERT_M3['hole'])}: goes in straight, no bulging, holds an M3 screw"),
            ("7", "M2.5 insert post", f"M2.5 x 4 insert in dia {fm(INSERT_M25['hole'])}: same check"),
            ("8", "NIC rail sample, right (button edge)", "the button edge slides along the ledge; the plunger passes the recess untouched")]
    sh.text((150, 160), "COUPON CHECKS (adjust the matching parameter in params.py if a fit is wrong)", size=FS * 0.95, ha="left", weight="bold")
    table(sh, 150, 156, [("#", 6), ("Feature", 52), ("Pass when", 142)], rows, size=FS * 0.8)
    sh.save(pdf, os.path.join(OUTD, "sheet7_small_parts_coupon.png"))


# ====================================================================== sheet 8: assembly
def sheet_assembly(pdf):
    import json
    sh = Sheet("ASSEMBLY + PARTS LIST", 8, NSHEETS, "Exploded view, assembled views, printed parts and fasteners")
    V = os.path.join(HERE, "deliverables", "views")
    h = sh.image(os.path.join(V, "exploded.png"), 16, 104, 178)
    sh.text((18, 104 + h - 2), "EXPLODED VIEW", size=FS * 1.1, ha="left", va="top", weight="bold")
    h1 = sh.image(os.path.join(V, "assembled_closed_front.png"), 200, 196, 100)
    sh.text((202, 196 + h1 - 2), "ASSEMBLED", size=FS, ha="left", va="top", weight="bold")
    h2 = sh.image(os.path.join(V, "assembled_lid_off.png"), 302, 196, 100)
    sh.text((304, 196 + h2 - 2), "LID OFF", size=FS, ha="left", va="top", weight="bold")
    parts = json.load(open(os.path.join(HERE, "out", "parts.json")))
    sl = json.load(open(os.path.join(HERE, "out", "slice.json")))["normal"]
    order = [("base", "Base (main body)"), ("lid", "Lid"), ("shelf", "Radio shelf"), ("nic_rail_l", "NIC rail, left"),
             (f"nic_rail_r_w{NIC_PCB_W:.1f}", f"NIC rail, right ({NIC_PCB_W:.1f} mm board) *"), ("nrf_strap", "nRF strap"),
             ("nrf_stop", "nRF stop bar"),
             ("fan_spacers", "Fan spacers (plate of 4)"), ("coupon", "Fit-test coupon (print first)")]
    rows = []
    for i, (k, nm) in enumerate(order, 1):
        p = parts[k]
        g = sl[p["file"][:-4]]
        rows.append((str(i), nm, p["file"], "PETG", f"{p['size_mm'][0]:.0f} x {p['size_mm'][1]:.0f} x {p['size_mm'][2]:.1f}",
                     f"{p['volume_cm3']:.1f}", (f"{float(g['filament_g']):.0f}" if float(g['filament_g']) >= 10 else f"{float(g['filament_g']):.1f}"),
                     g["time"].rsplit(" ", 1)[0] if "h" in g["time"] else g["time"]))
    sh.text((200, 190), "PRINTED PARTS (0.20 mm, 4 walls, 25 % gyroid; times from PrusaSlicer, Ender-3 V2 profile)", size=FS * 0.9,
            ha="left", weight="bold")
    yb = table(sh, 200, 186, [("#", 6), ("Part", 42), ("STL file", 60), ("Mat.", 11), ("Size on bed", 30), ("cm3", 11), ("g", 9),
                              ("Time", 20)], rows, size=FS * 0.74, row_h=4.2)
    rr = [sl[f"sentinel_r5_nic_rail_right_w{v:.1f}"] for v in (NIC_PCB_W_VARIANTS[0], NIC_PCB_W_VARIANTS[-1])]
    sh.text((200, yb - 3.5), f"* one right rail per board width, {NIC_PCB_W_VARIANTS[0]:.1f}-{NIC_PCB_W_VARIANTS[-1]:.1f} mm in 0.5 steps "
            f"(sheet 6): print only yours. From {float(rr[1]['filament_g']):.1f} g ({NIC_PCB_W_VARIANTS[-1]:.1f}) to "
            f"{float(rr[0]['filament_g']):.1f} g ({NIC_PCB_W_VARIANTS[0]:.1f}).", size=FS * 0.72, ha="left")
    yb -= 5
    fr = [("7", "M3 heat-set insert, 8 long, OD 4.5", "lid posts 4, shelf posts 2, strap 1"),
          ("4", "M2.5 heat-set insert, 4 long", "Pi standoffs"),
          ("7", "M3 x 8 button head (ISO 7380)", "lid 4, shelf 2, strap 1"),
          ("4", "M2.5 x 5 pan / button head", "Raspberry Pi"),
          ("4", "M3 x 20 countersunk (ISO 10642) + 4 M3 nuts", "fan (4010) through spacers and shelf"),
          ("4", "M2.5 x 4 self-tapping (plastic)", "TFT into the lid bosses"),
          ("-", "Double-sided foam tape for the KY-013", "see the report")]
    sh.text((200, yb - 5), "FASTENERS AND CONSUMABLES", size=FS * 0.9, ha="left", weight="bold")
    table(sh, 200, yb - 9, [("Qty", 9), ("Item", 92), ("Where", 88)], fr, size=FS * 0.74, row_h=4.2)
    sh.note((18, 98), ["Assembly order (full sequence and checks in the report):",
                       "1 inserts into base, shelf posts, Pi standoffs and strap hole   2 SMA leads + nuts in holes 3-6",
                       "3 Pi (SD card after, through the back slot)   4 NIC B plug   5 ESP (tilt in under the snap lip)",
                       "6 Pi plugs   7 PN532, buzzer, KY-013, breadboard, KCD11   8 shelf with fan, 2 x M3 x 8",
                       "9 NIC stack (2 rails + 2 WN722N + USB connectors) onto its 4 pegs, RA plugs   10 nRF24 modules, stop bar, strap",
                       "11 antennas   12 lid + 4 screws (holds the NIC stack down)   13 power"],
            size=FS * 0.85)
    sh.save(pdf, os.path.join(OUTD, "sheet8_assembly.png"))


if __name__ == "__main__":
    import sys
    base = build_base()
    with PdfPages(os.path.join(OUTD, "sentinel_r5_drawings.pdf")) as pdf:
        sheet_base_plan(base, pdf)
        sheet_base_elev(base, pdf)
        sheet_base_sections(base, pdf)
        sheet_lid(build_lid(), pdf)
        sheet_shelf(build_shelf(), pdf)
        sheet_rails(build_nic_rail("l"), build_nic_rail("r"), pdf)
        sheet_small(build_nrf_strap(), build_nrf_stop(), build_fan_spacers()[0], build_coupon(), pdf)
        sheet_assembly(pdf)
