"""Builds deliverables/REPORT.md from the validation, STL QA, slicing and shelf bending results (numbers are read from the
JSON outputs or computed from params.py, not typed in)."""
import glob, json, math, os
from params import *

HERE = os.path.dirname(os.path.abspath(__file__))
J = lambda n: json.load(open(os.path.join(HERE, "out", n)))


def md_table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "|".join("---" for _ in head) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def f1(x):
    return f"{x:.1f}"


def short_time(t):
    return t.rsplit(" ", 1)[0] if t and "h" in t else t


def engagement():
    """Rib overlap for a board floating sideways in its rail version (computed from params)."""
    r, xw, t = NIC_RAIL, NIC_RAIL["wl"][1], NIC_RAIL["rib"]
    rows = []
    for v in NIC_PCB_W_VARIANTS:
        g = nic_right(v)
        for b in (v, v - 0.5):
            pos = [xw + 0.05, g["kerb"] - b]           # leftmost (stopped by the hold-down's slope), rightmost (on the kerb)
            left = min(xw + t - xe for xe in pos)
            right = min(xe + b - (g["kerb"] - t) for xe in pos)
            plunger = min(g["recess"] - (xe + b + NIC_BTN["out"]) for xe in pos)
            rows.append((v, b, left, right, plunger))
    return rows


def build():
    v, q, sl, parts, fe = J("validation.json"), J("stl_qa.json"), J("slice.json"), J("parts.json"), J("fe_shelf.json")
    vw = {}
    for fn in sorted(glob.glob(os.path.join(HERE, "out", "validation_w*.json"))):
        d = json.load(open(fn))
        vw[d["nic_pcb_w"]] = d
    n_items = len(v["items"])
    n_solid = sum(1 for i in v["items"] if i["kind"] == "solid")
    n_air = sum(1 for i in v["items"] if i["kind"] == "air")
    st_err = sum(1 for r in v["static"] if r["sev"] == "ERROR")
    st_warn = sum(1 for r in v["static"] if r["sev"] == "WARN")
    seq_hits = sum(len(s["collisions"]) for s in v["sequence"])
    tot_n, tot_s = sl["normal"]["_total_enclosure"], sl["speed"]["_total_enclosure"]
    right_files = [f"sentinel_r5_nic_rail_right_w{w:.1f}" for w in NIC_PCB_W_VARIANTS]
    right_main = f"sentinel_r5_nic_rail_right_w{NIC_PCB_W:.1f}"
    vc = sl["vent_comparison"]["no_vents_normal"]
    sh = sl["normal"]["sentinel_r5_shelf"]
    n_vents = len(__import__("shelf").vent_holes())
    press = fe["press20N"]
    worst = max(press, key=lambda p: p["vents"]["vent_field_max_stress_mpa"])
    eng = engagement()
    min_eng = min(min(e[2], e[3]) for e in eng)
    min_pl = min(e[4] for e in eng)
    ws_ok = all(sum(r["sev"] == "ERROR" for r in d["static"]) == 0 and sum(len(s["collisions"]) for s in d["sequence"]) == 0
                for d in vw.values())
    stl_n = len(q)
    vol_dev = max(abs(r["integrity"]["volume_dev_pct"]) for r in q.values())
    manifold_all = all(any(ln == "manifold = yes" for ln in r.get("prusa_info", [])) for k, r in sl["normal"].items()
                       if not k.startswith("_"))

    L_ = []
    a = L_.append
    a("# Sentinel enclosure rev 5 - final CAD: validation, printing and test report")
    a("")
    a("Prepared for Prof. Samir Elsagheer, 13 Nov 2026. This version includes your shelf changes and the WN722N board data "
      "you gave on 13 Nov. Everything below was checked in CAD and on the exported STL files. Nothing has been printed or "
      "physically fitted yet. Section 10 lists what only a printed prototype can confirm.")
    a("")
    a("## Summary")
    a("")
    a(f"- **Collisions:** {st_err} interferences between solid parts in the assembled model ({n_items} items, {n_solid} of "
      f"them solid). {seq_hits} collisions along the {len(v['sequence'])}-step fitting sequence, with every part swept "
      f"along its real installation path. The same checks were run for each of the {len(vw)} WN722N board widths "
      f"({NIC_PCB_W_VARIANTS[0]:.1f}-{NIC_PCB_W_VARIANTS[-1]:.1f} mm), with the same result"
      f"{'' if ws_ok else ' EXCEPT where noted in section 4'}.")
    a("- **Maintenance:** every service move works. Three need another part moved first, as designed: the PN532 slid up, "
      "the breadboard tilted, or the shelf taken out for the buzzer. The NIC stack (both rails, both boards, USB connectors) "
      "lifts out with the lid off, without touching the shelf.")
    a(f"- **NIC rails (your changes):** the WN722N boards slide in two removable rails that sit on 4 pegs and are held "
      f"down by the lid. Nothing is fixed in front of the boards. A connector space of 20 x 32 x 25 mm in front of the USB "
      f"plugs is checked empty of printed parts. The right rail comes in {len(NIC_PCB_W_VARIANTS)} versions, one per "
      f"board width from {NIC_PCB_W_VARIANTS[0]:.1f} to {NIC_PCB_W_VARIANTS[-1]:.1f} mm. Any board up to 0.5 mm "
      f"narrower than its version still rests at least {min_eng:.1f} mm on each side. The button's plunger keeps at "
      f"least {min_pl:.1f} mm clear along its whole sliding path.")
    a(f"- **Shelf vents:** {n_vents} hexagonal holes. They save {float(vc['filament_g']) - float(sh['filament_g']):.1f} g "
      f"and add {sh['minutes'] - vc['minutes']:.0f} min of print time. Under the weight of the parts the plate's sag "
      f"changes from {fe['solid_weight']['max_deflection_mm']:.3f} to {fe['vents_weight']['max_deflection_mm']:.3f} mm. "
      f"Under a 20 N fingertip press the worst local stress is {worst['vents']['vent_field_max_stress_mpa']:.0f} MPa, a "
      f"safety factor of {worst['vents']['vent_field_safety_factor']:.1f} on 40 MPa (section 8).")
    a(f"- **STL files:** all {stl_n} are closed, manifold meshes. Each is one body, except the spacer plate with its 4 "
      f"rings. Each volume matches the CAD within {max(vol_dev, 0.01):.2f} %. PrusaSlicer reads "
      f"{'all of them' if manifold_all else 'NOT all of them'} as manifold and slices them with supports off.")
    a(f"- **Print:** about {tot_n['filament_g']:.0f} g of PETG ({tot_n['filament_m']:.0f} m of 1.75 mm) and "
      f"{tot_s['hours']:.0f}-{tot_n['hours']:.0f} h for the whole enclosure with one right rail. The "
      f"{float(sl['normal']['sentinel_r5_fit_test_coupon']['filament_g']):.0f} g fit-test coupon comes on top and should "
      "be printed first.")
    a("- **Changes from the approved rev 5:** all listed in section 2, with the reason for each.")
    a("")
    # -------------------------------------------------------------------------------------------- 1
    a("## 1. Deliverables")
    a("")
    a(md_table(["Item", "File(s)", "Notes"], [
        ("Editable CAD source", "`cad/*.py` (params.py holds every dimension)", "CadQuery (Python) parametric model; see section 11"),
        ("STL per printed part", f"`stl/sentinel_r5_*.stl` ({stl_n} files)",
         f"in print orientation, on the bed at Z 0; the right NIC rail in {len(NIC_PCB_W_VARIANTS)} width versions (print one)"),
        ("STEP per part + assembly", "`step/*.step`", "for Fusion, FreeCAD, SolidWorks (not parametric there)"),
        ("Assembled 3D model", "`sentinel_r5_assembly.glb`, `step/sentinel_r5_assembly.step`",
         f"all printed and bought parts, coloured ({NIC_PCB_W:.1f} mm boards)"),
        ("Dimensioned drawings", "`drawings/sentinel_r5_drawings.pdf` (8 A3 sheets) + PNG per sheet", "1:1 sheets can be measured when printed at 100 %"),
        ("Exploded view", "`views/exploded.png` and drawing sheet 8", "plus closed, lid-off, floor-level and cut-away views"),
        ("Clearance / collision report", "this report + `data/validation*.json`, `data/stl_qa.json`", "raw results of every check, one validation file per board width"),
        ("Print orientation, slicer settings", "section 6 + `slicer/*.ini` (PrusaSlicer 2.7)", "settings also listed for any other slicer"),
        ("Filament and time", "section 7 + `data/slice.json`", "from PrusaSlicer's G-code estimate"),
        ("Shelf bending check", "section 8 + `data/fe_shelf.json`", "plate with and without the vent holes"),
    ]))
    a("")
    # -------------------------------------------------------------------------------------------- 2
    a("## 2. Changes from the approved rev 5")
    a("")
    a("Every change is also in `params.py` (list `CHANGES`) and tagged `[CAD]` or `[U]` next to the value. Dimensions not "
      "listed here are the rev 5 values.")
    a("")
    split = CHANGES.index(next(c for c in CHANGES if c.startswith("Base: two places")))
    yours = [c for c in CHANGES[:split] if c.startswith("Your ")]
    found = [c for c in CHANGES[:split] if not c.startswith("Your ")]
    qa = CHANGES[split:]
    n = 0
    a("**Your changes and data (13 Nov):**")
    a("")
    for c in yours:
        n += 1
        s = c.split(": ", 1)[1].replace("(see the strength check in the report)", "(strength check in section 8)")
        a(f"{n}. {s[0].upper() + s[1:]}")
    a("")
    a(f"Undone as a result: the buzzer is back at its rev 5 height (centre Z {BUZ['cz']:.1f}). It had been lowered "
      "2.4 mm only to clear the old NIC sled's front overhang, which your shelf change removed.")
    a("")
    a("**Found by the assembly validation** (parts that would collide, or could not be fitted or removed):")
    a("")
    for c in found:
        n += 1
        a(f"{n}. {c}")
    a("")
    a("**Found by the STL inspection** (thin, weak or unprintable details; no fit dimension changed):")
    a("")
    for c in qa:
        n += 1
        a(f"{n}. {c}")
    a("")
    # -------------------------------------------------------------------------------------------- 3
    a("## 3. How the design was checked")
    a("")
    a(f"- **Model:** {n_items} items. The printed parts are the base, lid, shelf, 2 NIC rails, strap, stop bar and 4 "
      "spacers. Every bought part is in too: Pi 4, ESP32-S3, 2 WN722N with their USB connectors, 2 nRF24L01+PA+LNA on "
      "adapters, PN532, TFT, 5 PBS-11A, breadboard, buzzer, KCD11, KY-013, fan, plugs, antennas, screws, nuts and inserts. "
      "They are modelled from datasheets, your measurements, your photos, or flagged assumptions. Cables are 'soft' zones "
      f"that must stay free. {n_air} 'air' zones must stay empty of solids: the NFC field, the fan intake, the USB "
      "connector space, and the path each WN722N button sweeps while its board slides in.")
    a("- **Static interference:** every pair of parts intersected with exact mesh booleans (0.02 mm chord). Anything over "
      "0.01 mm3 counts.")
    a("- **Clearances:** smallest gap between every pair of solid parts closer than 1.5 mm.")
    a("- **Fitting sequence:** each step moves its parts along their real path (lowered, pushed, the ESP tilted and swung) "
      "in 0.5 mm steps against everything already fitted.")
    a("- **Maintenance moves:** each plug, board and sub-assembly is removed with everything else in place, or with the "
      "parts that must come off first removed.")
    a(f"- **Board widths:** the whole check runs once per WN722N width ({', '.join(f'{w:.1f}' for w in NIC_PCB_W_VARIANTS)} mm), "
      "each with its own right rail.")
    a("- **STL inspection:** the exported files are re-loaded from disk and checked for: watertight, edges shared by "
      "exactly two faces, one body, volume against the CAD, first-layer area. Every down-facing surface is classified "
      "(bridge, cantilever, island). Wall thickness is checked by ray casting from 4 samples per mm2 of surface, plus "
      "narrow internal slots. Then PrusaSlicer's own mesh check and a full slice of every part.")
    a("- **Shelf bending:** plate-bending finite-element model of the shelf with and without the vent holes (section 8).")
    a("")
    # -------------------------------------------------------------------------------------------- 4
    a("## 4. Collisions and clearances")
    a("")
    a(f"**Static check:** {st_err} errors, {st_warn} warnings. **Fitting sequence:** all {len(v['sequence'])} steps clear; "
      f"{'no' if not v['not_in_sequence'] else len(v['not_in_sequence'])} solid parts left outside the sequence. "
      f"Results below are for {NIC_PCB_W:.1f} mm boards; the other widths are in 4.2.")
    a("")
    rows = [(s["step"], s["desc"], s["items"], len(s["collisions"])) for s in v["sequence"]]
    a(md_table(["Step", "What is fitted and how", "Parts", "Collisions"], rows))
    a("")
    a("**Maintenance moves**")
    a("")
    mrows = []
    for m in v["maintenance"]:
        res = "clear" if not m["collisions"] else ("blocked, as expected" if m["note"].startswith("expected") else "BLOCKED")
        mrows.append((m["check"], res, m["note"] or ""))
    a(md_table(["Move", "Result", "Note"], mrows))
    a("")
    tb = v["breadboard_tilt"]
    ok = [t for t in tb if t["plug_path_hit"] == 0.0]
    if ok:
        t = ok[0]
        a(f"NIC B's plug (USB 3 lower) comes out once the breadboard's left end is tilted up {t['angle']} deg (about "
          f"{t['lift_at_plug']:.0f} mm at the plug). At that angle the board touches the frame's right rim "
          f"({t['clashes'][0][1]:.0f} mm3 in CAD). That is the board flexing against the rim, not a hard stop.")
        a("")
    a("### 4.1 Tightest clearances")
    a("")
    a("Parts that sit on, in or against each other by design are left out: PCBs on standoffs, the shelf on its ledges, "
      "inserts in holes, nuts on their threads.")
    a("")
    by = {(r["a"], r["b"]): r["gap"] for r in v["clearance"]}
    picks = [
        (("nrf1.adapter", "nrf2.adapter"), "nRF24 adapter boards", "edge to edge: 19 mm boards at 19 mm pitch (rev 5 layout); they may touch"),
        (("shelf", "nrf1.module"), "nRF24 module on the cradle block", "resting gap"),
        (("base", "sw.body"), "KCD11 body in its cut-out", "per side; coupon check"),
        (("nic_rail_l", "wn1.pcb"), "WN722N board on its rails", f"{NIC_RAIL['sup_gap']} under the board; left hold-down {NIC_RAIL['hold_gap']} over it"),
        (("base", "sma4.thread"), "SMA thread in its 6.6 hole", "per side; coupon check"),
        (("shelf", "fan_screw0"), "fan screw in the shelf hole", ""),
        (("esp.pcb", "usbc90.plug"), "90 deg USB-C plug to the ESP board", "plug body size assumed (12 x 7.8)"),
        (("lid", "btn0.thread"), "PBS-11A thread in its 12.3 hole", "per side"),
        (("base", "esp.pcb"), "ESP board in its frame", "per side"),
        (("nrf_strap", "nrf1.module"), "strap above the nRF modules", "hold-down gap"),
        (("lid", "nic_rail_r"), "lid's right lip over the right NIC rail", "this is what holds the NIC stack down"),
        (("lid", "nic_rail_l"), "lid over the left rail's two posts", ""),
        (("base", "usbc90.plug"), "90 deg USB-C plug to the floor", ""),
        (("lid", "tft.glass"), "TFT glass in the lid opening", "per side"),
        (("base", "nic_rail_r"), "right NIC rail to the right wall", ""),
        (("nic_rail_r", "wn1.parts"), "right rail's low front boss under NIC A", "to the assumed 1.4 mm parts envelope"),
        (("pi.hs_soc", "fan.body"), "Pi heatsink to the fan", "heatsink taken as 10 mm (your figure: under 10)"),
        (("base", "sma4.body"), "SMA body to the rear-middle lid post", ""),
        (("btn1.nut", "btn3.nut"), "neighbouring button nuts", "worst case: M12 thin nut 18 AF assumed"),
        (("base", "nrf1.jack"), "nRF24 jack in its 9.4 hole", "per side"),
        (("shelf", "wn1ra.plug"), "NIC A's right-angle RP-SMA plug to the shelf", ""),
        (("base", "pi.sdcard"), "microSD card to the back wall", ""),
    ]
    crow = [(lab, f"{by[k]:.2f}" if k in by else "> 1.5", note) for k, lab, note in picks]
    a(md_table(["Pair", "Gap (mm)", "Note"], crow))
    a("")
    a("### 4.2 NIC rails across the board widths")
    a("")
    a("Each width was checked as a complete assembly with its own right rail and boards of that width:")
    a("")
    wrows = []
    for w_, d in sorted(vw.items()):
        cl = {(r["a"], r["b"]): r["gap"] for r in d["clearance"]}
        stn = sum(r["sev"] == "ERROR" for r in d["static"])
        stw = sum(r["sev"] == "WARN" for r in d["static"])
        sq = sum(len(s["collisions"]) for s in d["sequence"])
        mt_bad = [m for m in d["maintenance"] if m["collisions"] and not m["note"].startswith("expected")]
        g = nic_right(w_)
        wrows.append((f"{w_:.1f}", f"sentinel_r5_nic_rail_right_w{w_:.1f}.stl", f"{stn} / {stw}", sq,
                      "as expected" if not mt_bad else f"{len(mt_bad)} BLOCKED",
                      f"{min(cl.get(('nic_rail_l', 'wn1.pcb'), 9), cl.get(('nic_rail_r', 'wn1.pcb'), 9)):.2f}",
                      f"{g['outer'] - g['recess']:.2f}"))
    a(md_table(["Board (mm)", "Right rail", "Errors / warnings", "Sequence hits", "Maintenance", "Rail-to-PCB min (mm)",
                "Wall behind recess (mm)"], wrows))
    a("")
    a("The errors column includes the two zones that must stay empty for every width: the USB connector space in front "
      "of the plugs, and the button's sliding path. A board narrower than its rail version floats sideways. The "
      "worst-case overlaps below are computed from the rail profile. 'Left' is the support and hold-down ribs on the "
      "antenna edge; 'right' is the ledge on the button edge. The plunger clearance is to the recess face.")
    a("")
    erows = [(f"{e[0]:.1f}", f"{e[1]:.1f}", f"{e[2]:.2f}", f"{e[3]:.2f}", f"{e[4]:.2f}") for e in eng]
    a(md_table(["Rail version (mm)", "Board (mm)", "Min. overlap left (mm)", "Min. overlap right (mm)", "Plunger clearance (mm)"], erows))
    a("")
    a(f"**Choosing the right rail:** measure the PCB width with calipers and round up to the next 0.5 mm. For example, "
      f"21.3 mm takes the 21.5 version. A board wider than {NIC_PCB_W_VARIANTS[-1]:.1f} mm, or narrower than "
      f"{NIC_PCB_W_VARIANTS[0] - 0.5:.1f} mm, needs a new version: add its width to `NIC_PCB_W_VARIANTS` and re-export.")
    a("")
    a("**USB connectors:** the free connector space runs from the mating face (Y 39) to the front-right lid post (Y 7). It "
      "is 20 mm wide, centred on the plugs, from the shelf top to the lid lips. That leaves 32 mm in front of each plug "
      "for the connector body and the start of its cable. The modelled reference is a bare USB-A female socket with "
      "soldered wires: it ends at Y 25, leaving 25 mm for the wires to turn down. A moulded extension-cable end must fit "
      "in the 32 mm, including the bend of its cable. Measure it before buying, or use a bare socket or a right-angle "
      "female adapter.")
    a("")
    a("**Antennas:** all six mount without interference (antenna step swept clear). Between neighbouring SMA nuts (8 AF, "
      "9.24 across corners) the free space is 9.76 mm at 19 mm pitch and 9.26 mm at 18.5 mm pitch. That is enough for an "
      "8 mm open spanner from the side. With the whips folded up (10 mm diameter assumed), neighbouring whips stand 9.0 "
      "and 8.5 mm apart.")
    a("")
    a("**Ports:** the Pi's USB-C power (left wall hole, 15 x 9) and microSD (back slot) are reachable from outside. The "
      "USB 2 and USB 3 ports carry the ESP link and the two NICs inside; their plugs come out as the maintenance table "
      "shows. Ethernet, micro-HDMI and audio face the inside of the box and are not reachable with the lid on, as in rev 5.")
    a("")
    # -------------------------------------------------------------------------------------------- 5
    a("## 5. STL inspection")
    a("")
    names = {"sentinel_r5_base": "Base", "sentinel_r5_shelf": "Shelf", "sentinel_r5_lid": "Lid",
             "sentinel_r5_nic_rail_left": "NIC rail, left", **{f: f"NIC rail, right {f[-4:]}" for f in right_files},
             "sentinel_r5_nrf_strap": "nRF strap", "sentinel_r5_nrf_stop": "nRF stop bar",
             "sentinel_r5_fan_spacers_x4": "Fan spacers x4", "sentinel_r5_fit_test_coupon": "Fit coupon"}
    srows = []
    for k, nm in names.items():
        r = q[k]
        ii = r["integrity"]
        walls = r["thin"]["parallel"]
        srows.append((nm, "yes" if ii["watertight"] and ii["edges_not_shared_by_two"] == 0 else "NO", ii["bodies"],
                      f"{ii['volume_cm3']:.2f} / {ii['cad_volume_cm3']:.2f}", " x ".join(f"{s:.1f}" for s in ii["size"]),
                      f"{ii['first_layer_mm2']:.0f}", len(r["overhang_problems"]),
                      ", ".join(f"{w['min']:.1f}" for w in walls) or "none"))
    a(md_table(["Part", "Closed, manifold", "Bodies", "Volume STL / CAD (cm3)", "Size on bed (mm)", "Bed contact (mm2)",
                "Overhangs to watch", "Walls under 1.2 mm"], srows))
    a("")
    a("Issues found on the first export and fixed (then every file regenerated and re-checked):")
    a("")
    for c in qa:
        a(f"- {c}")
    a("")
    a("Accepted, with reasons:")
    a("")
    a("- **ESP snap lip:** a 0.8 mm flat ledge, the only flat overhang in the base. It is two extrusion widths and prints "
      "as an overhang perimeter. Any droop eats into the 0.4 mm clearance over the module, so check it on the first print.")
    a("- **Lid, TFT bosses:** 0.6 mm of lid skin is left above each 2.4 mm pilot hole. The bosses cannot be deeper "
      "without lowering the screen. Use M2.5 x 4 screws, not longer, and tighten by hand.")
    a("- **Tapers, not walls:** the NIC rail ribs (45 deg triangles), the countersink rims and the 45 deg corbel tips end "
      "in knife edges by shape. The ray check flags them as thin; they are not thin walls.")
    a("")
    # -------------------------------------------------------------------------------------------- 6
    a("## 6. Print orientation and slicer settings")
    a("")
    orows = []
    for k in ("base", "lid", "shelf", "nic_rail_l", *[f"nic_rail_r_w{w:.1f}" for w in NIC_PCB_W_VARIANTS], "nrf_strap",
              "nrf_stop", "fan_spacers", "coupon"):
        p = parts[k]
        orows.append((p["file"], p["bed"], "none", sl["normal"][p["file"][:-4]]["settings"].replace("_", " ")))
    a(md_table(["STL", "Face on the bed (already oriented)", "Supports", "Settings"], orows))
    a("")
    a("Settings (PETG, 0.4 mm nozzle). The `slicer/*.ini` files hold these on top of PrusaSlicer's Creality Ender-3 V2 "
      "profile; any slicer can use the same values:")
    a("")
    cm = sl["_settings"]["common"]
    a(md_table(["Setting", "Main parts", "Strap, stop bar, spacers", "NIC rails"], [
        ("Layer height / first layer", f"{cm['layer_height']} / {cm['first_layer_height']} mm", "same", "same"),
        ("Perimeters (walls)", cm["perimeters"], "same", "same"),
        ("Top / bottom solid layers", f"{cm['top_solid_layers']} / {cm['bottom_solid_layers']}", "same", "same"),
        ("Infill", f"{cm['fill_density']} gyroid", "100 % rectilinear", "100 % rectilinear"),
        ("Supports", "off", "off", "off"),
        ("Brim", "none (add 5 mm on the base if a corner lifts)", "none", "5 mm (tall, narrow parts)"),
        ("Nozzle / bed", f"{cm['first_layer_temperature']} C / {cm['first_layer_bed_temperature']} C first layer, "
                         f"{cm['bed_temperature']} C after", "same", "same"),
        ("Part fan", f"{cm['min_fan_speed']}-{cm['max_fan_speed']} %, bridges {cm['bridge_fan_speed']} %", "same", "same"),
        ("Seam", "rear", "rear", "rear"),
        ("Elephant-foot compensation", f"{cm['elefant_foot_compensation']} mm (the base also has a 0.6 mm chamfer on its "
                                       "bed edge)", "same", "same"),
        ("XY size compensation", "0 (do not scale the model)", "0", "0"),
    ]))
    a("")
    a("**Accuracy and shrinkage.** PETG shrinks much less than ABS, and on parts this size the printer's own hole and "
      "outline accuracy matters more. Do not scale the model. Print the coupon (sheet 7), check each fit, and if one is "
      "off change only that parameter in `params.py`. Examples: `INSERT_M3['hole']`, `SMA['hole']`, `SW['cut']`, "
      "`BTN['hole']`, `NIC_PEG['hole']`. For the NIC boards, `NIC_RAIL['sup_gap']` / `['hold_gap']` set the vertical fit "
      "and `NIC_RAIL['gap']` the side play. Then re-export. The sliding fits are built with 0.2-0.3 mm per side. Holes "
      "printed vertically in the band are teardrops, so their tops stay round enough.")
    a("")
    # -------------------------------------------------------------------------------------------- 7
    a("## 7. Filament and print time")
    a("")
    frows = []
    for k, nm in names.items():
        nn, ss = sl["normal"][k], sl["speed"][k]
        if k in right_files and k != right_main:
            nm = nm + " (alternative)"
        frows.append((nm, f"{float(nn['filament_g']):.1f}", f"{float(nn['filament_mm']) / 1000:.2f}", nn["time"], ss["time"]))
    frows.append((f"**Enclosure total (one right rail, the {NIC_PCB_W:.1f} version; without coupon)**",
                  f"**{tot_n['filament_g']:.1f}**", f"**{tot_n['filament_m']:.1f}**", f"**{tot_n['hours']:.1f} h**",
                  f"**{tot_s['hours']:.1f} h**"))
    a(md_table(["Part", "PETG (g)", "Length (m)", "Time, stock speeds", "Time, faster profile"], frows))
    a("")
    rr = [sl["normal"][f] for f in right_files]
    a(f"Only one right rail is printed. They range from {min(float(r['filament_g']) for r in rr):.1f} g "
      f"({NIC_PCB_W_VARIANTS[-1]:.1f} mm board) to {max(float(r['filament_g']) for r in rr):.1f} g "
      f"({NIC_PCB_W_VARIANTS[0]:.1f} mm), so the total moves by about "
      f"{max(abs(float(r['filament_g']) - float(sl['normal'][right_main]['filament_g'])) for r in rr):.0f} g either way. "
      f"Shelf without the vent holes, same settings: {float(vc['filament_g']):.2f} g, {vc['time']} (with the holes: "
      f"{float(sh['filament_g']):.2f} g, {sh['time']}).")
    a("")
    a("PrusaSlicer 2.7.2 estimates at 1.27 g/cm3. 'Stock speeds' is the Ender-3 V2 \"0.20 mm NORMAL\" profile "
      "(perimeters 40 mm/s, outer wall 25, infill 50, 500 mm/s2); 'faster' is its \"NORMAL SPEED\" profile (60 / 30 / 60). "
      "A faster printer will be quicker; the gram figures do not depend on speed. One 1 kg spool covers the enclosure, the "
      "coupon and a reprint of the lid or shelf.")
    a("")
    # -------------------------------------------------------------------------------------------- 8
    a("## 8. Shelf vent holes: strength check")
    a("")
    a(f"You asked for holes in the shelf for air and weight, but only if they do not make it weak. The first try covered "
      f"the whole plate. The bending check showed the area between the fan opening, the jumper slot and the KY-013 "
      f"cut-out's free edge is the plate's most flexible part, so that area stays solid. The final {n_vents} holes (7 mm "
      f"across flats, 3 mm webs) sit only in front of the nRF stop bar and under the NIC boards, at least 6 mm from "
      f"every edge, screw, peg and support.")
    a("")
    a(f"Model: Kirchhoff plate, finite elements (scikit-fem, Morley triangles, {fe['mesh_mm']} mm mesh). The plate is "
      f"2.4 mm thick and is taken alone: the cradle, lip and pegs, which add "
      f"stiffness, are ignored. It rests on the wall ledges and is held vertically at the two screw posts. PETG is taken "
      f"as E = {fe['E_MPa']:.0f} MPa, against an allowable bending stress of {fe['allowable_MPa']:.0f} MPa. Loads are the "
      f"plate's own weight plus the parts it carries, with masses rounded up: "
      f"{', '.join(f'{k} {g:.0f} g' for k, g in fe['assumed_part_masses_g'].items())}. Separately, a 20 N press with a "
      f"fingertip (8 mm patch) is applied at the web between two holes in each vent group.")
    a("")
    prow = [("Parts' weight only", f"{fe['solid_weight']['max_deflection_mm']:.3f} -> {fe['vents_weight']['max_deflection_mm']:.3f}",
             f"{fe['solid_weight']['max_stress_mpa']:.2f} -> {fe['vents_weight']['max_stress_mpa']:.2f}",
             f"{fe['vents_weight']['safety_factor']:.0f}")]
    for p in press:
        prow.append((f"20 N press at X {p['press_at'][0]:.1f}, Y {p['press_at'][1]:.1f}",
                     f"{p['solid']['max_deflection_mm']:.2f} -> {p['vents']['max_deflection_mm']:.2f}",
                     f"{p['solid']['vent_field_max_stress_mpa']:.1f} -> {p['vents']['vent_field_max_stress_mpa']:.1f}",
                     f"{p['vents']['vent_field_safety_factor']:.1f}"))
    a(md_table(["Load case", "Max. deflection (mm), solid -> with holes", "Max. stress near the load (MPa), solid -> with holes",
                "Safety factor with holes"], prow))
    a("")
    ratios = [p["vents"]["vent_field_max_stress_mpa"] / p["solid"]["vent_field_max_stress_mpa"] for p in press]
    any_s = max(p["solid"]["max_stress_mpa"] for p in press)
    any_v = max(p["vents"]["max_stress_mpa"] for p in press)
    hole_area = n_vents * math.sqrt(3) / 2 * SHELF_VENTS["af"] ** 2
    a(f"Under normal use the holes change nothing measurable. A hard press on the webs raises the local stress "
      f"{min(ratios):.1f}-{max(ratios):.1f} times, but it stays well inside PETG's strength. The highest stress anywhere "
      f"({any_s:.1f} MPa solid, {any_v:.1f} MPa with the holes) sits at the screw-post supports, where the simplified "
      f"point-support model concentrates it (see `data/fe_shelf.json`). The holes add about {hole_area:.0f} mm2 of open "
      f"area for air through the shelf. How much that helps the NICs' temperature can only be measured (section 10).")
    a("")
    # -------------------------------------------------------------------------------------------- 9
    a("## 9. Assembly and disassembly")
    a("")
    a("Assembly follows the validated sequence in section 4 (also drawing sheet 8). Points that matter in practice:")
    a("")
    a("1. Heat-set inserts go in before anything else: 7 x M3 (4 lid posts, 2 shelf posts, strap hole) and 4 x M2.5 (Pi "
      "standoffs).")
    a("2. The SMA leads go through holes 4-6 from inside before the Pi. The Pi goes in without its microSD card, which "
      "is then pushed in through the back slot.")
    a("3. NIC B's plug goes into USB 3 lower before the breadboard. The ESP goes in module-end first under the snap lip, "
      "then the USB end swings down.")
    a("4. The shelf is built on the bench (fan, spacers, strap insert), lowered in and screwed down (2 x M3 x 8).")
    a("5. The NIC stack is built on the bench. Slide both WN722N into the two rails from the back, chip face up, until "
      "they touch the front stops. Push the USB connectors onto the plugs while holding the board, since the rails stop "
      "the board only toward the front. Lower the stack onto the 4 pegs; no screws. Screw the two right-angle RP-SMA "
      "plugs on.")
    a("6. Each nRF24 is set down 11 mm forward and slid back through its hole. Then the stop bar, then the strap (tab in "
      "the notch, 1 x M3 x 8).")
    a("7. Lid: screen (4 x M2.5 x 4) and buttons fitted to the lid first, wired, then lowered on; the lips locate it. "
      "4 x M3 x 8. The lid is what holds the NIC stack down.")
    a("")
    a("Disassembly is the reverse. With the lid off and the two RA plugs unscrewed, the NIC stack lifts straight out with "
      "its USB connectors still on the plugs; the shelf stays in. To reach NIC A's Pi-side plug, slide the PN532 up "
      "15 mm. For NIC B's, tilt the breadboard's left end up about 12 deg. The buzzer comes out only with the shelf out.")
    a("")
    # -------------------------------------------------------------------------------------------- 10
    a("## 10. What still needs a physical prototype")
    a("")
    a("CAD cannot confirm these. In order of risk:")
    a("")
    tests = [
        "**Fit coupon first** (about 1 h 45 min). Check the insert holes, the SMA hole and spot face, the nRF hole and "
        "pocket, the KCD11 cut-out in 2 mm, and the PBS-11A hole. Check both NIC rail samples. The antenna edge of a "
        "WN722N must slide between the left ribs with a little play. Its button edge must run along the right ledge with "
        "the plunger passing the recess untouched. Adjust the parameter for any fit that is wrong before printing the "
        "14-16 h base.",
        "**WN722N width and button:** measure the PCB width with calipers and print the matching right rail (section "
        "4.2). The button is taken as 2 mm high, with its plunger 1 mm past the edge and nothing else within 2.5 mm of "
        "either long edge, as you described. Check that the board slides all the way in without the plunger catching. "
        "Check that the parts on both faces clear the ribs; the model assumes 1.4 mm of parts on each face.",
        "**NIC stack held by the lid:** the rails only sit on their pegs. The lid's right lip is 0.3 mm over the right "
        "rail and two posts reach 0.3 mm under the lid on the left rail. With the lid screwed down, check that nothing "
        "rattles. If it does, a dab of hot glue or a thin foam pad on the posts takes up the play.",
        "**USB connectors:** check that your connectors and their cables fit in front of the plugs (section 4.2) and that "
        "the cables reach the Pi along the route behind the breadboard without tight bends.",
        "**Parts whose size is assumed (`[A]` in params.py):** the USB plug position on the WN722N (taken as centred), "
        "the SMA flange and thread length, the KY-013 header side, the ESP's underside (USB-C receptacle positions, "
        "shield), the 90 deg USB-C plug body (must be 12 x 7.8 mm or smaller), the PBS-11A nut, the microSD position, the "
        "antenna whips. Measure each on arrival against the value in params.py.",
        "**ESP retention:** the snap lip overlaps the module end by only 0.2-0.5 mm, and nothing holds the USB end down "
        "except the 90 deg plug. Check the board stays put with the cable fitted. If it lifts, the planned fallback is a "
        "strip of thin double-sided tape on the USB-end pad.",
        "**Cables:** the 90 deg USB-C cable has about 6 mm of room under the shelf, so use a thin cable, 3.5 mm or less. "
        "Check the NIC USB wires and the RP-SMA coax pigtails route through their reserved zones without tight bends; "
        "thin RG178-class pigtails are the safe choice.",
        "**Button nuts:** with 18 AF nuts, neighbours end up 1.2 mm apart, so no socket or ring spanner fits once a "
        "neighbour is on. Tighten by hand: hold the nut inside and turn the button from outside. Check the real nut (size "
        "and thickness) when the buttons arrive.",
        "**Heat:** the fan's intake is partly covered and the fan sits 1.0 mm above a 10 mm heatsink. Measure the Pi's "
        "temperature under load with the lid on, and the NICs' temperature with and without the shelf vents if they run "
        "hot.",
        "**Radio:** six antennas share the back band, 18.5-19 mm apart. Check range and interference once all radios "
        "run together.",
        "**First print:** watch for base corners lifting (add a brim), the 0.8 mm ESP lip ledge, the 45 deg pocket roofs, "
        "and whether the KCD11 clips grip a 2 mm wall.",
        "**Lid:** check the 0.3 mm lip gap gives a snug, rattle-free fit and that all four screws reach their inserts "
        "without forcing.",
    ]
    for i, t in enumerate(tests, 1):
        a(f"{i}. {t}")
    a("")
    # -------------------------------------------------------------------------------------------- 11
    a("## 11. Changing the design")
    a("")
    a("All dimensions are in `cad/params.py`, each tagged with its source. After a change, run, in `cad/`:")
    a("")
    a("```")
    a("python3 validate.py   # collisions, clearances, fitting sequence, maintenance moves  -> out/validation.json")
    a("SENTINEL_NIC_W=21.0 python3 validate.py   # same for another WN722N width          -> out/validation_w21.0.json")
    a("python3 export.py     # STL (print orientation), STEP, assembly GLB                    -> deliverables/")
    a("python3 stl_qa.py     # mesh, overhang and wall-thickness checks of the STL files     -> out/stl_qa.json")
    a("python3 slice.py      # PrusaSlicer: filament and time                                -> out/slice.json")
    a("python3 fe_shelf.py   # shelf bending with and without the vent holes                -> out/fe_shelf.json")
    a("python3 views.py      # rendered views;  python3 drawings.py  # drawing sheets (PDF)")
    a("python3 report.py     # this report")
    a("```")
    a("")
    a("Needs Python 3.10+ with CadQuery 2.x, manifold3d, trimesh (plus embreex for fast ray casting), matplotlib, shapely "
      "and scikit-fem. OpenSCAD renders the views and PrusaSlicer 2.7 does the slicing. The parts are built in `base.py`, "
      "`lid.py`, `shelf.py` and `coupon.py`. The bought parts are in `bought.py`, and the fitting sequence in "
      "`assembly.py`. To take the vent holes out, call `build_shelf(vents=False)` or empty `SHELF_VENTS['zones']`.")
    a("")
    return "\n".join(L_) + "\n"


if __name__ == "__main__":
    os.makedirs(os.path.join(HERE, "deliverables"), exist_ok=True)
    txt = build()
    open(os.path.join(HERE, "deliverables", "REPORT.md"), "w").write(txt)
    print(len(txt), "chars")
