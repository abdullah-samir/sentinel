"""Assembly validation on exact-ish meshes (CadQuery tessellation, 0.02 mm chord error) with manifold3d booleans.

1. static interference between every pair of items (real intersection volumes)
2. clearance: the smallest gaps between solid items (contacts, tight spots)
3. fitting sequence: every installed item swept along its installation path against everything already fitted
4. maintenance moves: plug pull-outs, PN532 slide-up, breadboard tilt, KY-013 and nRF removal, SD card, WN722N on the bench
Writes out/validation.json (or out/validation_w<width>.json when SENTINEL_NIC_W sets the WN722N board width) and
prints a summary.
"""
import json, math, os, sys, time
import numpy as np
import manifold3d as mf
from assembly import all_items, STEPS
from params import *

HERE = os.path.dirname(os.path.abspath(__file__))
VOL_TOL = 0.01          # mm3: intersections below this are numerical contact
STEP_MM = 0.5           # sampling step along installation paths


def to_mf(shape, tol=0.02, ang=0.15):
    vs, ts = shape.tessellate(tol, ang)
    v = np.array([(p.x, p.y, p.z) for p in vs], dtype=np.float32)
    t = np.array(ts, dtype=np.uint32)
    m = mf.Mesh(vert_properties=v, tri_verts=t)
    m.merge()
    out = mf.Manifold(m)
    if out.status() != mf.Error.NoError:
        raise RuntimeError(f"mesh not manifold: {out.status()}")
    return out


def bb_of(m):
    b = m.bounding_box()
    return np.array(b[:3]), np.array(b[3:])


def bb_hit(a, b, pad=0.0):
    return bool(np.all(a[0] < b[1] + pad) and np.all(b[0] < a[1] + pad))


def matches(name, pat):
    if name == pat:
        return True
    if pat.endswith(".") or pat.endswith("_"):
        return name.startswith(pat)
    return name.startswith(pat) and len(name) > len(pat) and (name[len(pat)].isdigit() or name[len(pat)] == ".")


def allowed(a, b):
    if a.group == b.group and a.group not in ("base", "shelf", "lid"):
        return True
    for x, y in ((a, b), (b, a)):
        for pat in x.allow:
            if y.name == pat or y.name.startswith(pat):
                return True
    return False


class Model:
    def __init__(self):
        t = time.time()
        self.items = all_items()
        self.mf, self.bb = {}, {}
        for it in self.items:
            m = to_mf(it.shape)
            self.mf[it.name] = m
            self.bb[it.name] = bb_of(m)
        self.by = {it.name: it for it in self.items}
        print(f"{len(self.items)} items meshed in {time.time() - t:.1f} s")

    def inter(self, a, b, da=(0, 0, 0)):
        ma = self.mf[a].translate(da) if any(da) else self.mf[a]
        return (ma ^ self.mf[b]).volume()


# ------------------------------------------------------------------ 1. static interference
def static_check(M):
    res = []
    names = [it.name for it in M.items]
    for i, a in enumerate(M.items):
        for b in M.items[i + 1:]:
            ka, kb = a.kind, b.kind
            if ka != "solid" and kb != "solid":
                continue
            if allowed(a, b) or not bb_hit(M.bb[a.name], M.bb[b.name], -0.005):
                continue
            v = M.inter(a.name, b.name)
            if v <= VOL_TOL:
                continue
            sev = "ERROR" if "soft" not in (ka, kb) else "WARN"
            res.append(dict(sev=sev, a=a.name, b=b.name, kinds=f"{ka}/{kb}", vol=round(v, 3)))
    return res


# ------------------------------------------------------------------ 2. clearances
def clearance_check(M, search=1.5):
    rows = []
    sol = [it for it in M.items if it.kind == "solid"]
    for i, a in enumerate(sol):
        for b in sol[i + 1:]:
            if allowed(a, b) or not bb_hit(M.bb[a.name], M.bb[b.name], search):
                continue
            g = M.mf[a.name].min_gap(M.mf[b.name], search)
            if g < search:
                rows.append(dict(a=a.name, b=b.name, gap=round(float(g), 3)))
    rows.sort(key=lambda r: r["gap"])
    return rows


# ------------------------------------------------------------------ 3. installation paths
def waypoints(motion):
    """List of offsets from the final position, in travel order, ending at (0,0,0)."""
    if not motion:
        return [np.zeros(3)]
    pts = [np.zeros(3)]
    for kind, val in reversed(motion):
        v = np.array([0, 0, -val], float) if kind == "lower" else np.array(val, float)
        pts.insert(0, pts[0] - v)
    return pts


def samples(pts, step=STEP_MM):
    out = []
    for p, q in zip(pts[:-1], pts[1:]):
        n = max(1, int(math.ceil(np.linalg.norm(q - p) / step)))
        for k in range(n):
            out.append(p + (q - p) * k / n)
    out.append(pts[-1])
    return out


def sweep_check(M, moving, fixed, motion, expect=()):
    """moving: item names (solid) moving together; fixed: item names. Returns list of collisions."""
    pts = waypoints(motion)
    offs = samples(pts)
    lo = np.min(np.array(offs), axis=0)
    hi = np.max(np.array(offs), axis=0)
    hits = {}
    for a in moving:
        ba = M.bb[a]
        swept = (ba[0] + lo, ba[1] + hi)
        cands = [f for f in fixed if M.by[f].kind != "soft" and not allowed(M.by[a], M.by[f]) and bb_hit(swept, M.bb[f], -0.005)]
        if not cands:
            continue
        for f in cands:
            fb = M.bb[f]
            worst, at = 0.0, None
            for o in offs:
                if not bb_hit((ba[0] + o, ba[1] + o), fb, -0.005):
                    continue
                v = M.inter(a, f, tuple(float(x) for x in o))
                if v > worst:
                    worst, at = v, o
            if worst > VOL_TOL:
                key = (a, f)
                hits[key] = dict(moving=a, fixed=f, vol=round(worst, 3), at=[round(float(x), 2) for x in at],
                                 expected=any(f.startswith(e) for e in expect))
    return list(hits.values())


def esp_tilt_transforms(theta0=-15.0, back=5.0, drop=20.0):
    """ESP fitted by tilting: module end slid under the snap lip with the USB end raised, then swung down about the module end."""
    P = np.array([0.0, ESP["y0"] + ESP["l"], ESP_MOD["z"][1]])
    def rot(th, t):
        return lambda m: m.translate(tuple(-P)).rotate((th, 0, 0)).translate(tuple(P + t))
    tfs = []
    for k in range(int(drop / STEP_MM) + 1):                        # lower, tilted, 5 mm in front of the place
        tfs.append(rot(theta0, np.array([0, -back, drop - k * STEP_MM])))
    for k in range(int(back / STEP_MM) + 1):                        # slide back under the lip
        tfs.append(rot(theta0, np.array([0, -back + k * STEP_MM, 0])))
    n = int(abs(theta0) / 0.5)
    for k in range(n + 1):                                           # swing down
        tfs.append(rot(theta0 * (1 - k / n), np.zeros(3)))
    return tfs


def sweep_check_tf(M, moving, fixed, tfs):
    hits = {}
    for a in moving:
        moved = [tf(M.mf[a]) for tf in tfs]
        bbs = [bb_of(m) for m in moved]
        lo = np.min([b[0] for b in bbs], axis=0)
        hi = np.max([b[1] for b in bbs], axis=0)
        cands = [f for f in fixed if M.by[f].kind != "soft" and not allowed(M.by[a], M.by[f]) and bb_hit((lo, hi), M.bb[f], -0.005)]
        for f in cands:
            worst, at = 0.0, None
            for k, (m, b) in enumerate(zip(moved, bbs)):
                if not bb_hit(b, M.bb[f], -0.005):
                    continue
                v = (m ^ M.mf[f]).volume()
                if v > worst:
                    worst, at = v, k
            if worst > VOL_TOL:
                hits[(a, f)] = dict(moving=a, fixed=f, vol=round(worst, 3), at=f"transform {at}/{len(tfs)}", expected=False)
    return list(hits.values())


def resolve(M, pats):
    return [it.name for it in M.items if any(matches(it.name, p) for p in pats)]


def sequence_check(M):
    out = []
    installed = []
    placed = set()
    for st in STEPS:
        names = [n for n in resolve(M, st["items"]) if n not in placed]
        solids = [n for n in names if M.by[n].kind == "solid"]
        if st["motion"] == "esp_tilt":
            hits = sweep_check_tf(M, solids, installed, esp_tilt_transforms())
        else:
            hits = sweep_check(M, solids, installed, st["motion"]) if st["motion"] else []
        out.append(dict(step=st["step"], desc=st["desc"], items=len(solids), collisions=hits))
        installed += solids
        placed.update(names)
    missing = [it.name for it in M.items if it.kind == "solid" and it.name not in placed]
    return out, missing


# ------------------------------------------------------------------ 4. maintenance moves
def maintenance_check(M):
    all_solid = [it.name for it in M.items if it.kind == "solid"]
    R = []

    def run(title, moving_pats, motion, remove_pats=(), shifted=None, note=""):
        removed = set(resolve(M, remove_pats))
        moving = [n for n in resolve(M, moving_pats) if M.by[n].kind == "solid" and n not in removed]
        fixed = [n for n in all_solid if n not in moving and n not in removed]
        saved = {}
        if shifted:                                   # temporarily move some fixed items (e.g. PN532 slid up)
            for pat, d in shifted:
                for n in resolve(M, [pat]):
                    saved[n] = M.mf[n]
                    M.mf[n] = M.mf[n].translate(d)
                    M.bb[n] = (M.bb[n][0] + np.array(d), M.bb[n][1] + np.array(d))
        hits = sweep_check_tf(M, moving, fixed, esp_tilt_transforms()) if motion == "esp_tilt" else sweep_check(M, moving, fixed, motion)
        for n, m in saved.items():
            M.mf[n] = m
            M.bb[n] = bb_of(m)
        R.append(dict(check=title, note=note, collisions=hits))

    def rem(*ds):
        """Removal: displacements in travel order -> the equivalent installation motion (same swept positions)."""
        return [("push", tuple(-x for x in d)) for d in reversed(ds)]

    lid_off = ["lid", "tft.", "btn", "lid_screw", "tft_screw"]
    run("ESP link plug out of the Pi (USB 3 upper), everything fitted", ["usbplug.esp"], rem((0, -14, 0)))
    run("NIC A plug out (USB 2 upper), PN532 slid up 15 mm", ["usbplug.wn1"], rem((0, -14, 0)), shifted=[("pn.", (0, 0, 15.0))])
    run("NIC A plug out (USB 2 upper), PN532 left in place", ["usbplug.wn1"], rem((0, -14, 0)),
        note="expected to collide: the PN532 must slide up first")
    run("NIC B plug out (USB 3 lower), breadboard in place", ["usbplug.wn2"], rem((0, -14, 0)),
        note="expected to collide: the breadboard must be lifted first")
    run("90 deg USB-C plug out of the ESP, breadboard in place", ["usbc90.plug"], rem((0, -7.0, 0)))
    run("microSD card out through the back slot, everything fitted", ["pi.sdcard"], rem((0, 16.0, 0)))
    run("PN532 lifted out (lid off), everything else fitted", ["pn.pcb", "pn.parts", "pn.hdr"], rem((0, 0, 70.0)), remove_pats=lid_off)
    run("KY-013 out with the shelf fitted: slid 12 mm forward, lifted through the shelf's back cut-out",
        ["ky.pcb", "ky.parts", "ky.pins"], rem((0, -12.0, 0), (0, 0, 70.0)), remove_pats=lid_off)
    run("nRF24 out (stop bar and strap off): slid 11 mm forward, lifted", ["nrf1.", "nrf2."], rem((0, -11.0, 0), (0, 0, 40.0)),
        remove_pats=lid_off + ["nrf_stop", "nrf_strap", "strap_screw", "ant1", "ant2"])
    nic = ["nic_rail_l", "nic_rail_r", "wn1.", "wn2.", "socket"]
    run("NIC stack lifted out (lid off, RA plugs unscrewed; USB connectors stay on the plugs)", nic, rem((0, 0, 45.0)),
        remove_pats=lid_off + ["wn1ra", "wn2ra"])
    run("Shelf lifted out (NIC stack, RA plugs, nRFs, strap, stop and screws off)", ["shelf", "fan.body", "fan_spacer", "fan_screw", "fan_nut",
                                                                                   "strap_insert"], rem((0, 0, 45.0)),
        remove_pats=lid_off + nic + ["nrf_stop", "nrf_strap", "strap_screw", "nrf1.", "nrf2.", "wn1ra", "wn2ra", "shelf_screw", "ant1", "ant2"])
    run("Buzzer lifted out with the shelf fitted (NIC stack out)", ["buz.body"], rem((0, 0, 40.0)), remove_pats=lid_off + nic + ["wn1ra", "wn2ra"],
        note="expected to collide: the shelf's front edge is over the buzzer's rear ear, so the shelf comes out first (as in rev 5)")
    run("Buzzer lifted out with the shelf removed", ["buz.body"], rem((0, 0, 40.0)),
        remove_pats=lid_off + nic + ["shelf", "fan.", "fan_", "wn1ra", "wn2ra", "strap_insert", "strap_screw",
                               "nrf_stop", "nrf_strap", "nrf1.", "nrf2.", "shelf_screw", "ant1", "ant2"])
    run("ESP tilted out with the shelf removed (USB-C plug and lead stay on it)", ["esp.", "usbc90.plug"], "esp_tilt",
        remove_pats=lid_off + nic + ["shelf", "fan.", "fan_", "wn1ra", "wn2ra", "strap_insert", "strap_screw",
                               "nrf_stop", "nrf_strap", "nrf1.", "nrf2.", "shelf_screw", "ant1", "ant2"],
        note="the two RA plugs hang on their coax once unscrewed and are moved aside")
    run("Pi lifted out (SD card, power cable, Pi-end plugs out; shelf and ESP out)", ["pi.", "pi_screw"], rem((0, 0, 70.0)),
        remove_pats=lid_off + nic + ["shelf", "fan.", "fan_", "wn1ra", "wn2ra", "strap_insert", "strap_screw",
                               "nrf_stop", "nrf_strap", "nrf1.", "nrf2.", "shelf_screw", "ant1", "ant2", "esp.", "usbc90.plug", "usbplug.",
                               "power.plug", "pi.sdcard"])
    run("WN722N slid out of its rails at the back (stack on the bench, RA plug and USB connector off)", ["wn2.pcb", "wn2.parts", "wn2.jack", "wn2.plug"],
        rem((0, 80.0, 0)), remove_pats=[n for n in all_solid if n not in ("nic_rail_l", "nic_rail_r", "wn1.pcb", "wn1.parts", "wn1.jack", "wn1.plug")])
    run("Lid lifted off", ["lid", "tft.pcb", "tft.glass", "tft.j2", "tft.j4", "tft.sd", "tft_screw", "btn"], rem((0, 0, 50.0)),
        remove_pats=["lid_screw"])
    return R


def tilt_breadboard(M):
    """Breadboard tilted up at its left end (pivot on its right end under the sled) so NIC B's plug can come out."""
    import manifold3d as mf
    res = []
    bbm = M.mf["bb.body"]
    pivot = np.array([BB["x1"], 0, 0.0])
    for ang in (6, 8, 10, 12):
        a = math.radians(ang)
        # rotate about the y axis through the pivot (left end goes up)
        m = bbm.translate(tuple(-pivot)).rotate((0, ang, 0)).translate(tuple(pivot))
        lift_at_plug = (BB["x1"] - 30.5) * math.sin(a)
        clash = []
        for n in ("shelf", "base", "usbplug.esp"):
            v = (m ^ M.mf[n]).volume()
            if v > VOL_TOL:
                clash.append((n, round(v, 2)))
        # NIC B plug path clear of the tilted board?
        path = M.mf["usbplug.wn2"]
        swept_hit = 0.0
        for k in range(0, 29):
            swept_hit = max(swept_hit, (path.translate((0, -0.5 * k, 0)) ^ m).volume())
        res.append(dict(angle=ang, lift_at_plug=round(lift_at_plug, 1), clashes=clash, plug_path_hit=round(swept_hit, 2)))
    return res


def main():
    t = time.time()
    M = Model()
    st = static_check(M)
    print(f"static: {sum(r['sev'] == 'ERROR' for r in st)} errors, {sum(r['sev'] == 'WARN' for r in st)} warnings ({time.time() - t:.0f} s)")
    for r in st:
        print("  ", r)
    cl = clearance_check(M)
    print(f"clearance pairs under 1.5 mm: {len(cl)}")
    seq, missing = sequence_check(M)
    print("sequence:")
    for s in seq:
        print(f"  {s['step']:16s} items {s['items']:3d} collisions {len(s['collisions'])}")
        for c in s["collisions"]:
            print("      ", c)
    print("not in any step:", missing)
    mt = maintenance_check(M)
    print("maintenance:")
    for m in mt:
        print(f"  {m['check']}: {len(m['collisions'])} collisions")
        for c in m["collisions"]:
            print("      ", c)
    tb = tilt_breadboard(M)
    print("breadboard tilt:", tb)
    out = dict(static=st, clearance=cl, sequence=seq, not_in_sequence=missing, maintenance=mt, breadboard_tilt=tb,
               items=[dict(name=it.name, kind=it.kind, stage=it.stage, note=it.note) for it in M.items])
    os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
    out["nic_pcb_w"] = NIC_PCB_W
    fn = "validation.json" if "SENTINEL_NIC_W" not in os.environ else f"validation_w{NIC_PCB_W:.1f}.json"
    json.dump(out, open(os.path.join(HERE, "out", fn), "w"), indent=1)
    print(f"done in {time.time() - t:.0f} s")


if __name__ == "__main__":
    main()
