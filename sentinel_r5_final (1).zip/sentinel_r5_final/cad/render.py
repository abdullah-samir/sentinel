"""OpenSCAD renders of STL meshes (used for visual checks, the assembly views and the exploded view)."""
import os, subprocess, tempfile
import cadquery as cq

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "out", "render_cache")
os.makedirs(CACHE, exist_ok=True)


def stl_of(shape, name, tol=0.05, ang=0.2):
    fn = os.path.join(CACHE, name.replace(".", "_").replace(" ", "_") + ".stl")
    cq.exporters.export(cq.Workplane().add(shape), fn, tolerance=tol, angularTolerance=ang)
    return fn


def scad_src(entries, clip=None):
    """entries: list of dict(file, color '#rrggbb', alpha, offset (dx,dy,dz))."""
    lines = []
    for e in entries:
        c = e.get("color", "#999999")
        rgb = [int(c[i:i + 2], 16) / 255 for i in (1, 3, 5)]
        dx, dy, dz = e.get("offset", (0, 0, 0))
        a = e.get("alpha", 1.0)
        lines.append(f'translate([{dx},{dy},{dz}]) color([{rgb[0]:.3f},{rgb[1]:.3f},{rgb[2]:.3f},{a}]) import("{os.path.abspath(e["file"])}", convexity=6);')
    body = "\n".join(lines)
    if clip:
        x0, x1, y0, y1, z0, z1 = clip
        body = f"intersection() {{ union() {{\n{body}\n}} translate([{x0},{y0},{z0}]) cube([{x1 - x0},{y1 - y0},{z1 - z0}]); }}"
    return body


def render(entries, png, eye, center, size=(1600, 1150), ortho=False, clip=None, scheme="Tomorrow"):
    src = os.path.splitext(png)[0] + ".scad"
    open(src, "w").write(scad_src(entries, clip))
    cam = ",".join(str(round(v, 3)) for v in (*eye, *center))
    cmd = ["xvfb-run", "-a", "openscad", "-o", png, f"--imgsize={size[0]},{size[1]}", f"--camera={cam}",
           f"--projection={'o' if ortho else 'p'}", f"--colorscheme={scheme}", src]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    if r.returncode != 0:
        print(r.stderr[-3000:])
    return png


C0 = (61.5, 72.5, 28.0)


def eye_dir(dx, dy, dz, dist, c=C0):
    import math
    n = math.sqrt(dx * dx + dy * dy + dz * dz)
    return (c[0] + dx / n * dist, c[1] + dy / n * dist, c[2] + dz / n * dist), c
