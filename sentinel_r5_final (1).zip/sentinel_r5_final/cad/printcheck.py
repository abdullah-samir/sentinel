"""Printability check on the exported STL meshes, in their print orientation.

Every down-facing patch steeper than 46 deg from vertical is found and classified by how it is held while printing:
  bridge     - supported along two separate edges (slicer bridges across)        -> span
  cantilever - supported along one edge only (a ledge sticking out into the air)  -> depth
  island     - no supported edge (starts in mid-air)
An edge is 'supported' when the neighbouring surface across it runs downward from the edge (material continues below).
"""
import glob, json, os, sys
import numpy as np
import trimesh
from trimesh.graph import connected_components

NZ_LIM = -0.72          # steeper than ~46 deg from vertical
FLAT = -0.98
LIMITS = dict(bridge=25.0, cantilever=0.8, slope_cantilever=1.2, slope_bridge=12.0)


def _seg_dist(p, a, b):
    ab = b - a
    t = np.clip(((p - a) @ ab) / max(ab @ ab, 1e-12), 0, 1)
    return np.linalg.norm(p - (a + t * ab))


def analyse(m):
    n, c, A = m.face_normals, m.triangles_center, m.area_faces
    zmin = m.bounds[0][2]
    sel = (n[:, 2] < NZ_LIM) & (c[:, 2] > zmin + 0.25)
    idx = np.where(sel)[0]
    if not len(idx):
        return []
    adj, adj_e = m.face_adjacency, m.face_adjacency_edges
    both = sel[adj[:, 0]] & sel[adj[:, 1]]
    groups = connected_components(adj[both], nodes=idx, min_len=1)
    one = sel[adj[:, 0]] ^ sel[adj[:, 1]]
    border = {}
    for (f0, f1), e in zip(adj[one], adj_e[one]):
        inside, other = (f0, f1) if sel[f0] else (f1, f0)
        border.setdefault(inside, []).append((other, e))
    out = []
    V = m.vertices
    for g in groups:
        g = np.asarray(g)
        area = float(A[g].sum())
        if area < 0.3:
            continue
        nzm = float(np.average(n[g, 2], weights=A[g]))
        sup = []
        for f in g:
            for other, e in border.get(f, []):
                mid = V[e].mean(0)
                ed = V[e[1]] - V[e[0]]
                ed = ed / max(np.linalg.norm(ed), 1e-12)
                v = c[other] - mid
                v = v - (v @ ed) * ed                                   # across the edge, not along it
                if v[2] / max(np.linalg.norm(v), 1e-9) < -0.05:      # neighbour runs downward from this edge
                    sup.append((V[e[0], :2], V[e[1], :2]))
        pts = np.unique(np.vstack([V[m.faces[g]].reshape(-1, 3)[:, :2], c[g, :2]]).round(3), axis=0)
        flat = nzm < FLAT
        lim_b = LIMITS["bridge"] if flat else LIMITS["slope_bridge"]
        lim_c = LIMITS["cantilever"] if flat else LIMITS["slope_cantilever"]
        if sup:
            # per sample point: nearest support in each of 8 direction sectors (45 deg each)
            A0 = np.array([s[0] for s in sup]); B0 = np.array([s[1] for s in sup])
            AB = B0 - A0
            L2 = np.maximum((AB * AB).sum(1), 1e-12)
            # a point is held if it is within lim_c of a support (overhang) or lies on a bridge no longer than lim_b
            cant, span, ok = 0.0, 0.0, True
            for p in pts:
                t = np.clip(((p - A0) * AB).sum(1) / L2, 0, 1)
                q = A0 + t[:, None] * AB
                dv = q - p
                d = np.linalg.norm(dv, axis=1)
                d1 = float(d.min())
                if d1 <= lim_c:
                    cant = max(cant, d1)
                    continue
                sec = (np.floor((np.arctan2(dv[:, 1], dv[:, 0]) + np.pi) / (np.pi / 4)).astype(int)) % 8
                best = np.full(8, np.inf)
                np.minimum.at(best, sec, d)
                sp_ = float(min(best[k] + best[(k + j) % 8] for k in range(8) for j in (3, 4, 5)))
                if sp_ <= lim_b:
                    span = max(span, sp_)              # bridged between two roughly opposite supports
                else:
                    ok = False                          # neither: a real unsupported overhang
                    if np.isfinite(sp_):
                        span = max(span, sp_)
                    cant = max(cant, d1)
            kind = "cantilever" if cant > lim_c else ("bridge" if span > 0 else "overhang")
            reach = cant if kind == "cantilever" else (span if kind == "bridge" else cant)
        else:
            kind, reach, cant, span = "island", float("inf"), float("inf"), 0.0
            ok = area < 1.0       # tip of a cone or similar: a few strands
        lim = lim_b if kind == "bridge" else lim_c
        b0, b1 = V[np.unique(m.faces[g])].min(0), V[np.unique(m.faces[g])].max(0)
        out.append(dict(kind=kind, flat=bool(flat), area=round(area, 1), reach=round(reach, 2), limit=lim, ok=bool(ok),
                        cantilever=round(cant, 2), bridge_span=round(span, 2),
                        nz=round(nzm, 2), bbox=[b0.round(1).tolist(), b1.round(1).tolist()]))
    out.sort(key=lambda r: (r["ok"], -r["reach"] if np.isfinite(r["reach"]) else -1e9))
    return out


def main(folder="stl", verbose=True):
    res = {}
    for fn in sorted(glob.glob(os.path.join(folder, "*.stl"))):
        m = trimesh.load(fn)
        rows = analyse(m)
        name = os.path.basename(fn)[:-4]
        bad = [r for r in rows if not r["ok"]]
        br = [r["bridge_span"] for r in rows if r["flat"]]
        ca = [r["cantilever"] for r in rows if r["kind"] != "island"]
        res[name] = dict(patches=len(rows), problems=bad, max_bridge=max(br) if br else 0.0,
                         max_cantilever=max(ca) if ca else 0.0,
                         size=[round(float(e), 1) for e in m.extents], watertight=bool(m.is_watertight),
                         bodies=len(m.split(only_watertight=False)))
        if verbose:
            print(f"{name:26s} patches={len(rows):3d} problems={len(bad)} max bridge={res[name]['max_bridge']:.1f} "
                  f"max cantilever={res[name]['max_cantilever']:.2f} size={res[name]['size']} watertight={m.is_watertight}")
            for r in bad:
                print("    !", r)
    return res


if __name__ == "__main__":
    r = main(sys.argv[1] if len(sys.argv) > 1 else "stl")
    json.dump(r, open("out/printcheck.json", "w"), indent=1)
