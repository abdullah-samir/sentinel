"""Bending check of the shelf plate with and without the hexagonal vent holes (Kirchhoff plate, Morley triangles,
scikit-fem). Conservative model: the 2.4 mm plate alone (the cradle, lip and pegs add stiffness that is ignored),
resting on the wall ledges and clamped only vertically at the two screw posts.

Loads: the plate's own weight, the parts it carries (masses rounded up, see PARTS_G) and, separately, a 20 N press with
a fingertip (8 mm patch) at the worst of several points among the vent holes.
PETG taken as E = 1800 MPa (printed, conservative), nu = 0.38, allowable bending stress 40 MPa.
Writes out/fe_shelf.json."""
import json, math, os
import numpy as np
from shapely.geometry import Polygon, Point, box as sbox
from shapely.ops import unary_union
import shapely
from skfem import MeshTri, Basis, ElementTriMorley, ElementTriP1, BilinearForm, LinearForm, asm, solve, condense
from skfem.helpers import dd, ddot, trace, eye
from params import *
from shelf import plate_outline, fan_holes, vent_holes

HERE = os.path.dirname(os.path.abspath(__file__))
E_MPA, NU, T = 1800.0, 0.38, SHELF_T
G = 9.81e-3                       # N per gram
RHO = 1.27e-3                     # g/mm3
ALLOW = 40.0
H_MESH = 0.7
PARTS_G = {"NIC stack (2 WN722N, 2 rails, USB connectors)": 50.0, "2 nRF24 + adapters": 30.0, "fan + spacers + screws": 20.0,
           "cradle, strap, stop bar": 10.0}


def region(vents):
    poly = Polygon(plate_outline())
    holes = [Point(FAN["cx"], FAN["cy"]).buffer(FAN_OPEN_D / 2, 64), sbox(SLOT[0], SLOT[2], SLOT[1], SLOT[3])]
    holes += [Point(x, y).buffer(M3_CLEAR / 2, 16) for x, y in list(SHELF_POSTS) + fan_holes()]
    holes += [Point(px, (NRF_STOP["y0"] + NRF_STOP["y1"]) / 2).buffer((NRF_STOP["peg_d"] + 0.3) / 2, 16) for px in NRF_STOP["pegs"]]
    if vents:
        rc = SHELF_VENTS["af"] / math.sqrt(3)
        holes += [Polygon([(x + rc * math.cos(math.radians(60 * k)), y + rc * math.sin(math.radians(60 * k))) for k in range(6)])
                  for x, y in vent_holes()]
    return poly.difference(unary_union(holes))


def mesh_of(reg, h=H_MESH):
    x0, y0, x1, y1 = reg.bounds
    nx, ny = int(math.ceil((x1 - x0) / h)) + 1, int(math.ceil((y1 - y0) / h)) + 1
    xs, ys = np.linspace(x0, x0 + (nx - 1) * h, nx), np.linspace(y0, y0 + (ny - 1) * h, ny)
    X, Y = np.meshgrid(xs, ys, indexing="ij")
    idx = np.arange(nx * ny).reshape(nx, ny)
    a, b, c, d = idx[:-1, :-1].ravel(), idx[1:, :-1].ravel(), idx[1:, 1:].ravel(), idx[:-1, 1:].ravel()
    tris = np.vstack([np.stack([a, b, c], 1), np.stack([a, c, d], 1)])
    P = np.stack([X.ravel(), Y.ravel()], 1)
    cen = P[tris].mean(axis=1)
    keep = shapely.contains_xy(reg, cen[:, 0], cen[:, 1])
    tris = tris[keep]
    used = np.unique(tris)
    remap = -np.ones(len(P), int)
    remap[used] = np.arange(len(used))
    return MeshTri(P[used].T, remap[tris].T)


def loads():
    """Load density q(x, y) in N/mm2 (downward positive)."""
    self_w = RHO * T * G
    patches = []
    r = NIC_RAIL
    wr = (nic_right()["recess"] - r["flange"][0], nic_right()["outer"])       # right rail footprint (foot flange to outer face)
    nic_area = (r["wl"][1] - r["wl"][0]) * (r["y1_l"] - r["y0"]) + (wr[1] - wr[0]) * (r["y1_r"] - r["y0"])
    patches.append(([(r["wl"][0], r["wl"][1], r["y0"], r["y1_l"]), (wr[0], wr[1], r["y0"], r["y1_r"])],
                    PARTS_G["NIC stack (2 WN722N, 2 rails, USB connectors)"] * G / nic_area))
    ad = [(x - 9.5, x + 9.5, NRF_YS, NRF_YS + 26) for x in NRF_X]
    patches.append((ad, PARTS_G["2 nRF24 + adapters"] * G / (2 * 19 * 26)))
    cr = [(SHELF_X[0], CUT[0], CRADLE["y0"], CRADLE["y1"])]
    patches.append((cr, PARTS_G["cradle, strap, stop bar"] * G / ((CUT[0] - SHELF_X[0]) * (CRADLE["y1"] - CRADLE["y0"]))))
    fan_r = 3.5
    fan_pts = fan_holes()

    def q(x, y):
        out = np.full(x.shape, self_w)
        for rects, dens in patches:
            for (a, b, c, d) in rects:
                out += dens * ((x >= a) & (x <= b) & (y >= c) & (y <= d))
        for fx, fy in fan_pts:
            out += (PARTS_G["fan + spacers + screws"] * G / 4) / (math.pi * fan_r ** 2) * (((x - fx) ** 2 + (y - fy) ** 2) <= fan_r ** 2)
        return out
    return q


def total_force(m, q):
    @LinearForm
    def one(v, w):
        return q(w.x[0], w.x[1]) * v
    return float(asm(one, Basis(m, ElementTriP1())).sum())


def solve_case(m, q, near_vents=None):
    e = ElementTriMorley()
    ib = Basis(m, e)
    D_ = E_MPA * T ** 3 / (12 * (1 - NU ** 2))

    @BilinearForm
    def bil(u, v, w):
        def C(Tn):
            return E_MPA / (1 + NU) * (Tn + NU / (1 - NU) * eye(trace(Tn), 2))
        return T ** 3 / 12.0 * ddot(C(dd(u)), dd(v))

    @LinearForm
    def lin(v, w):
        return q(w.x[0], w.x[1]) * v

    K, f = asm(bil, ib), asm(lin, ib)
    px, py = m.p
    sup = np.zeros(m.p.shape[1], bool)
    lx = px <= 2.0 + 1e-6                                          # left ledges (x 0-2)
    sup |= lx & np.any([(py >= a) & (py <= b) for a, b in LEDGE_L_Y], axis=0)
    rx = px >= L - LEDGE_W - 1e-6                                  # right ledge (x 121-123)
    sup |= rx & np.any([(py >= a) & (py <= b) for a, b in LEDGE_R_Y], axis=0)
    for sx, sy in SHELF_POSTS:                                     # screwed onto the posts
        rr = np.hypot(px - sx, py - sy)
        sup |= (rr <= SHELF_POST_D / 2) & (rr >= M3_CLEAR / 2 - 0.3)
    D = ib.nodal_dofs[0, np.where(sup)[0]]
    x = solve(*condense(K, f, D=D))
    wv = x[ib.nodal_dofs[0]]
    hh = ib.interpolate(x).hess                                    # curvatures at quadrature points
    kxx, kyy, kxy = hh[0, 0], hh[1, 1], hh[0, 1]
    mxx = D_ * (kxx + NU * kyy)
    myy = D_ * (kyy + NU * kxx)
    mxy = D_ * (1 - NU) * kxy
    mavg, mdif = (mxx + myy) / 2, np.sqrt(((mxx - myy) / 2) ** 2 + mxy ** 2)
    mmax = np.max(np.maximum(np.abs(mavg + mdif), np.abs(mavg - mdif)), axis=1)
    sig = 6 * mmax / T ** 2
    i = int(np.argmax(sig))
    cen = m.p[:, m.t].mean(axis=1)
    c = cen[:, i]
    j = int(np.argmax(np.abs(wv)))
    out = dict(max_deflection_mm=round(float(np.max(np.abs(wv))), 4), at=[round(float(v), 1) for v in m.p[:, j]],
               max_stress_mpa=round(float(sig[i]), 2), stress_at=[round(float(v), 1) for v in c],
               safety_factor=round(ALLOW / float(sig[i]), 1) if sig[i] > 0 else None, n_tri=int(m.t.shape[1]),
               applied_N=round(total_force(m, q), 3))
    if near_vents is not None:                                     # elements in the vent field (within 8 mm of a hole centre)
        vh = np.array(near_vents)
        dmin = np.min(np.hypot(cen[0][:, None] - vh[:, 0][None], cen[1][:, None] - vh[:, 1][None]), axis=1)
        sel = dmin <= 8.0
        out["vent_field_max_stress_mpa"] = round(float(sig[sel].max()), 2)
        out["vent_field_safety_factor"] = round(ALLOW / float(sig[sel].max()), 1)
    return out


def press(m, x0, y0, force=20.0, r=4.0):
    """20 N spread over a 4 mm radius fingertip; scaled so the force actually applied to this mesh (holes take none) is 20 N."""
    def q0(x, y):
        return (((x - x0) ** 2 + (y - y0) ** 2) <= r * r).astype(float)
    k = force / total_force(m, q0)
    return lambda x, y: k * q0(x, y)


def main():
    res = {"model": __doc__.strip().splitlines()[0], "assumed_part_masses_g": PARTS_G, "E_MPa": E_MPA, "allowable_MPa": ALLOW,
           "mesh_mm": H_MESH}
    meshes = {k: mesh_of(region(v)) for k, v in (("solid", False), ("vents", True))}
    q = loads()
    vh = vent_holes()
    for k, m in meshes.items():
        res[f"{k}_weight"] = solve_case(m, q, near_vents=vh)
    # press test: 20 N on each vent field (between two holes), same points on the solid plate; the worst case of each is kept
    arr = np.array(vh)
    cands = []
    for cx, cy in ((26.0, 63.0), (61.0, 93.0), (74.0, 103.0), (104.4, 73.0), (104.4, 103.0), (87.0, 103.0)):
        dd_ = np.hypot(arr[:, 0] - cx, arr[:, 1] - cy)
        hx, hy = arr[np.argmin(dd_)]
        pt = (round(float(hx), 1), round(float(hy) + 5.0, 1))   # on the web between this hole and the next one up
        if pt not in cands:
            cands.append(pt)
    res["press_points"] = cands
    rows = []
    for (cx, cy) in cands:
        a = solve_case(meshes["solid"], press(meshes["solid"], cx, cy), near_vents=vh)
        b = solve_case(meshes["vents"], press(meshes["vents"], cx, cy), near_vents=vh)
        rows.append(dict(press_at=[cx, cy], solid=a, vents=b))
        print(f"press at ({cx:6.1f},{cy:6.1f})  deflection {a['max_deflection_mm']:.2f} -> {b['max_deflection_mm']:.2f} mm   "
              f"stress near the press {a['vent_field_max_stress_mpa']:5.1f} -> {b['vent_field_max_stress_mpa']:5.1f} MPa   "
              f"(max anywhere {a['max_stress_mpa']:.1f} -> {b['max_stress_mpa']:.1f})")
    res["press20N"] = rows
    json.dump(res, open(os.path.join(HERE, "out", "fe_shelf.json"), "w"), indent=1)
    for k in ("solid_weight", "vents_weight"):
        print(k, res[k])


if __name__ == "__main__":
    main()
