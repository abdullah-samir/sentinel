# Sentinel enclosure rev 5 - final CAD: validation, printing and test report

Prepared for Prof. Samir Elsagheer, 13 Nov 2026. This version includes your shelf changes and the WN722N board data you gave on 13 Nov. Everything below was checked in CAD and on the exported STL files. Nothing has been printed or physically fitted yet. Section 10 lists what only a printed prototype can confirm.

## Summary

- **Collisions:** 0 interferences between solid parts in the assembled model (194 items, 162 of them solid). 0 collisions along the 22-step fitting sequence, with every part swept along its real installation path. The same checks were run for each of the 5 WN722N board widths (21.0-23.0 mm), with the same result.
- **Maintenance:** every service move works. Three need another part moved first, as designed: the PN532 slid up, the breadboard tilted, or the shelf taken out for the buzzer. The NIC stack (both rails, both boards, USB connectors) lifts out with the lid off, without touching the shelf.
- **NIC rails (your changes):** the WN722N boards slide in two removable rails that sit on 4 pegs and are held down by the lid. Nothing is fixed in front of the boards. A connector space of 20 x 32 x 25 mm in front of the USB plugs is checked empty of printed parts. The right rail comes in 5 versions, one per board width from 21.0 to 23.0 mm. Any board up to 0.5 mm narrower than its version still rests at least 1.0 mm on each side. The button's plunger keeps at least 0.4 mm clear along its whole sliding path.
- **Shelf vents:** 18 hexagonal holes. They save 1.4 g and add 8 min of print time. Under the weight of the parts the plate's sag changes from 0.020 to 0.021 mm. Under a 20 N fingertip press the worst local stress is 14 MPa, a safety factor of 2.9 on 40 MPa (section 8).
- **STL files:** all 13 are closed, manifold meshes. Each is one body, except the spacer plate with its 4 rings. Each volume matches the CAD within 0.03 %. PrusaSlicer reads all of them as manifold and slices them with supports off.
- **Print:** about 231 g of PETG (76 m of 1.75 mm) and 22-25 h for the whole enclosure with one right rail. The 15 g fit-test coupon comes on top and should be printed first.
- **Changes from the approved rev 5:** all listed in section 2, with the reason for each.

## 1. Deliverables

| Item | File(s) | Notes |
|---|---|---|
| Editable CAD source | `cad/*.py` (params.py holds every dimension) | CadQuery (Python) parametric model; see section 11 |
| STL per printed part | `stl/sentinel_r5_*.stl` (13 files) | in print orientation, on the bed at Z 0; the right NIC rail in 5 width versions (print one) |
| STEP per part + assembly | `step/*.step` | for Fusion, FreeCAD, SolidWorks (not parametric there) |
| Assembled 3D model | `sentinel_r5_assembly.glb`, `step/sentinel_r5_assembly.step` | all printed and bought parts, coloured (22.0 mm boards) |
| Dimensioned drawings | `drawings/sentinel_r5_drawings.pdf` (8 A3 sheets) + PNG per sheet | 1:1 sheets can be measured when printed at 100 % |
| Exploded view | `views/exploded.png` and drawing sheet 8 | plus closed, lid-off, floor-level and cut-away views |
| Clearance / collision report | this report + `data/validation*.json`, `data/stl_qa.json` | raw results of every check, one validation file per board width |
| Print orientation, slicer settings | section 6 + `slicer/*.ini` (PrusaSlicer 2.7) | settings also listed for any other slicer |
| Filament and time | section 7 + `data/slice.json` | from PrusaSlicer's G-code estimate |
| Shelf bending check | section 8 + `data/fe_shelf.json` | plate with and without the vent holes |

## 2. Changes from the approved rev 5

Every change is also in `params.py` (list `CHANGES`) and tagged `[CAD]` or `[U]` next to the value. Dimensions not listed here are the rev 5 values.

**Your changes and data (13 Nov):**

1. The WN722N boards slide in two removable rails that drop onto 4 pegs on the shelf and are held down by the lid; nothing surrounds their USB ends (rev 5: a sled with perfboard sockets).
2. WN722N boards 21-23 mm wide (rev 5: 23) with a 2 mm button and 1 mm plunger at the edge opposite the antenna. The right rail is printed for the measured width (5 versions, 21.0-23.0 mm in 0.5 steps); it carries that edge on a ledge with a low kerb as side stop and a recess above for the plunger, with nothing over the board. The left rail's ribs now reach 2.0 mm.
3. The shelf's front edge under the NICs is at y 37 (rev 5 sled front y 25), leaving the space in front of the boards free for the USB connectors and their cables.
4. Hexagonal vent holes (7 mm across flats, 3 mm webs) in the shelf plate, kept 6 mm from every edge, screw, peg and support (strength check in section 8).

Undone as a result: the buzzer is back at its rev 5 height (centre Z 17.0). It had been lowered 2.4 mm only to clear the old NIC sled's front overhang, which your shelf change removed.

**Found by the assembly validation** (parts that would collide, or could not be fitted or removed):

5. Lid posts: rear-left post moved to the back band between holes 3 and 4 (x 64.25, 8 mm dia); it stood over the Pi's corner and blocked lowering the Pi in.
6. Lid posts: front-left post moved 9.5 mm right (x 12): it stood over the PN532, which must slide up to free NIC A's USB plug.
7. Shelf: rear-left corner no longer notched (no post there now).
8. KY-013 moved 5 mm right (x 69-87.5) so it can be lowered in past the new rear-middle lid post.
9. Left shelf ledge interrupted at the Pi's audio jack, which would otherwise hit it while the Pi is lowered in.
10. Fan screws countersunk from the top: a screw head at (15.5, 88) would sit under nRF24 #1's adapter.
11. nRF cradle gets a groove under each jack, so the module can be set down 11 mm forward and slid back (its jack hangs 2.5 mm below the PCB).
12. nRF24 modules slide back 11 mm, not 9: the jack (8 mm) and the 2.5 mm pocket must both clear the band before it can be lowered.
13. microSD card goes in through the back slot after the Pi is fitted (the card's 2.5 mm overhang passes under the band otherwise).
14. Breadboard frame's back rim stops at x 81: the ESP's 90 deg USB-C plug needs the room to be pulled out.
15. ESP snap lip raised to 0.4 mm above the module so the board can be tilted in under it.
16. Right NIC rail has windows behind the right-side vents (it stands 0.5 mm behind them).
17. NIC stack 1.0 mm further left (board edge X 95.7, left rail X 92.45-95.45, left pegs X 93.6): the 23 mm right rail keeps a 2.15 mm wall behind the plunger recess.
18. Right rail's front peg moved back under the lower board (Y 48, low boss, hole through): its boss reached 1.8 mm into the space in front of the USB plugs.
19. Buzzer held by its ears in two printed slots (no screws: a screwdriver could not reach screws facing the right wall).
20. No cable-tie anchor: the 15 x 9 power hole itself carries the plug body's side loads.

**Found by the STL inspection** (thin, weak or unprintable details; no fit dimension changed):

21. Base: two places where solids met only along an edge (PN532 back stop, buzzer slot end walls) made the STL non-manifold; the parts now overlap.
22. Base: nRF pocket roofs slope at 45 deg (they were 2.5 mm flat overhangs); the pocket is unchanged where the module sits.
23. Base: ESP end wall and snap lip raised from 7.3 to 9.0 (lip 2.4 mm thick instead of 0.7); clearance over the module unchanged at 0.4.
24. Base: SD slot mouth no longer flares downward (it left 0.4 mm of material at the floor edge).
25. Base: left-wall vents now z 14-24 (were 16-27): they cut into the shelf ledge's corbel and left thin slivers.
26. Base: PN532 channel walls, KY-013 guide and buzzer slot lips thickened from 1.2 to 1.6 mm.
27. Shelf/strap: the strap's 1 mm tab in a 1.3 slot (0.57 mm walls either side) replaced by a 3.6 x 2.15 tab in a 4 mm notch through the cradle wall.
28. Base: buzzer ear-slot end walls 1.6 mm (were 1.0).
29. Lid: TFT screw pilot 2.4 deep (was 2.5) to keep 0.6 mm of skin under the lid face; use M2.5 x 4 screws, not longer.

## 3. How the design was checked

- **Model:** 194 items. The printed parts are the base, lid, shelf, 2 NIC rails, strap, stop bar and 4 spacers. Every bought part is in too: Pi 4, ESP32-S3, 2 WN722N with their USB connectors, 2 nRF24L01+PA+LNA on adapters, PN532, TFT, 5 PBS-11A, breadboard, buzzer, KCD11, KY-013, fan, plugs, antennas, screws, nuts and inserts. They are modelled from datasheets, your measurements, your photos, or flagged assumptions. Cables are 'soft' zones that must stay free. 5 'air' zones must stay empty of solids: the NFC field, the fan intake, the USB connector space, and the path each WN722N button sweeps while its board slides in.
- **Static interference:** every pair of parts intersected with exact mesh booleans (0.02 mm chord). Anything over 0.01 mm3 counts.
- **Clearances:** smallest gap between every pair of solid parts closer than 1.5 mm.
- **Fitting sequence:** each step moves its parts along their real path (lowered, pushed, the ESP tilted and swung) in 0.5 mm steps against everything already fitted.
- **Maintenance moves:** each plug, board and sub-assembly is removed with everything else in place, or with the parts that must come off first removed.
- **Board widths:** the whole check runs once per WN722N width (21.0, 21.5, 22.0, 22.5, 23.0 mm), each with its own right rail.
- **STL inspection:** the exported files are re-loaded from disk and checked for: watertight, edges shared by exactly two faces, one body, volume against the CAD, first-layer area. Every down-facing surface is classified (bridge, cantilever, island). Wall thickness is checked by ray casting from 4 samples per mm2 of surface, plus narrow internal slots. Then PrusaSlicer's own mesh check and a full slice of every part.
- **Shelf bending:** plate-bending finite-element model of the shelf with and without the vent holes (section 8).

## 4. Collisions and clearances

**Static check:** 0 errors, 0 warnings. **Fitting sequence:** all 22 steps clear; no solid parts left outside the sequence. Results below are for 22.0 mm boards; the other widths are in 4.2.

| Step | What is fitted and how | Parts | Collisions |
|---|---|---|---|
| 0 base | Print the base; press the M3 and M2.5 heat-set inserts into the posts and standoffs. | 11 | 0 |
| 1 SMA leads | SMA/RP-SMA leads into holes 4-6 from inside (thread out through the hole); washer + nut outside. | 9 | 0 |
| 1b SMA nuts | Washers and nuts onto the bulkhead threads from outside. | 6 | 0 |
| 2 Pi | Raspberry Pi (SD card NOT fitted) lowered straight onto its 4 standoffs; 4 x M2.5 x 5 screws. | 20 | 0 |
| 2b SD card | microSD card pushed into the Pi through the back slot. | 1 | 0 |
| 3 NIC B plug | NIC B's short USB plug into the Pi's USB 3 lower port (before the breadboard). | 1 | 0 |
| 5 ESP | ESP32-S3: IPEX lead and 90 deg USB-C plug fitted on the bench; tilt the module end under the snap lip, swing the USB end down onto the bed. | 10 | 0 |
| 6 Pi plugs | ESP link into USB 3 upper, NIC A into USB 2 upper. | 2 | 0 |
| 7 small parts | Buzzer ears down into their slots; PN532 slid down its rails. | 4 | 0 |
| 7b KY-013 | KY-013: lowered 12 mm in front of its place, slid back onto the ledge, taped to the wall. | 3 | 0 |
| 8 breadboard | Breadboard into its frame (not glued), jumpers fitted. | 1 | 0 |
| 9 KCD11 | KCD11 pushed in from outside until it snaps; wires on. | 3 | 0 |
| 10 shelf | Shelf assembled on the bench (fan + spacers + 4 countersunk screws/nuts underneath, strap insert), then lowered in from the top. | 15 | 0 |
| 11 shelf screws | 2 x M3 x 8 into the shelf posts. | 2 | 0 |
| 11b NIC stack | On the bench: both WN722N slid into the two rails from the back until they touch the front stops, USB connectors plugged onto their plugs. The stack is lowered onto the 4 pegs on the shelf (no screws; the lid holds it down). | 14 | 0 |
| 12 RA plugs | Right-angle RP-SMA plugs screwed onto the two WN722N jacks (leads to holes 4 and 5). | 2 | 0 |
| 13 nRF24 | Each nRF24 + adapter set on the shelf 11 mm forward, then slid back so its jack passes hole 1 or 2 and the module end enters its pocket. | 10 | 0 |
| 14 stop+strap | nRF stop bar (pegs into the shelf) and strap (tab into the notch in the cradle wall, 1 x M3 x 8). | 3 | 0 |
| 15 antennas | Antennas screwed onto the 5 connectors outside. | 5 | 0 |
| 16 lid | Lid with screen (4 x M2.5 x 4) and 5 buttons, wired to the breadboard, lowered on; lips locate it. | 35 | 0 |
| 17 lid screws | 4 x M3 x 8 lid screws. | 4 | 0 |
| 18 power | Power bank cable into the Pi's USB-C through the left-side hole. | 1 | 0 |

**Maintenance moves**

| Move | Result | Note |
|---|---|---|
| ESP link plug out of the Pi (USB 3 upper), everything fitted | clear |  |
| NIC A plug out (USB 2 upper), PN532 slid up 15 mm | clear |  |
| NIC A plug out (USB 2 upper), PN532 left in place | blocked, as expected | expected to collide: the PN532 must slide up first |
| NIC B plug out (USB 3 lower), breadboard in place | blocked, as expected | expected to collide: the breadboard must be lifted first |
| 90 deg USB-C plug out of the ESP, breadboard in place | clear |  |
| microSD card out through the back slot, everything fitted | clear |  |
| PN532 lifted out (lid off), everything else fitted | clear |  |
| KY-013 out with the shelf fitted: slid 12 mm forward, lifted through the shelf's back cut-out | clear |  |
| nRF24 out (stop bar and strap off): slid 11 mm forward, lifted | clear |  |
| NIC stack lifted out (lid off, RA plugs unscrewed; USB connectors stay on the plugs) | clear |  |
| Shelf lifted out (NIC stack, RA plugs, nRFs, strap, stop and screws off) | clear |  |
| Buzzer lifted out with the shelf fitted (NIC stack out) | blocked, as expected | expected to collide: the shelf's front edge is over the buzzer's rear ear, so the shelf comes out first (as in rev 5) |
| Buzzer lifted out with the shelf removed | clear |  |
| ESP tilted out with the shelf removed (USB-C plug and lead stay on it) | clear | the two RA plugs hang on their coax once unscrewed and are moved aside |
| Pi lifted out (SD card, power cable, Pi-end plugs out; shelf and ESP out) | clear |  |
| WN722N slid out of its rails at the back (stack on the bench, RA plug and USB connector off) | clear |  |
| Lid lifted off | clear |  |

NIC B's plug (USB 3 lower) comes out once the breadboard's left end is tilted up 12 deg (about 15 mm at the plug). At that angle the board touches the frame's right rim (10 mm3 in CAD). That is the board flexing against the rim, not a hard stop.

### 4.1 Tightest clearances

Parts that sit on, in or against each other by design are left out: PCBs on standoffs, the shelf on its ledges, inserts in holes, nuts on their threads.

| Pair | Gap (mm) | Note |
|---|---|---|
| nRF24 adapter boards | 0.00 | edge to edge: 19 mm boards at 19 mm pitch (rev 5 layout); they may touch |
| nRF24 module on the cradle block | 0.05 | resting gap |
| KCD11 body in its cut-out | 0.10 | per side; coupon check |
| WN722N board on its rails | 0.10 | 0.1 under the board; left hold-down 0.2 over it |
| SMA thread in its 6.6 hole | 0.12 | per side; coupon check |
| fan screw in the shelf hole | 0.14 |  |
| 90 deg USB-C plug to the ESP board | 0.20 | plug body size assumed (12 x 7.8) |
| PBS-11A thread in its 12.3 hole | 0.25 | per side |
| ESP board in its frame | 0.30 | per side |
| strap above the nRF modules | 0.30 | hold-down gap |
| lid's right lip over the right NIC rail | 0.30 | this is what holds the NIC stack down |
| lid over the left rail's two posts | 0.30 |  |
| 90 deg USB-C plug to the floor | 0.40 |  |
| TFT glass in the lid opening | 0.50 | per side |
| right NIC rail to the right wall | 0.50 |  |
| right rail's low front boss under NIC A | 0.58 | to the assumed 1.4 mm parts envelope |
| Pi heatsink to the fan | 1.00 | heatsink taken as 10 mm (your figure: under 10) |
| SMA body to the rear-middle lid post | 1.16 |  |
| neighbouring button nuts | 1.22 | worst case: M12 thin nut 18 AF assumed |
| nRF24 jack in its 9.4 hole | 1.45 | per side |
| NIC A's right-angle RP-SMA plug to the shelf | 1.45 |  |
| microSD card to the back wall | 1.49 |  |

### 4.2 NIC rails across the board widths

Each width was checked as a complete assembly with its own right rail and boards of that width:

| Board (mm) | Right rail | Errors / warnings | Sequence hits | Maintenance | Rail-to-PCB min (mm) | Wall behind recess (mm) |
|---|---|---|---|---|---|---|
| 21.0 | sentinel_r5_nic_rail_right_w21.0.stl | 0 / 0 | 0 | as expected | 0.10 | 4.15 |
| 21.5 | sentinel_r5_nic_rail_right_w21.5.stl | 0 / 0 | 0 | as expected | 0.10 | 3.65 |
| 22.0 | sentinel_r5_nic_rail_right_w22.0.stl | 0 / 0 | 0 | as expected | 0.10 | 3.15 |
| 22.5 | sentinel_r5_nic_rail_right_w22.5.stl | 0 / 0 | 0 | as expected | 0.10 | 2.65 |
| 23.0 | sentinel_r5_nic_rail_right_w23.0.stl | 0 / 0 | 0 | as expected | 0.10 | 2.15 |

The errors column includes the two zones that must stay empty for every width: the USB connector space in front of the plugs, and the button's sliding path. A board narrower than its rail version floats sideways. The worst-case overlaps below are computed from the rail profile. 'Left' is the support and hold-down ribs on the antenna edge; 'right' is the ledge on the button edge. The plunger clearance is to the recess face.

| Rail version (mm) | Board (mm) | Min. overlap left (mm) | Min. overlap right (mm) | Plunger clearance (mm) |
|---|---|---|---|---|
| 21.0 | 21.0 | 1.50 | 1.55 | 0.40 |
| 21.0 | 20.5 | 1.00 | 1.05 | 0.40 |
| 21.5 | 21.5 | 1.50 | 1.55 | 0.40 |
| 21.5 | 21.0 | 1.00 | 1.05 | 0.40 |
| 22.0 | 22.0 | 1.50 | 1.55 | 0.40 |
| 22.0 | 21.5 | 1.00 | 1.05 | 0.40 |
| 22.5 | 22.5 | 1.50 | 1.55 | 0.40 |
| 22.5 | 22.0 | 1.00 | 1.05 | 0.40 |
| 23.0 | 23.0 | 1.50 | 1.55 | 0.40 |
| 23.0 | 22.5 | 1.00 | 1.05 | 0.40 |

**Choosing the right rail:** measure the PCB width with calipers and round up to the next 0.5 mm. For example, 21.3 mm takes the 21.5 version. A board wider than 23.0 mm, or narrower than 20.5 mm, needs a new version: add its width to `NIC_PCB_W_VARIANTS` and re-export.

**USB connectors:** the free connector space runs from the mating face (Y 39) to the front-right lid post (Y 7). It is 20 mm wide, centred on the plugs, from the shelf top to the lid lips. That leaves 32 mm in front of each plug for the connector body and the start of its cable. The modelled reference is a bare USB-A female socket with soldered wires: it ends at Y 25, leaving 25 mm for the wires to turn down. A moulded extension-cable end must fit in the 32 mm, including the bend of its cable. Measure it before buying, or use a bare socket or a right-angle female adapter.

**Antennas:** all six mount without interference (antenna step swept clear). Between neighbouring SMA nuts (8 AF, 9.24 across corners) the free space is 9.76 mm at 19 mm pitch and 9.26 mm at 18.5 mm pitch. That is enough for an 8 mm open spanner from the side. With the whips folded up (10 mm diameter assumed), neighbouring whips stand 9.0 and 8.5 mm apart.

**Ports:** the Pi's USB-C power (left wall hole, 15 x 9) and microSD (back slot) are reachable from outside. The USB 2 and USB 3 ports carry the ESP link and the two NICs inside; their plugs come out as the maintenance table shows. Ethernet, micro-HDMI and audio face the inside of the box and are not reachable with the lid on, as in rev 5.

## 5. STL inspection

| Part | Closed, manifold | Bodies | Volume STL / CAD (cm3) | Size on bed (mm) | Bed contact (mm2) | Overhangs to watch | Walls under 1.2 mm |
|---|---|---|---|---|---|---|---|
| Base | yes | 1 | 122.50 / 122.50 | 127.0 x 149.0 x 61.0 | 18583 | 1 | none |
| Shelf | yes | 1 | 25.47 / 25.47 | 122.0 x 104.5 x 16.7 | 8520 | 0 | none |
| Lid | yes | 1 | 32.72 / 32.71 | 127.0 x 149.0 x 5.0 | 14911 | 0 | 0.6, 0.6, 0.6, 0.6 |
| NIC rail, left | yes | 1 | 4.67 / 4.67 | 8.2 x 52.0 x 27.8 | 305 | 0 | none |
| NIC rail, right 21.0 | yes | 1 | 8.30 / 8.30 | 7.5 x 69.0 x 24.8 | 468 | 0 | none |
| NIC rail, right 21.5 | yes | 1 | 7.51 / 7.51 | 7.0 x 69.0 x 24.8 | 434 | 0 | none |
| NIC rail, right 22.0 | yes | 1 | 6.72 / 6.72 | 7.0 x 69.0 x 24.8 | 404 | 0 | none |
| NIC rail, right 22.5 | yes | 1 | 5.93 / 5.93 | 7.0 x 69.0 x 24.8 | 374 | 0 | none |
| NIC rail, right 23.0 | yes | 1 | 5.15 / 5.15 | 7.0 x 69.0 x 24.8 | 345 | 0 | none |
| nRF strap | yes | 1 | 0.72 / 0.72 | 45.0 x 8.0 x 4.1 | 351 | 0 | none |
| nRF stop bar | yes | 1 | 0.47 / 0.47 | 38.0 x 3.2 x 5.7 | 122 | 0 | none |
| Fan spacers x4 | yes | 4 | 0.25 / 0.25 | 17.0 x 17.0 x 2.1 | 118 | 0 | none |
| Fit coupon | yes | 1 | 12.97 / 12.97 | 74.0 x 36.0 x 26.0 | 2545 | 0 | none |

Issues found on the first export and fixed (then every file regenerated and re-checked):

- Base: two places where solids met only along an edge (PN532 back stop, buzzer slot end walls) made the STL non-manifold; the parts now overlap.
- Base: nRF pocket roofs slope at 45 deg (they were 2.5 mm flat overhangs); the pocket is unchanged where the module sits.
- Base: ESP end wall and snap lip raised from 7.3 to 9.0 (lip 2.4 mm thick instead of 0.7); clearance over the module unchanged at 0.4.
- Base: SD slot mouth no longer flares downward (it left 0.4 mm of material at the floor edge).
- Base: left-wall vents now z 14-24 (were 16-27): they cut into the shelf ledge's corbel and left thin slivers.
- Base: PN532 channel walls, KY-013 guide and buzzer slot lips thickened from 1.2 to 1.6 mm.
- Shelf/strap: the strap's 1 mm tab in a 1.3 slot (0.57 mm walls either side) replaced by a 3.6 x 2.15 tab in a 4 mm notch through the cradle wall.
- Base: buzzer ear-slot end walls 1.6 mm (were 1.0).
- Lid: TFT screw pilot 2.4 deep (was 2.5) to keep 0.6 mm of skin under the lid face; use M2.5 x 4 screws, not longer.

Accepted, with reasons:

- **ESP snap lip:** a 0.8 mm flat ledge, the only flat overhang in the base. It is two extrusion widths and prints as an overhang perimeter. Any droop eats into the 0.4 mm clearance over the module, so check it on the first print.
- **Lid, TFT bosses:** 0.6 mm of lid skin is left above each 2.4 mm pilot hole. The bosses cannot be deeper without lowering the screen. Use M2.5 x 4 screws, not longer, and tighten by hand.
- **Tapers, not walls:** the NIC rail ribs (45 deg triangles), the countersink rims and the 45 deg corbel tips end in knife edges by shape. The ray check flags them as thin; they are not thin walls.

## 6. Print orientation and slicer settings

| STL | Face on the bed (already oriented) | Supports | Settings |
|---|---|---|---|
| sentinel_r5_base.stl | floor | none | main parts |
| sentinel_r5_lid.stl | top face (outside) | none | main parts |
| sentinel_r5_shelf.stl | shelf underside | none | main parts |
| sentinel_r5_nic_rail_left.stl | rail foot | none | nic rails |
| sentinel_r5_nic_rail_right_w21.0.stl | rail foot | none | nic rails |
| sentinel_r5_nic_rail_right_w21.5.stl | rail foot | none | nic rails |
| sentinel_r5_nic_rail_right_w22.0.stl | rail foot | none | nic rails |
| sentinel_r5_nic_rail_right_w22.5.stl | rail foot | none | nic rails |
| sentinel_r5_nic_rail_right_w23.0.stl | rail foot | none | nic rails |
| sentinel_r5_nrf_strap.stl | strap top | none | small parts |
| sentinel_r5_nrf_stop.stl | bar top (pegs up) | none | small parts |
| sentinel_r5_fan_spacers_x4.stl | ring face | none | small parts |
| sentinel_r5_fit_test_coupon.stl | base plate | none | main parts |

Settings (PETG, 0.4 mm nozzle). The `slicer/*.ini` files hold these on top of PrusaSlicer's Creality Ender-3 V2 profile; any slicer can use the same values:

| Setting | Main parts | Strap, stop bar, spacers | NIC rails |
|---|---|---|---|
| Layer height / first layer | 0.2 / 0.2 mm | same | same |
| Perimeters (walls) | 4 | same | same |
| Top / bottom solid layers | 5 / 4 | same | same |
| Infill | 25% gyroid | 100 % rectilinear | 100 % rectilinear |
| Supports | off | off | off |
| Brim | none (add 5 mm on the base if a corner lifts) | none | 5 mm (tall, narrow parts) |
| Nozzle / bed | 240 C / 80 C first layer, 75 C after | same | same |
| Part fan | 20-50 %, bridges 100 % | same | same |
| Seam | rear | rear | rear |
| Elephant-foot compensation | 0.1 mm (the base also has a 0.6 mm chamfer on its bed edge) | same | same |
| XY size compensation | 0 (do not scale the model) | 0 | 0 |

**Accuracy and shrinkage.** PETG shrinks much less than ABS, and on parts this size the printer's own hole and outline accuracy matters more. Do not scale the model. Print the coupon (sheet 7), check each fit, and if one is off change only that parameter in `params.py`. Examples: `INSERT_M3['hole']`, `SMA['hole']`, `SW['cut']`, `BTN['hole']`, `NIC_PEG['hole']`. For the NIC boards, `NIC_RAIL['sup_gap']` / `['hold_gap']` set the vertical fit and `NIC_RAIL['gap']` the side play. Then re-export. The sliding fits are built with 0.2-0.3 mm per side. Holes printed vertically in the band are teardrops, so their tops stay round enough.

## 7. Filament and print time

| Part | PETG (g) | Length (m) | Time, stock speeds | Time, faster profile |
|---|---|---|---|---|
| Base | 145.2 | 47.54 | 16h 21m 11s | 14h 1m 23s |
| Shelf | 27.7 | 9.07 | 3h 3m 45s | 2h 45m 28s |
| Lid | 40.6 | 13.30 | 3h 48m 3s | 3h 15m 8s |
| NIC rail, left | 6.2 | 2.02 | 49m 49s | 48m 56s |
| NIC rail, right 21.0 (alternative) | 11.1 | 3.63 | 1h 21m 15s | 1h 13m 46s |
| NIC rail, right 21.5 (alternative) | 10.1 | 3.30 | 1h 14m 56s | 1h 8m 42s |
| NIC rail, right 22.0 | 8.9 | 2.92 | 1h 2m 31s | 58m 28s |
| NIC rail, right 22.5 (alternative) | 7.9 | 2.58 | 58m 43s | 55m 26s |
| NIC rail, right 23.0 (alternative) | 6.8 | 2.24 | 54m 16s | 51m 48s |
| nRF strap | 1.0 | 0.34 | 8m 4s | 7m 32s |
| nRF stop bar | 0.7 | 0.23 | 8m 6s | 8m 6s |
| Fan spacers x4 | 0.4 | 0.12 | 4m 25s | 4m 25s |
| Fit coupon | 15.2 | 4.98 | 1h 45m 37s | 1h 34m 27s |
| **Enclosure total (one right rail, the 22.0 version; without coupon)** | **230.7** | **75.5** | **25.4 h** | **22.2 h** |

Only one right rail is printed. They range from 6.8 g (23.0 mm board) to 11.1 g (21.0 mm), so the total moves by about 2 g either way. Shelf without the vent holes, same settings: 29.09 g, 2h 55m 57s (with the holes: 27.69 g, 3h 3m 45s).

PrusaSlicer 2.7.2 estimates at 1.27 g/cm3. 'Stock speeds' is the Ender-3 V2 "0.20 mm NORMAL" profile (perimeters 40 mm/s, outer wall 25, infill 50, 500 mm/s2); 'faster' is its "NORMAL SPEED" profile (60 / 30 / 60). A faster printer will be quicker; the gram figures do not depend on speed. One 1 kg spool covers the enclosure, the coupon and a reprint of the lid or shelf.

## 8. Shelf vent holes: strength check

You asked for holes in the shelf for air and weight, but only if they do not make it weak. The first try covered the whole plate. The bending check showed the area between the fan opening, the jumper slot and the KY-013 cut-out's free edge is the plate's most flexible part, so that area stays solid. The final 18 holes (7 mm across flats, 3 mm webs) sit only in front of the nRF stop bar and under the NIC boards, at least 6 mm from every edge, screw, peg and support.

Model: Kirchhoff plate, finite elements (scikit-fem, Morley triangles, 0.7 mm mesh). The plate is 2.4 mm thick and is taken alone: the cradle, lip and pegs, which add stiffness, are ignored. It rests on the wall ledges and is held vertically at the two screw posts. PETG is taken as E = 1800 MPa, against an allowable bending stress of 40 MPa. Loads are the plate's own weight plus the parts it carries, with masses rounded up: NIC stack (2 WN722N, 2 rails, USB connectors) 50 g, 2 nRF24 + adapters 30 g, fan + spacers + screws 20 g, cradle, strap, stop bar 10 g. Separately, a 20 N press with a fingertip (8 mm patch) is applied at the web between two holes in each vent group.

| Load case | Max. deflection (mm), solid -> with holes | Max. stress near the load (MPa), solid -> with holes | Safety factor with holes |
|---|---|---|---|
| Parts' weight only | 0.020 -> 0.021 | 0.19 -> 0.19 | 212 |
| 20 N press at X 26.5, Y 67.0 | 0.32 -> 0.47 | 5.6 -> 14.0 | 2.9 |
| 20 N press at X 61.1, Y 87.0 | 0.89 -> 0.99 | 6.4 -> 13.4 | 3.0 |
| 20 N press at X 104.4, Y 82.0 | 0.21 -> 0.26 | 4.2 -> 10.9 | 3.7 |
| 20 N press at X 104.4, Y 112.0 | 0.31 -> 0.32 | 3.6 -> 7.7 | 5.2 |

Under normal use the holes change nothing measurable. A hard press on the webs raises the local stress 2.1-2.6 times, but it stays well inside PETG's strength. The highest stress anywhere (17.3 MPa solid, 18.7 MPa with the holes) sits at the screw-post supports, where the simplified point-support model concentrates it (see `data/fe_shelf.json`). The holes add about 764 mm2 of open area for air through the shelf. How much that helps the NICs' temperature can only be measured (section 10).

## 9. Assembly and disassembly

Assembly follows the validated sequence in section 4 (also drawing sheet 8). Points that matter in practice:

1. Heat-set inserts go in before anything else: 7 x M3 (4 lid posts, 2 shelf posts, strap hole) and 4 x M2.5 (Pi standoffs).
2. The SMA leads go through holes 4-6 from inside before the Pi. The Pi goes in without its microSD card, which is then pushed in through the back slot.
3. NIC B's plug goes into USB 3 lower before the breadboard. The ESP goes in module-end first under the snap lip, then the USB end swings down.
4. The shelf is built on the bench (fan, spacers, strap insert), lowered in and screwed down (2 x M3 x 8).
5. The NIC stack is built on the bench. Slide both WN722N into the two rails from the back, chip face up, until they touch the front stops. Push the USB connectors onto the plugs while holding the board, since the rails stop the board only toward the front. Lower the stack onto the 4 pegs; no screws. Screw the two right-angle RP-SMA plugs on.
6. Each nRF24 is set down 11 mm forward and slid back through its hole. Then the stop bar, then the strap (tab in the notch, 1 x M3 x 8).
7. Lid: screen (4 x M2.5 x 4) and buttons fitted to the lid first, wired, then lowered on; the lips locate it. 4 x M3 x 8. The lid is what holds the NIC stack down.

Disassembly is the reverse. With the lid off and the two RA plugs unscrewed, the NIC stack lifts straight out with its USB connectors still on the plugs; the shelf stays in. To reach NIC A's Pi-side plug, slide the PN532 up 15 mm. For NIC B's, tilt the breadboard's left end up about 12 deg. The buzzer comes out only with the shelf out.

## 10. What still needs a physical prototype

CAD cannot confirm these. In order of risk:

1. **Fit coupon first** (about 1 h 45 min). Check the insert holes, the SMA hole and spot face, the nRF hole and pocket, the KCD11 cut-out in 2 mm, and the PBS-11A hole. Check both NIC rail samples. The antenna edge of a WN722N must slide between the left ribs with a little play. Its button edge must run along the right ledge with the plunger passing the recess untouched. Adjust the parameter for any fit that is wrong before printing the 14-16 h base.
2. **WN722N width and button:** measure the PCB width with calipers and print the matching right rail (section 4.2). The button is taken as 2 mm high, with its plunger 1 mm past the edge and nothing else within 2.5 mm of either long edge, as you described. Check that the board slides all the way in without the plunger catching. Check that the parts on both faces clear the ribs; the model assumes 1.4 mm of parts on each face.
3. **NIC stack held by the lid:** the rails only sit on their pegs. The lid's right lip is 0.3 mm over the right rail and two posts reach 0.3 mm under the lid on the left rail. With the lid screwed down, check that nothing rattles. If it does, a dab of hot glue or a thin foam pad on the posts takes up the play.
4. **USB connectors:** check that your connectors and their cables fit in front of the plugs (section 4.2) and that the cables reach the Pi along the route behind the breadboard without tight bends.
5. **Parts whose size is assumed (`[A]` in params.py):** the USB plug position on the WN722N (taken as centred), the SMA flange and thread length, the KY-013 header side, the ESP's underside (USB-C receptacle positions, shield), the 90 deg USB-C plug body (must be 12 x 7.8 mm or smaller), the PBS-11A nut, the microSD position, the antenna whips. Measure each on arrival against the value in params.py.
6. **ESP retention:** the snap lip overlaps the module end by only 0.2-0.5 mm, and nothing holds the USB end down except the 90 deg plug. Check the board stays put with the cable fitted. If it lifts, the planned fallback is a strip of thin double-sided tape on the USB-end pad.
7. **Cables:** the 90 deg USB-C cable has about 6 mm of room under the shelf, so use a thin cable, 3.5 mm or less. Check the NIC USB wires and the RP-SMA coax pigtails route through their reserved zones without tight bends; thin RG178-class pigtails are the safe choice.
8. **Button nuts:** with 18 AF nuts, neighbours end up 1.2 mm apart, so no socket or ring spanner fits once a neighbour is on. Tighten by hand: hold the nut inside and turn the button from outside. Check the real nut (size and thickness) when the buttons arrive.
9. **Heat:** the fan's intake is partly covered and the fan sits 1.0 mm above a 10 mm heatsink. Measure the Pi's temperature under load with the lid on, and the NICs' temperature with and without the shelf vents if they run hot.
10. **Radio:** six antennas share the back band, 18.5-19 mm apart. Check range and interference once all radios run together.
11. **First print:** watch for base corners lifting (add a brim), the 0.8 mm ESP lip ledge, the 45 deg pocket roofs, and whether the KCD11 clips grip a 2 mm wall.
12. **Lid:** check the 0.3 mm lip gap gives a snug, rattle-free fit and that all four screws reach their inserts without forcing.

## 11. Changing the design

All dimensions are in `cad/params.py`, each tagged with its source. After a change, run, in `cad/`:

```
python3 validate.py   # collisions, clearances, fitting sequence, maintenance moves  -> out/validation.json
SENTINEL_NIC_W=21.0 python3 validate.py   # same for another WN722N width          -> out/validation_w21.0.json
python3 export.py     # STL (print orientation), STEP, assembly GLB                    -> deliverables/
python3 stl_qa.py     # mesh, overhang and wall-thickness checks of the STL files     -> out/stl_qa.json
python3 slice.py      # PrusaSlicer: filament and time                                -> out/slice.json
python3 fe_shelf.py   # shelf bending with and without the vent holes                -> out/fe_shelf.json
python3 views.py      # rendered views;  python3 drawings.py  # drawing sheets (PDF)
python3 report.py     # this report
```

Needs Python 3.10+ with CadQuery 2.x, manifold3d, trimesh (plus embreex for fast ray casting), matplotlib, shapely and scikit-fem. OpenSCAD renders the views and PrusaSlicer 2.7 does the slicing. The parts are built in `base.py`, `lid.py`, `shelf.py` and `coupon.py`. The bought parts are in `bought.py`, and the fitting sequence in `assembly.py`. To take the vent holes out, call `build_shelf(vents=False)` or empty `SHELF_VENTS['zones']`.

