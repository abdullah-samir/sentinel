# Sentinel enclosure rev 5 - final CAD package (13 Nov 2026)

Start with **REPORT.md** (validation results, print settings, filament and time, shelf strength check, and what still
needs a physical test).

| Folder / file | What it is |
|---|---|
| `REPORT.md` | Clearance and collision report, NIC rails per board width, STL inspection, print orientation and slicer settings, filament and time, shelf vent strength check, assembly order, prototype test list |
| `drawings/sentinel_r5_drawings.pdf` | 8 dimensioned A3 sheets (base plan, elevations, sections, lid, shelf, NIC rails, small parts + coupon, assembly + parts list). Print at 100 % to measure the 1:1 sheets |
| `stl/` | Print-ready STL files, already in print orientation. **Print `sentinel_r5_fit_test_coupon.stl` first.** The right NIC rail comes in 5 versions (`..._right_w21.0` to `..._w23.0`): measure your WN722N board width and print only the matching one (round up to the next 0.5 mm) |
| `step/` | STEP of every part and of the full assembly (for Fusion 360, FreeCAD, SolidWorks) |
| `sentinel_r5_assembly.glb` | Coloured 3D assembly with 22 mm boards (Windows 3D Viewer, Blender, any glTF viewer) |
| `views/` | Rendered views: closed (front, back), lid off, floor level, cut-away, exploded |
| `slicer/` | PrusaSlicer 2.7 settings (.ini): main parts, small parts, NIC rails; stock and faster speed |
| `data/` | Raw results: validation.json (22 mm boards) and validation_w*.json (each board width), stl_qa.json, slice.json, parts.json, fe_shelf.json |
| `cad/` | Parametric source (CadQuery, Python). Every dimension is in `cad/params.py` |

Rebuilding after a change (in `cad/`): `python3 validate.py`, `python3 export.py`, `python3 stl_qa.py`, `python3 slice.py`,
`python3 fe_shelf.py`, `python3 views.py`, `python3 drawings.py`, `python3 report.py`. For another board width:
`SENTINEL_NIC_W=21.5 python3 validate.py`. Outputs go to `cad/deliverables/` and `cad/out/`.
Needs Python 3.10+ with cadquery, manifold3d, trimesh, matplotlib, shapely, scikit-fem (embreex optional). `views.py`
calls OpenSCAD through `xvfb-run` (Linux); `slice.py` reads PrusaSlicer's bundled `Creality.ini` (path in `VENDOR` at
the top of the file).
